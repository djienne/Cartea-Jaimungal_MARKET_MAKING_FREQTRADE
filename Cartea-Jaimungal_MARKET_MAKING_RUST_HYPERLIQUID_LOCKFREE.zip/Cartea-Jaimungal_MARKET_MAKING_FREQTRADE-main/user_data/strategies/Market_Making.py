# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these libs ---
from warnings import simplefilter
import hashlib
import math
import numpy as np  # noqa
import pandas as pd  # noqa
import os
import sys
import threading
from pandas import DataFrame
from functools import reduce
import json
import logging
from pathlib import Path
import importlib.util
from typing import Any
from freqtrade.strategy import (BooleanParameter, CategoricalParameter, DecimalParameter,
                                IStrategy, IntParameter, stoploss_from_absolute, informative)
from freqtrade.exchange import timeframe_to_prev_date
from freqtrade.persistence import Trade, Order
from datetime import datetime, timedelta, timezone
# --------------------------------
# Add your lib to import here
import talib.abstract as ta
import pandas_ta as pta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from importlib import import_module

logger = logging.getLogger(__name__)

# Parameter snapshot schema this strategy consumes (see scripts/param_utils.py).
# v3: survival-based lambda (mo_survival_fit), mid-relative kappa, EMA-smoothed
# primaries with *_raw companions, depth_p95 calibration diagnostics, sigma2.
SUPPORTED_PARAM_SCHEMA_VERSION = 3

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)
pd.options.mode.chained_assignment = None

def find_upwards(filename: str, start: Path, max_up: int = 10) -> Path:
    p = start.resolve()
    for _ in range(max_up + 1):
        candidate = p / filename
        if candidate.exists():
            return candidate
        if p.parent == p:
            break
        p = p.parent
    raise FileNotFoundError(f"Could not find {filename} from {start}")

def load_configs(start_dir: Path | None = None, max_up: int = 10):
    if start_dir is None:
        try:
            start_dir = Path(__file__).resolve().parent
        except NameError:  # e.g., interactive
            start_dir = Path(sys.argv[0]).resolve().parent if sys.argv and sys.argv[0] else Path.cwd()

    def _load_optional(filename: str) -> dict:
        """A missing snapshot means 'not ready yet', not a fatal error.

        kappa.json and epsilon.json used to be unguarded here, so a cold start
        before the estimator's first successful cycle killed the process with
        FileNotFoundError. Because bot_start raises before the reload loop ever
        begins, that could never recover without a restart. Absent params must
        behave exactly like stale ones: come up, do not quote, retry on cadence.

        Returning {} is already safe downstream -- _refresh_hjb leaves hjb_cache
        as None, _params_are_valid returns param_schema_unsupported, and both
        _model_ready and _quote_state_valid gate quoting on precisely that.
        """
        try:
            return json.loads(
                (find_upwards(filename, start_dir, max_up)).read_text(encoding="utf-8")
            )
        except Exception:
            return {}

    kappa = _load_optional("kappa.json")
    epsilon = _load_optional("epsilon.json")
    lambda_params = _load_optional("lambda.json")
    return kappa, epsilon, lambda_params


def load_hjb_solver():
    """
    Import HJB module.

    In the Freqtrade container this repo mounts `./scripts` to `/freqtrade/scripts`,
    but that path is not guaranteed to be on `sys.path`. We first try a normal
    import (`import hjb`), then fall back to loading `scripts/hjb.py` by file path.
    """
    try:
        return import_module("hjb")
    except Exception:
        pass

    try:
        start_dir = Path(__file__).resolve().parent
    except NameError:  # e.g., interactive
        start_dir = Path(sys.argv[0]).resolve().parent if sys.argv and sys.argv[0] else Path.cwd()

    for rel in ("scripts/hjb.py", "hjb.py"):
        try:
            hjb_path = find_upwards(rel, start_dir, max_up=10)
        except Exception:
            hjb_path = None
        if not hjb_path:
            continue
        try:
            spec = importlib.util.spec_from_file_location("hjb", str(hjb_path))
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module
        except Exception:
            continue

    return None


def load_mm_core():
    """Import the shared quoting core (scripts/mm_core.py).

    Unlike hjb and param_store, mm_core has transitive imports of its own
    (``hjb``, ``hyperliquid_alo_executor``), so loading it by file path is not
    enough -- the sibling modules have to be importable too. We therefore put
    the containing ``scripts`` directory on sys.path and then import normally.

    Returns None if unavailable; callers keep their local arithmetic in that
    case rather than refusing to quote.
    """
    try:
        return import_module("mm_core")
    except Exception:
        pass
    try:
        start_dir = Path(__file__).resolve().parent
    except NameError:
        start_dir = Path.cwd()
    for rel in ("scripts/mm_core.py", "mm_core.py"):
        try:
            core_path = find_upwards(rel, start_dir, max_up=10)
        except Exception:
            continue
        scripts_dir = str(core_path.parent)
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        try:
            return import_module("mm_core")
        except Exception:
            continue
    return None


def load_param_store():
    """Import the optional Redis param_store helper (scripts/param_store.py).

    Mirrors load_hjb_solver: normal import first, then load by file path. Returns
    None if unavailable, in which case the strategy falls back to JSON files.
    """
    try:
        return import_module("param_store")
    except Exception:
        pass
    try:
        start_dir = Path(__file__).resolve().parent
    except NameError:
        start_dir = Path.cwd()
    for rel in ("scripts/param_store.py", "param_store.py"):
        try:
            store_path = find_upwards(rel, start_dir, max_up=10)
        except Exception:
            store_path = None
        if not store_path:
            continue
        try:
            spec = importlib.util.spec_from_file_location("param_store", str(store_path))
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module
        except Exception:
            continue
    return None


class ParamReloadBlocked(Exception):
    """The file-based param snapshot may be mid-update (lock present / status not ok).

    Raised by _load_params(enforce_file_gate=True) so a periodic reload can skip
    this cycle and keep the previous params instead of risking a torn read.
    """

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


class Market_Making(IStrategy):

    # Strategy interface version - allow new iterations of the strategy interface.
    # Check the documentation or the Sample strategy to get the latest version.
    INTERFACE_VERSION = 3

    # Hyperliquid base perp maker fee: 0.015% = 1.5 bps.
    fees_maker_HL = 0.0150/100.0
    trading_enabled: bool = False
    fail_closed_reason: str = "initial_safety_lock"
    post_only_verified: bool = False

    # Strategy configuration
    can_short: bool = False
    # "long" or "short" -- which leg of the two-instance pair this is. Supplied
    # by config.{long,short}.json; must agree with can_short or the guards
    # contradict each other and the strategy fails closed.
    role: str = "long"
    # Stop quoting if the peer's heartbeat is older than this. Exits and the
    # heartbeat itself are NEVER gated on it: a peer outage must not strand both
    # books with no unwind path, nor make staleness mutual and permanent.
    max_peer_inventory_age_seconds: float = 30.0
    use_exit_signal: bool = True
    use_custom_stoploss: bool = False
    process_only_new_candles: bool = False
    # Inventory is the SIZE of one trade, not a count of trades: freqtrade rests
    # one order per pair, so |q| > 1 is only reachable through adjust_trade_position.
    position_adjustment_enable: bool = True
    # 0 would block every increase. -1 is unlimited; the real bound is q_max,
    # enforced in adjust_trade_position and by the HJB's own boundary.
    max_entry_position_adjustment = -1

    # Disable time-based ROI exits; passive exits are controlled explicitly.
    minimal_roi = {
        "0": 10
    }

    # Configuration parameters loaded from external files
    kappas = None
    epsilons = None
    lambdas = None
    hjb_cache = None
    hjb_solver = load_hjb_solver()
    # Shared quote arithmetic (scripts/mm_core.py). The replay harness imports
    # the same module, so a backtest simulates literally the code that quotes.
    _mm_core = load_mm_core()
    # Optional Redis transport for the param snapshot (estimator -> strategy).
    _param_store = None
    _param_store_loaded: bool = False
    _param_source: str = "file"
    _hjb_import_error_logged: bool = False
    _hjb_generation: int = 0
    _hjb_last_refresh_ts: str | None = None
    _hjb_last_refresh_dt: datetime | None = None
    _hjb_param_fingerprint: str | None = None
    _hjb_params_snapshot: dict[str, Any] | None = None
    # Episode clock for hjb_time_mode="episodic". Both legs must agree on it or
    # they price the same net inventory at different points on the surface, so
    # it rides the inventory heartbeat (see _adopt_peer_episode).
    _episode_id: int = 0
    _episode_start_dt: datetime | None = None

    debug_json_log: bool = True
    debug_json_log_filename: str = "mm_debug.jsonl"
    debug_json_log_max_bytes: int = 2_000_000
    # 2 MB x 1 backup retained ~66 minutes at the measured 3.7 MB/hour. 48 files
    # is ~4.4 days of continuous quoting, which is what a multi-day dry run needs
    # to hand calibrate_replay_from_logs.py a usable fill sample. ~98 MB on disk.
    debug_json_log_backup_count: int = 48
    _debug_log_lock = threading.Lock()

    _data_checked_and_available: bool = False # Added to track initial data presence
    # Conservative stoploss at 75% loss
    stoploss = -0.75

    # Trailing stoploss disabled
    trailing_stop = False

    # Use 1-minute timeframe for high-frequency market making
    timeframe = '1m'

    # No startup candles required
    startup_candle_count: int = 0

    # HJB risk settings (aligned with fq_market_making_introduction.ipynb)
    # Risk preference expressed in the DIMENSIONLESS products the model responds
    # to, so it carries across symbols. eq. 10.28 uses -phi*kappa*q^2 and
    # exp(-alpha*kappa*q^2), so a phi tuned at one kappa is meaningless at
    # another: ETH (kappa~2) -> CASHCAT (kappa~10000) took phi*kappa*T from 0.03
    # to 153 and pinned every quote to the floor or the cap. Set either to 0 to
    # fall back to the raw hjb_phi / hjb_alpha below.
    # 10.0 is NOT a measured optimum. An early 9.8h sweep reported an inverted U
    # peaking at 10-20; it did not replicate. Re-swept 2026-08-17 over 0.05 ->
    # 400 on one pinned 18.67h tape: monotonically improving past ~1 and still
    # improving at 400. USDC per fill barely moves (-0.06 to -0.11) while fills
    # fall 1959 -> 338, i.e. phi only changes how much we trade, not how well.
    # Kept mid-range so the model still trades enough to be measured. Full
    # numbers and reasoning in docs/spread_calculation.tex, sec:phisweep.
    hjb_phi_kappa_t = 10.0
    # Ceiling on the SAME dimensionless product, so the sigma2 volatility channel
    # -- which is still in absolute price units -- cannot re-pin quotes to the
    # clamps through the other channel. Set it ABOVE hjb_phi_kappa_t or the
    # setting above is silently clamped to this one; the gap between them is the
    # headroom the volatility channel is allowed.
    hjb_phi_kappa_t_max = 50.0
    hjb_alpha_kappa = 0.05
    hjb_alpha = 0.001   # raw fallback, only used when hjb_alpha_kappa == 0
    # Running inventory penalty. NOTE: eq. 10.28 puts this in the transition
    # matrix as -phi*kappa*q^2, so phi is NOT kappa-invariant and must be
    # re-tuned whenever kappa or the inventory unit moves. (The book's own
    # Fig 10.8/10.9 captions are inconsistent with its eq. 10.28 by a factor of
    # kappa -- do not read phi off those figures.)
    hjb_phi = 0.0001
    hjb_q_max = 6     # inventory grid radius; q_max ~ 20% of expected trades over the horizon
    # Horizon in seconds (lambda is trades/sec). Paired with q_max above so that
    # q_max is ~20% of the expected trade count over T, which is the book's own
    # sizing heuristic (section 10.4.2).
    hjb_horizon_seconds = 150.0
    use_asymmetric_kappa = True  # always use backward-Euler asymmetric-κ solver (kappa+ != kappa-)

    # The book's control is delta*(t,q) on [0,T] with terminal condition
    # h(T,q) = -alpha*q^2. "stationary" reads only the t=0 slice, so the agent
    # never approaches T, alpha never bites, and the time dimension of eq. 10.26
    # is inert -- that is an approximation, not the model. "episodic" runs a real
    # clock: each episode starts at t=0 and the quoted depths follow the surface
    # to t=T.
    #
    # What that does here is NOT the textbook "flatten harder as t->T" picture,
    # because our running penalty dwarfs the terminal one: phi*kappa*T = 10 vs
    # alpha*kappa = 0.05, a factor of 200. The running penalty is what remains to
    # be PAID over the time left, so it is largest at t=0 and vanishes at T.
    # Measured at q=+3 on live-scale CASHCAT params, the ask depth runs
    # -6.8e-6 -> +1.0e-4 as tau goes 150s -> 0: the agent unwinds hardest at the
    # START of an episode and relaxes into the terminal. That is the correct
    # reading of eq. 10.26 at this calibration; the book's figures show the
    # opposite because their alpha dominates their phi*T.
    hjb_time_mode = "episodic"
    # End the episode early once inventory is genuinely flat: the book's agent
    # starts flat at t=0, so reaching flat is the natural place to restart rather
    # than running a stale clock down against no position.
    hjb_episode_reset_on_flat = True
    # ...but not immediately, or a single round trip restarts the clock and the
    # horizon never advances. Requires this fraction of T to have elapsed first.
    hjb_episode_min_elapsed_fraction = 0.25

    # One inventory unit must match the actual order amount: the HJB assumes one
    # fill moves q by exactly 1 (eq. 10.2 is a unit-jump process). On CASHCAT at
    # ~0.1015 USDC the unit is ~247 USDC of notional, comfortably above the
    # exchange minimum and below stake_amount so the one-unit cap is what binds.
    # custom_stake_amount emits inventory_unit_mismatch when the rounded amount
    # drifts >25% from the unit (e.g. after large mid moves).
    inventory_unit_base = 2430.0
    # Leverage is a financing choice, not a model input -- see leverage().
    target_leverage = 2.0
    # Auto-size the inventory unit from capital instead of pinning it to a value
    # that silently goes stale as price moves:
    #
    #   unit = available_capital * target_utilisation * leverage / (q_max * mid)
    #
    # At 1000 USDC, 74% utilisation, 2x, q_max=6 and CASHCAT~0.1015 this gives
    # 2430 tokens -- so the constant above is the formula's answer today, not a
    # magic number, and it re-derives itself if the symbol or price moves.
    # Recomputed ONLY when flat: changing the unit while holding
    # inventory would shift the q-mapping under the open position, and the unit
    # also feeds phi_effective, so it must not move mid-position.
    auto_size_inventory_unit = True
    target_capital_utilisation = 0.74
    # Final half-spread assembly (see _assemble_half_spread):
    #   delta_total = clamp(HJB depth * spread_multiplier + fee*mid,
    #                       min_half_spread_bps, max_half_spread_bps)
    # The multiplier scales only the MODEL term; the fee cushion is one maker
    # fee per side (a round trip costs two fees and collects the cushion
    # twice). All three knobs overridable via market_making.*.
    # The book's optimum IS delta*; a multiplier scales 1/kappa and the
    # inventory skew with it, so it stays at 1.0. Defensive widening goes in
    # extra_cushion_bps below, which is additive and therefore skew-preserving.
    spread_multiplier = 1.0
    extra_cushion_bps = 0.0
    # Anchored to the maker fee: a half-spread below your own fee loses money
    # on the round trip regardless of anything else, so that is a real floor.
    # Above ~2 bps the clamp starts flattening the HJB's inventory skew (on
    # live ETH a 3 bps floor clamped all 24 sides and the skew went dead);
    # below ~1.4 bps it never binds at all, because the fee cushion already
    # guarantees that much. Defensive widening belongs in extra_cushion_bps.
    min_half_spread_bps = 1.5
    max_half_spread_bps = 80.0
    # Volatility-aware inventory penalty: phi_effective =
    # hjb_phi + gamma_inventory_risk * sigma2_per_sec * inventory_unit_base
    # (sigma2 published by get_kappa from the BBO mid stream; falls back to
    # hjb_phi when absent). See docs/UNITS.md for the unit derivation.
    gamma_inventory_risk = 0.05
    # Must track hjb_q_max: if the risk cap and the solver grid drift apart you
    # either quote past the model's boundary or go dark inside it.
    max_abs_inventory_units = 6
    max_param_age_seconds = 90
    max_collector_age_seconds = 30
    max_book_age_seconds = 5
    # Must stay well below max_collector_age_seconds: this caches the newest
    # collector row timestamp, and a cache longer than the freshness window
    # makes the cached timestamp age past it and rejects quotes as stale.
    collector_timestamp_cache_seconds = 5
    collector_timestamp_newest_files_per_stream = 5
    collector_required_streams = ("orderbooks", "prices", "trades")
    book_snapshot_cache_ms = 500
    max_toxicity = 1.5
    # Sized for q_max=6 at the auto-derived unit: ~1480 USDC of notional and
    # ~740 USDC of margin at 2x, on either symbol. The ~2x headroom above
    # that absorbs an in-flight fill landing while q is already at the cap, plus
    # mid drift revaluing existing inventory; a cap sized exactly to the target
    # would trip on ordinary noise and dead-stop the quoter.
    max_notional_exposure_usdc = 3200.0
    max_margin_used_usdc = 1600.0
    min_liquidation_buffer_usdc = 100.0
    maintenance_margin_rate = 0.05
    max_daily_loss_usdc = 20
    max_consecutive_losses = 10
    max_post_only_reject_rate = 0.80
    min_post_only_reject_samples = 10
    quote_link_max_age_seconds = 900
    quote_link_cache_limit = 500
    max_future_timestamp_skew_seconds = 10
    kill_on_taker_fill = True
    kill_on_time_in_force_mismatch = True
    kill_on_unknown_liquidity_fill = True
    fill_markout_horizons_ms = (100, 1_000, 5_000, 30_000)
    fee_snapshot_cache_seconds = 300
    require_exchange_fee_match_live = True
    max_deployment_report_age_seconds = 86_400
    # Floors for the estimator fit diagnostics (mirrored by the estimators'
    # own status gating in scripts/estimator_common.py).
    min_kappa_fit_points = 6
    min_kappa_r2 = 0.30
    min_epsilon_events = 50
    param_update_status_path: str | None = None
    param_snapshot_reload_interval_seconds = 60
    param_update_lock_stale_seconds = 300
    _param_update_lock = threading.Lock()
    _param_update_running: bool = False
    _last_param_update: datetime | None = None
    _last_health_log: datetime | None = None
    _quote_id_sequence: int = 0
    _quote_decisions_count: int = 0
    _accepted_order_attempts: int = 0
    _cancel_open_order_requests: int = 0
    _post_only_rejects: int = 0
    _maker_fill_count: int = 0
    _taker_fill_count: int = 0
    _daily_realized_pnl_usdc: float = 0.0
    _daily_risk_date: str | None = None
    _consecutive_losses: int = 0
    _risk_action_sequence: int = 0

    # Use limit orders for all operations to ensure maker fees
    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'stoploss': 'limit',
        "emergency_exit": "market",
        'stoploss_on_exchange': False
    }

    # Freqtrade 2025.4 rejects Hyperliquid PO at runtime. Keep GTC for
    # research/dry-run startup only; post_only_verified gates any live use.
    order_time_in_force = {
        'entry': 'GTC',
        'exit': 'GTC'
    }

    def _now_utc(self) -> datetime:
        return datetime.now(timezone.utc)

    def _as_utc(self, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    def _parse_utc_timestamp(self, value: Any) -> datetime | None:
        if value is None:
            return None
        if isinstance(value, datetime):
            return self._as_utc(value)
        try:
            if isinstance(value, (int, float)):
                ts = float(value)
                if ts > 1_000_000_000_000:
                    ts /= 1000.0
                return datetime.fromtimestamp(ts, tz=timezone.utc)
            text = str(value).strip()
            if not text:
                return None
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            return self._as_utc(parsed)
        except Exception:
            return None

    def _symbol_from_pair(self, pair: str) -> str:
        return pair.split("/", 1)[0].split(":", 1)[0]

    def _quote_currency_from_pair(self, pair: str) -> str:
        if "/" not in pair:
            return str(getattr(self, "config", {}).get("stake_currency") or "USDC")
        return pair.split("/", 1)[1].split(":", 1)[0]

    def _mm_config(self) -> dict[str, Any]:
        config = getattr(self, "config", {}) or {}
        mm_config = config.get("market_making", {}) if isinstance(config, dict) else {}
        return mm_config if isinstance(mm_config, dict) else {}

    def _param_config_dir(self) -> Path | None:
        raw_dir = self._mm_config().get("param_dir")
        if not raw_dir:
            return None
        return Path(str(raw_dir))

    def _redis_url(self) -> str | None:
        url = self._mm_config().get("redis_url")
        if not url:
            url = os.getenv("REDIS_URL")
        return str(url) if url else None

    def _load_params(self, enforce_file_gate: bool = False) -> tuple[dict, dict, dict]:
        """Load (kappas, epsilons, lambdas).

        Prefers the atomic Redis blob published by the estimator (one consistent
        snapshot, no torn multi-file reads); falls back to the JSON files on disk
        when Redis is not configured / unavailable / empty. Sets _param_source so
        the validation path can skip the file lock when reading from Redis.

        With enforce_file_gate=True (periodic reloads), the file fallback checks
        the estimator lock/status BEFORE and AFTER reading the JSON files and
        raises ParamReloadBlocked if either check fails — the estimator may be
        mid-copy and the three files could mix adjacent cycles. The Redis path
        never needs this (single atomic blob). bot_start keeps the lenient
        default: the initial load tolerates a mid-cycle estimator because every
        quote is gated by _params_are_valid anyway.
        """
        redis_url = self._redis_url()
        if redis_url:
            if not self._param_store_loaded:
                self._param_store = load_param_store()
                self._param_store_loaded = True
            store = self._param_store
            if store is not None:
                try:
                    pairs = self.dp.current_whitelist() if getattr(self, "dp", None) else []
                except Exception:
                    pairs = []
                symbol = self._symbol_from_pair(pairs[0]) if pairs else None
                if symbol:
                    try:
                        blob = store.fetch_params(redis_url, symbol)
                    except Exception:
                        blob = None
                    if isinstance(blob, dict) and all(
                        isinstance(blob.get(k), dict) for k in ("kappa", "epsilon", "lambda")
                    ):
                        self._param_source = "redis"
                        return (
                            {symbol: blob["kappa"]},
                            {symbol: blob["epsilon"]},
                            {symbol: blob["lambda"]},
                        )
        if enforce_file_gate:
            ok, reason = self._param_update_status()
            if not ok:
                raise ParamReloadBlocked(reason)
        loaded = load_configs(start_dir=self._param_config_dir())
        if enforce_file_gate:
            ok, reason = self._param_update_status()
            if not ok:
                raise ParamReloadBlocked(reason)
        # Only flip the provenance marker once a file load is actually committed;
        # a blocked reload must leave the marker describing the params still in
        # memory (possibly Redis-sourced).
        self._param_source = "file"
        return loaded

    def _repo_root(self) -> Path:
        return Path(__file__).resolve().parents[2]

    def _resolve_repo_path(self, raw_path: Any, default_path: str) -> Path:
        path = Path(str(raw_path or default_path))
        if not path.is_absolute():
            path = self._repo_root() / path
        return path

    def _deployment_gate_report_paths(self) -> dict[str, Path]:
        mm_config = self._mm_config()
        return {
            "post_only": self._resolve_repo_path(
                mm_config.get("post_only_evidence_report_path"),
                "docs/post_only_evidence_report.json",
            ),
            "fee": self._resolve_repo_path(
                mm_config.get("fee_evidence_report_path"),
                "docs/fee_evidence_report.json",
            ),
            "replay": self._resolve_repo_path(
                mm_config.get("replay_acceptance_report_path"),
                "docs/replay_acceptance_report.json",
            ),
            "live_canary": self._resolve_repo_path(
                mm_config.get("live_canary_report_path"),
                "docs/live_canary_report.json",
            ),
        }

    def _read_gate_report_status(self, path: Path) -> dict[str, Any]:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {"ok": False, "reason": "missing_report", "path": str(path)}
        except Exception as exc:
            return {"ok": False, "reason": "invalid_report", "path": str(path), "error": str(exc)}
        if not isinstance(payload, dict):
            return {"ok": False, "reason": "invalid_report", "path": str(path)}
        generated_at = payload.get("generated_at")
        generated_at_dt = self._parse_utc_timestamp(generated_at)
        age_seconds = (self._now_utc() - generated_at_dt).total_seconds() if generated_at_dt is not None else None
        max_age = float(self.max_deployment_report_age_seconds)
        max_future_skew = float(self.max_future_timestamp_skew_seconds)
        report_ok = payload.get("ok") is True
        reason = "ok" if report_ok else "report_not_ok"
        ok = bool(report_ok)
        if report_ok and generated_at_dt is None:
            ok = False
            reason = "missing_generated_at"
        elif report_ok and age_seconds is not None and age_seconds < -max_future_skew:
            ok = False
            reason = "future_generated_at"
        elif report_ok and max_age > 0 and age_seconds is not None and age_seconds > max_age:
            ok = False
            reason = "stale_report"
        return {
            "ok": ok,
            "reason": reason,
            "path": str(path),
            "reasons": payload.get("reasons", []),
            "generated_at": generated_at,
            "age_seconds": age_seconds,
            "max_age_seconds": max_age,
        }

    def _live_deployment_gate_state(self) -> tuple[bool, str, dict[str, Any]]:
        mm_config = self._mm_config()
        stage = str(mm_config.get("deployment_stage") or "research").strip().lower()
        payload: dict[str, Any] = {
            "deployment_gate_reports_required": True,
            "deployment_stage": stage,
            "gate_reports": {},
        }
        if stage not in {"canary", "production"}:
            return False, "deployment_stage_not_set", payload

        if stage in {"canary", "production"} and not bool(mm_config.get("manual_monitoring_ack", False)):
            return False, "manual_monitoring_not_acknowledged", payload

        required = ["post_only", "fee", "replay"]
        if stage == "production":
            required.append("live_canary")

        reports = self._deployment_gate_report_paths()
        for name in required:
            status = self._read_gate_report_status(reports[name])
            payload["gate_reports"][name] = status
            if not status.get("ok"):
                return False, f"{name}_gate_not_passed", payload

        return True, "ok", payload

    def _apply_runtime_safety_config(self) -> None:
        mm_config = self._mm_config()
        if not mm_config:
            return

        # Role comes from config.long.json / config.short.json, layered over the
        # shared config.json. The class default stays long-only so an instance
        # started without a role config cannot short by accident.
        if "role" in mm_config:
            role = str(mm_config.get("role") or "").strip().lower()
            if role in ("long", "short"):
                self.role = role
            else:
                self._debug_log_event(
                    "runtime_config_rejected",
                    {"key": "role", "value": mm_config.get("role"), "reason": "unknown_role"},
                )
        if "can_short" in mm_config:
            self.can_short = bool(mm_config.get("can_short"))
        if self.can_short != (self.role == "short"):
            # These two must agree or the guards contradict each other: the role
            # decides which side is quoted, can_short decides which exposure is a
            # fault. Fail closed rather than guess which one the operator meant.
            self._debug_log_event(
                "runtime_config_rejected",
                {
                    "key": "role",
                    "role": self.role,
                    "can_short": bool(self.can_short),
                    "reason": "role_and_can_short_disagree",
                },
            )
            self._trigger_kill_switch("role_and_can_short_disagree", {"role": self.role})
        if "post_only_verified" in mm_config:
            self.post_only_verified = bool(mm_config.get("post_only_verified"))
        if "param_update_status_path" in mm_config:
            self.param_update_status_path = str(mm_config.get("param_update_status_path") or "")
        elif self._param_config_dir() is not None:
            self.param_update_status_path = str(self._param_config_dir() / "param_update_status.json")
        if "kill_on_unknown_liquidity_fill" in mm_config:
            self.kill_on_unknown_liquidity_fill = bool(mm_config.get("kill_on_unknown_liquidity_fill"))
        # The maker fee is exchange- and tier-dependent. The class default
        # (0.00015) reflects Hyperliquid's documented base perp maker fee, but
        # the live CCXT connector / account tier can differ, and the fee gate
        # fail-closes on any mismatch. Allow operators to align the strategy fee
        # with what their exchange actually reports via market_making.maker_fee_rate.
        if "maker_fee_rate" in mm_config:
            try:
                self.fees_maker_HL = float(mm_config["maker_fee_rate"])
            except Exception:
                self._debug_log_event(
                    "runtime_config_rejected",
                    {"key": "maker_fee_rate", "value": mm_config.get("maker_fee_rate"), "reason": "non_numeric"},
                )
        if "spread_multiplier" in mm_config:
            try:
                value = float(mm_config["spread_multiplier"])
                if not np.isfinite(value) or value <= 0:
                    raise ValueError("spread_multiplier must be a positive finite number")
                self.spread_multiplier = value
            except Exception:
                self._debug_log_event(
                    "runtime_config_rejected",
                    {"key": "spread_multiplier", "value": mm_config.get("spread_multiplier"), "reason": "invalid"},
                )
        prior_min_bps = float(self.min_half_spread_bps)
        prior_max_bps = float(self.max_half_spread_bps)
        for bps_key in ("min_half_spread_bps", "max_half_spread_bps"):
            if bps_key in mm_config:
                try:
                    value = float(mm_config[bps_key])
                    if not np.isfinite(value) or value <= 0:
                        raise ValueError(f"{bps_key} must be a positive finite number")
                    setattr(self, bps_key, value)
                except Exception:
                    self._debug_log_event(
                        "runtime_config_rejected",
                        {"key": bps_key, "value": mm_config.get(bps_key), "reason": "invalid"},
                    )
        if float(self.min_half_spread_bps) >= float(self.max_half_spread_bps):
            self._debug_log_event(
                "runtime_config_rejected",
                {
                    "key": "half_spread_bps_bounds",
                    "value": {
                        "min_half_spread_bps": float(self.min_half_spread_bps),
                        "max_half_spread_bps": float(self.max_half_spread_bps),
                    },
                    "reason": "min_not_below_max",
                },
            )
            self.min_half_spread_bps = prior_min_bps
            self.max_half_spread_bps = prior_max_bps
        for numeric_key in (
            "max_param_age_seconds",
            "max_collector_age_seconds",
            "max_book_age_seconds",
            "max_toxicity",
            "collector_timestamp_cache_seconds",
            "collector_timestamp_newest_files_per_stream",
            "max_deployment_report_age_seconds",
            "param_snapshot_reload_interval_seconds",
            "param_update_lock_stale_seconds",
            "gamma_inventory_risk",
            "extra_cushion_bps",
            "hjb_phi_kappa_t",
            "hjb_phi_kappa_t_max",
            "hjb_alpha_kappa",
            "max_daily_loss_usdc",
            "max_consecutive_losses",
            "min_kappa_fit_points",
            "min_kappa_r2",
            "min_epsilon_events",
        ):
            if numeric_key in mm_config:
                try:
                    setattr(self, numeric_key, float(mm_config[numeric_key]))
                except Exception:
                    self._debug_log_event(
                        "runtime_config_rejected",
                        {"key": numeric_key, "value": mm_config.get(numeric_key), "reason": "non_numeric"},
                    )

        if "trading_enabled" not in mm_config:
            return

        requested_enabled = bool(mm_config.get("trading_enabled"))
        is_dry_run = bool(getattr(self, "config", {}).get("dry_run", True))
        ok, reason = self._config_fee_state_valid()
        if requested_enabled and not ok:
            self.trading_enabled = False
            self.fail_closed_reason = reason
            self._debug_log_event(
                "trading_enable_rejected",
                {"reason": reason, "dry_run": is_dry_run},
            )
            return

        if requested_enabled and not is_dry_run and not self.post_only_verified:
            self.trading_enabled = False
            self.fail_closed_reason = "post_only_not_verified"
            self._debug_log_event(
                "trading_enable_rejected",
                {"reason": "post_only_not_verified", "dry_run": is_dry_run},
            )
            return

        if requested_enabled and not is_dry_run and self.post_only_verified:
            ok, reason, tif_payload = self._configured_post_only_tif_valid()
            if not ok:
                self.trading_enabled = False
                self.fail_closed_reason = reason
                self._debug_log_event(
                    "trading_enable_rejected",
                    {"reason": reason, "dry_run": is_dry_run, **tif_payload},
                )
                return
            ok, reason, gate_payload = self._live_deployment_gate_state()
            if not ok:
                self.trading_enabled = False
                self.fail_closed_reason = reason
                self._debug_log_event(
                    "trading_enable_rejected",
                    {"reason": reason, "dry_run": is_dry_run, **gate_payload},
                )
                return

        self.trading_enabled = requested_enabled
        self.fail_closed_reason = "none" if self.trading_enabled else "initial_safety_lock"

    def bot_start(self, **kwargs) -> None:
        """
        Called only once after bot instantiation.
        :param **kwargs: Ensure to keep this here so updates to this won't break your strategy.
        """
        logger.info('Loading market making parameters (Epsilon and Kappa)')
        # Freqtrade does not set `self.exchange` on the strategy; the exchange
        # object (with price_to_precision / amount_to_precision / markets) is
        # only reachable via the DataProvider. Without it, tick/lot rounding in
        # _round_quote_price/_round_quote_amount silently no-ops and quotes go
        # out unrounded. Wire it up here (guarded so tests can inject a stub).
        if getattr(self, "exchange", None) is None:
            self.exchange = getattr(self.dp, "_exchange", None)
            if self.exchange is None:
                logger.warning(
                    "Exchange handle unavailable from DataProvider; "
                    "price/amount rounding will be skipped."
                )
        pairs = self.dp.current_whitelist()
        if len(pairs) != 1:
            logger.error('Strategy requires exactly one trading pair')
            sys.exit()
        symbol = self._symbol_from_pair(pairs[0])
        logger.info(f"Trading symbol: {symbol}")
        self._apply_runtime_safety_config()
        self.kappas, self.epsilons, self.lambdas = self._load_params()
        logger.info(f"Parameter source: {self._param_source}")
        logger.info(f'Loaded kappa values: {self.kappas}')
        logger.info(f'Loaded epsilon values: {self.epsilons}')
        logger.info(f'Loaded lambda values: {self.lambdas}')
        if not self.use_asymmetric_kappa:
            logger.warning("Forcing use_asymmetric_kappa=True (always use kappa+/kappa-).")
            self.use_asymmetric_kappa = True
        if self.hjb_solver is None:
            self.hjb_solver = load_hjb_solver()
        logger.info(f"HJB module loaded: {self.hjb_solver is not None}")
        if self._episodic():
            self._start_episode("bot_start")
            logger.info(
                "HJB time mode: episodic (T=%.1fs, reset_on_flat=%s)",
                float(self.hjb_horizon_seconds),
                bool(self.hjb_episode_reset_on_flat),
            )
        else:
            logger.info("HJB time mode: stationary (t=0 slice only)")
        self._refresh_hjb(pairs[0])
        self._log_health(pairs[0], self._now_utc())

    def bot_loop_start(self, current_time: datetime, **kwargs) -> None:
        """
        Called at the start of each bot iteration to refresh market making parameters.
        
        :param current_time: Current datetime
        :param **kwargs: Additional arguments
        """
        pairs = self.dp.current_whitelist()
        pair = pairs[0] if pairs else None
        now = self._as_utc(current_time) or self._now_utc()
        if pair:
            self._process_pending_fill_markouts(pair, now)
            # Roll the episode clock BEFORE publishing, so the heartbeat carries
            # the clock this cycle will actually quote on. Wrapped because the
            # publish below must never be blocked by it: a leg that stops
            # publishing makes staleness mutual and the pair never recovers.
            try:
                q_net, _ = self._net_inventory(pair)
                self._advance_episode_clock(q_net, now)
            except Exception as exc:
                self._debug_log_event(
                    "episode_clock_failed", {"pair": pair, "error": str(exc)}
                )
            # Published before anything can return early, and never gated on
            # this instance's own willingness to quote -- a leg that stops
            # publishing makes staleness mutual and the pair never recovers.
            self._publish_inventory_heartbeat(pair)
            self._resize_inventory_unit(pair, self.get_mid_price(pair, 0.0))
            self._log_health(pair, now)
        else:
            self._debug_log_event("param_update_skipped", {"reason": "no_pair"})
            return

        if bool(self._mm_config().get("run_estimators_in_strategy", False)):
            self._debug_log_event(
                "param_update_skipped",
                {"reason": "internal_estimator_disabled_use_sidecar"},
            )

        if self._param_update_running:
            self._debug_log_event("param_update_skipped", {"reason": "estimator_running"})
            return
        if self._last_param_update and (
            now - self._last_param_update
        ) < timedelta(seconds=float(self.param_snapshot_reload_interval_seconds)):
            return

        acquired = self._param_update_lock.acquire(blocking=False)
        if not acquired:
            self._debug_log_event("param_update_skipped", {"reason": "estimator_lock_busy"})
            return

        self._param_update_running = True
        try:
            # _load_params prefers the atomic Redis blob (no file lock needed)
            # and only gates on the estimator lock/status when it actually falls
            # back to reading the JSON files (enforce_file_gate=True). This way
            # Redis reloads are never blocked by a mid-cycle estimator, while a
            # Redis-configured-but-unavailable setup still gets the torn-read
            # protection on the file fallback.
            old_source = self._param_source
            try:
                new_kappas, new_epsilons, new_lambdas = self._load_params(enforce_file_gate=True)
            except ParamReloadBlocked as blocked:
                self._debug_log_event("param_update_skipped", {"pair": pair, "reason": blocked.reason})
                return
            logger.info('Reloading market making parameter snapshots')
            self._last_param_update = now
            old_params = (self.kappas, self.epsilons, self.lambdas)
            self.kappas, self.epsilons, self.lambdas = new_kappas, new_epsilons, new_lambdas
            if pair:
                ok, reason = self._params_are_valid(pair)
                if not ok:
                    self.kappas, self.epsilons, self.lambdas = old_params
                    self._param_source = old_source
                    self._debug_log_event("param_update_rejected", {"pair": pair, "reason": reason})
                    logger.warning(f"Parameter refresh rejected ({reason}); keeping last known values.")
                    return
            logger.info(f'Reloaded kappa values: {self.kappas}')
            logger.info(f'Reloaded epsilon values: {self.epsilons}')
            logger.info(f'Reloaded lambda values: {self.lambdas}')
            if not self.use_asymmetric_kappa:
                logger.warning("Forcing use_asymmetric_kappa=True (always use kappa+/kappa-).")
                self.use_asymmetric_kappa = True
            if pair:
                self._refresh_hjb(pair)
        except Exception as exc:
            self._debug_log_event("param_update_failed", {"error": str(exc)})
            logger.warning(f"Parameter refresh failed; keeping last known values: {exc}")
        finally:
            self._param_update_running = False
            self._param_update_lock.release()

    def informative_pairs(self):
        """
        No additional informative pairs required for this market making strategy.
        """
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        No technical indicators needed for pure market making strategy.
        """
        return dataframe

    def _collector_symbol_dir(self, symbol: str) -> Path:
        candidates = [
            Path("/freqtrade/scripts/HL_data") / symbol,
            Path(__file__).resolve().parents[2] / "scripts" / "HL_data" / symbol,
            Path.cwd() / "scripts" / "HL_data" / symbol,
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate
        return candidates[0]

    def _latest_parquet_timestamp(self, path: Path) -> datetime | None:
        try:
            frame = pd.read_parquet(path, columns=["timestamp"])
        except Exception as exc:
            self._debug_log_event(
                "collector_data_read_error",
                {"path": str(path), "reason": str(exc)},
            )
            return None

        if frame.empty or "timestamp" not in frame:
            return None

        series = frame["timestamp"].dropna()
        if series.empty:
            return None

        try:
            if pd.api.types.is_numeric_dtype(series):
                numeric = pd.to_numeric(series, errors="coerce").dropna()
                if numeric.empty:
                    return None
                return self._parse_utc_timestamp(float(numeric.max()))

            parsed = pd.to_datetime(series, utc=True, errors="coerce").dropna()
            if parsed.empty:
                return None
            return self._as_utc(parsed.max().to_pydatetime())
        except Exception as exc:
            self._debug_log_event(
                "collector_data_timestamp_error",
                {"path": str(path), "reason": str(exc)},
            )
            return None

    def _collector_stream_timestamps(self, symbol: str) -> dict[str, datetime | None]:
        now = self._now_utc()
        cache = getattr(self, "_collector_timestamp_cache", None)
        if not isinstance(cache, dict):
            cache = {}
            self._collector_timestamp_cache = cache
        cached = cache.get(symbol)
        if isinstance(cached, dict):
            checked_at = self._as_utc(cached.get("checked_at"))
            if (
                checked_at is not None
                and (now - checked_at).total_seconds() <= float(self.collector_timestamp_cache_seconds)
                and isinstance(cached.get("stream_timestamps"), dict)
            ):
                return {
                    str(stream): self._as_utc(ts)
                    for stream, ts in cached.get("stream_timestamps", {}).items()
                }

        base = self._collector_symbol_dir(symbol)
        stream_timestamps: dict[str, datetime | None] = {}
        for sub_dir in self.collector_required_streams:
            target_dir = base / sub_dir
            if not target_dir.is_dir():
                stream_timestamps[sub_dir] = None
                continue
            newest: datetime | None = None
            shards = list(target_dir.glob("*.parquet"))
            # Order by the flush timestamp in the filename ("<dtype>_<ms>.parquet")
            # rather than by os.stat(). Sorting by mtime stats EVERY shard on
            # every freshness check: at a 5s cache and 3-day retention that is
            # ~26k stat calls per stream per check on a bind mount, so the cost
            # of this scan grew with RETENTION_MINUTES even though only the
            # newest few shards are ever read. Names that cannot be parsed sort
            # last and fall back to mtime, so nothing is silently skipped.
            def _shard_sort_key(path: Path) -> float:
                stem = path.stem
                if "_" in stem:
                    try:
                        return float(stem.rsplit("_", 1)[1])
                    except ValueError:
                        pass
                try:
                    return path.stat().st_mtime * 1000.0
                except OSError:
                    return float("-inf")

            shards = sorted(shards, key=_shard_sort_key, reverse=True)
            try:
                scan_limit = int(self.collector_timestamp_newest_files_per_stream)
            except Exception:
                scan_limit = 5
            if scan_limit > 0:
                shards = shards[:scan_limit]
            for shard in shards:
                ts = self._latest_parquet_timestamp(shard)
                if ts is None:
                    continue
                if newest is None or ts > newest:
                    newest = ts
            stream_timestamps[sub_dir] = newest
        latest = max(
            (ts for ts in stream_timestamps.values() if ts is not None),
            default=None,
        )
        cache[symbol] = {
            "checked_at": now,
            "latest_ts": latest,
            "stream_timestamps": stream_timestamps,
        }
        return dict(stream_timestamps)

    def _latest_collector_timestamp(self, symbol: str) -> datetime | None:
        stream_timestamps = self._collector_stream_timestamps(symbol)
        newest = max(
            (ts for ts in stream_timestamps.values() if ts is not None),
            default=None,
        )
        return newest

    def _collector_age_seconds(self, symbol: str, now: datetime | None = None) -> float | None:
        stream_timestamps = self._collector_stream_timestamps(symbol)
        present = [ts for ts in stream_timestamps.values() if ts is not None]
        if not present:
            return None
        reference = self._as_utc(now) or self._now_utc()
        return max(0.0, max((reference - ts).total_seconds() for ts in present))

    def _market_data_fresh(self, symbol: str, max_age_seconds: int | None = None) -> tuple[bool, str]:
        max_age = int(max_age_seconds or getattr(self, "max_collector_age_seconds", 30))
        stream_timestamps = self._collector_stream_timestamps(symbol)
        missing = [stream for stream in self.collector_required_streams if stream_timestamps.get(stream) is None]
        if len(missing) == len(tuple(self.collector_required_streams)):
            return False, "no_collector_data"

        if missing:
            return False, "missing_collector_streams:" + ",".join(missing)

        reference = self._now_utc()
        stale: list[tuple[str, float]] = []
        for stream in self.collector_required_streams:
            ts = stream_timestamps.get(stream)
            if ts is None:
                continue
            age = max(0.0, (reference - ts).total_seconds())
            if age > max_age:
                stale.append((stream, age))

        if stale:
            stream, age = max(stale, key=lambda item: item[1])
            return False, f"collector_data_stale_{stream}_{age:.1f}s"

        return True, "ok"

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Emit a one-candle passive bid signal only when the model is ready.
        """
        dataframe.loc[:, 'enter_long'] = 0
        dataframe.loc[:, 'enter_short'] = 0
        if dataframe.empty:
            return dataframe
        pair = metadata.get("pair", "")
        if not self.trading_enabled:
            return dataframe
        if not self._model_ready(pair):
            return dataframe

        # The short leg OPENS with an ask (adding short exposure); the long leg
        # opens with a bid. Each leg rests one side per cycle, and which side
        # that is comes from the pair's routing rule, not from here.
        if self.can_short:
            if not self._inventory_allows_ask(pair):
                return dataframe
            if self._inventory_level(pair) != 0:
                return dataframe
            dataframe.loc[dataframe.index[-1], 'enter_short'] = 1
            dataframe.loc[dataframe.index[-1], 'enter_tag'] = "mm_ask"
            return dataframe

        if not self._inventory_allows_bid(pair):
            return dataframe
        # freqtrade suppresses an exit signal whenever an entry signal is on the
        # same candle (interface.py: `exit_ and not enter`), so an instance may
        # not emit an entry while it needs the exit side. Inventory beyond the
        # first unit is added through adjust_trade_position instead.
        if self._inventory_level(pair) != 0:
            return dataframe
        dataframe.loc[dataframe.index[-1], 'enter_long'] = 1
        dataframe.loc[dataframe.index[-1], 'enter_tag'] = "mm_bid"
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Emit a one-candle passive ask signal only when inventory can be unwound.
        """
        dataframe.loc[:, 'exit_long'] = 0
        dataframe.loc[:, 'exit_short'] = 0
        if dataframe.empty:
            return dataframe
        pair = metadata.get("pair", "")
        if not self.trading_enabled:
            return dataframe
        if not self._model_ready(pair):
            return dataframe

        # Mirror image of the entry side: the short leg CLOSES with a bid
        # (covering), the long leg closes with an ask.
        if self.can_short:
            if not self._inventory_allows_bid(pair):
                return dataframe
            dataframe.loc[dataframe.index[-1], 'exit_short'] = 1
            dataframe.loc[dataframe.index[-1], 'exit_tag'] = "mm_bid"
            return dataframe

        if not self._inventory_allows_ask(pair):
            return dataframe
        dataframe.loc[dataframe.index[-1], 'exit_long'] = 1
        dataframe.loc[dataframe.index[-1], 'exit_tag'] = "mm_ask"
        return dataframe
    
    def get_mid_price(self, pair: str, fallback_rate: float) -> float:
        """
        Calculate mid price from first order book bid and ask.
        
        :param pair: Trading pair
        :param fallback_rate: Rate to use if orderbook is not available
        :return: Mid price
        """
        orderbook = self.dp.orderbook(pair, maximum=1)
        try:
            if orderbook and orderbook.get('bids') and orderbook.get('asks'):
                best_bid = float(orderbook['bids'][0][0])
                best_ask = float(orderbook['asks'][0][0])
                if best_bid > 0 and best_ask > 0 and best_bid < best_ask:
                    return (best_bid + best_ask) / 2
        except Exception:
            pass
        return fallback_rate
    
    def _refresh_hjb(self, pair: str) -> None:
        """
        Compute HJB surface using latest λ/κ/ε (asymmetric κ+/κ-).
        Keeps the last known-good cache if refresh fails.
        """
        symbol = self._symbol_from_pair(pair)
        try:
            kappa_p = float(self.kappas[symbol]["kappa+"])
            kappa_m = float(self.kappas[symbol]["kappa-"])
            epsilon_p = float(self.epsilons[symbol]["epsilon+"])
            epsilon_m = float(self.epsilons[symbol]["epsilon-"])
            lambda_p = float(self.lambdas.get(symbol, {}).get("lambda+", 0.0)) if isinstance(self.lambdas, dict) else 0.0
            lambda_m = float(self.lambdas.get(symbol, {}).get("lambda-", 0.0)) if isinstance(self.lambdas, dict) else 0.0
            params_snapshot = self._params_snapshot(symbol)
            params_fingerprint = self._params_fingerprint(params_snapshot)
        except Exception as e:
            logger.warning(f"HJB refresh skipped (missing/invalid params for {symbol}): {e}")
            self._debug_log_event(
                "hjb_refresh_skipped",
                {"pair": pair, "symbol": symbol, "reason": "missing_or_invalid_params", "error": str(e)},
            )
            return

        hjb_mod = self.hjb_solver
        if hjb_mod is None:
            hjb_mod = load_hjb_solver()
            self.hjb_solver = hjb_mod
        if hjb_mod is None:
            if not self._hjb_import_error_logged:
                logger.error("HJB module not available (could not import / load scripts/hjb.py). Trading will stay disabled.")
                self._debug_log_event(
                    "hjb_unavailable",
                    {"pair": pair, "symbol": symbol, "reason": "module_load_failed"},
                )
                self._hjb_import_error_logged = True
            return
        if self._mm_core is None:
            logger.error("mm_core unavailable; cannot solve the HJB. Trading stays disabled.")
            self._debug_log_event(
                "hjb_unavailable",
                {"pair": pair, "symbol": symbol, "reason": "mm_core_load_failed"},
            )
            return
        # mm_core picks and calls the solver; this only checks the module the
        # operator expects is actually present, and names it for telemetry.
        solver_name = "compute_h_asymmetric" if self.use_asymmetric_kappa else "compute_h_symmetric"
        if getattr(hjb_mod, solver_name, None) is None:
            logger.error(f"HJB solver function not found: {solver_name}")
            self._debug_log_event(
                "hjb_unavailable",
                {"pair": pair, "symbol": symbol, "reason": "solver_not_found", "solver": solver_name},
            )
            return

        # sigma2 feeds mm_core's volatility channel, which is additive on top of
        # the kappa-derived base phi. A missing or invalid value simply omits that
        # term -- it must never stop quoting.
        phi_base = float(self.hjb_phi)
        sigma2_per_sec = None
        try:
            sigma2_raw = self.kappas[symbol].get("sigma2_per_sec")
            if sigma2_raw is not None:
                sigma2_candidate = float(sigma2_raw)
                if np.isfinite(sigma2_candidate) and sigma2_candidate >= 0:
                    sigma2_per_sec = sigma2_candidate
        except Exception:
            sigma2_per_sec = None

        try:
            # Delegate to mm_core rather than calling the solver directly: it is
            # what derives phi/alpha from live kappa (they are NOT kappa-invariant,
            # see eq. 10.28), and duplicating that here is how the two paths drift.
            hjb_res = self._mm_core.solve_hjb(
                {
                    "kappa+": kappa_p,
                    "kappa-": kappa_m,
                    "epsilon+": epsilon_p,
                    "epsilon-": epsilon_m,
                    "lambda+": lambda_p,
                    "lambda-": lambda_m,
                },
                self._quote_config(),
                sigma2_per_sec=sigma2_per_sec,
            )
            phi_effective = float(hjb_res.get("phi_effective", phi_base))
            phi_source = str(hjb_res.get("phi_source", "phi_base_fallback"))
            self.hjb_cache = hjb_res
            self._hjb_generation += 1
            self._hjb_params_snapshot = params_snapshot
            self._hjb_param_fingerprint = params_fingerprint
            self._hjb_last_refresh_dt = self._now_utc()
            self._hjb_last_refresh_ts = self._hjb_last_refresh_dt.isoformat(timespec="milliseconds").replace("+00:00", "Z")
            self._debug_log_event(
                "hjb_refresh",
                {
                    "pair": pair,
                    "symbol": symbol,
                    "solver": solver_name,
                    "inputs": {
                        "lambda_plus": lambda_p,
                        "lambda_minus": lambda_m,
                        "kappa_plus": kappa_p,
                        "kappa_minus": kappa_m,
                        "epsilon_plus": epsilon_p,
                        "epsilon_minus": epsilon_m,
                        # What the solve ACTUALLY used, not the raw fallback:
                        # alpha is derived from live kappa and differs by orders
                        # of magnitude from hjb_alpha.
                        "alpha": float(hjb_res.get("alpha_effective", self.hjb_alpha)),
                        "kappa_avg": hjb_res.get("kappa_avg"),
                        "phi": float(phi_effective),
                        "phi_base": float(phi_base),
                        "phi_effective": float(phi_effective),
                        "phi_source": phi_source,
                        "sigma2_per_sec": sigma2_per_sec,
                        "gamma_inventory_risk": float(self.gamma_inventory_risk),
                        "T_seconds": float(self.hjb_horizon_seconds),
                        "q_max": int(self.hjb_q_max),
                    },
                    "params": params_snapshot,
                    "param_fingerprint": params_fingerprint,
                    "hjb_generation": self._hjb_generation,
                    "hjb_last_refresh_ts": self._hjb_last_refresh_ts,
                    "hjb": self._hjb_snapshot(),
                },
            )
        except Exception as e:
            logger.error(f"Failed to compute HJB surfaces: {e}")
            self._debug_log_event(
                "hjb_refresh_failed",
                {"pair": pair, "symbol": symbol, "solver": solver_name, "error": str(e)},
            )
            # Keep last known-good cache (no static fallback).
            return

    def _inventory_level(self, pair: str) -> int:
        """
        Long-only inventory unit, based on signed base exposure.
        """
        signed_base = self._signed_base_position(pair)
        # The kill switch stays here, on the strategy's OWN exposure: it is a
        # safety check about this account, not a pricing input.
        if self._reject_unexpected_short_position(pair, signed_base):
            return 0
        # The mapping itself is shared with the replay via mm_core. allow_short
        # follows can_short, so a long-only instance still clamps to [0, q_max].
        return self._mm_core.inventory_to_q(signed_base, self._quote_config())

    def _pricing_state(self, pair: str) -> tuple[int, float, float | None]:
        """(integer q, exact q, time-to-go) -- everything a depth lookup needs.

        One helper rather than five copies, because the two coordinates are easy
        to get subtly wrong on their own:

        - ``q`` is rounded because eq. 10.2 is a unit-jump process and the HJB
          grid is integer. Routing, boundary tests and the peer heartbeat all
          speak this. ``q_exact`` is what is really held -- a partial fill lands
          between grid points, and rounding it away hides up to half a unit of
          live risk (0.49 units reads as flat). Depths price off q_exact.
        - ``tau`` is None in stationary mode, which tells mm_core to read the
          t=0 slice: what every call site did before the surface existed.

        Both q values come from ONE position read, so they cannot disagree.
        """
        signed_base = self._signed_base_position(pair)
        if self._reject_unexpected_short_position(pair, signed_base):
            q_exact = 0.0
        else:
            q_exact = self._mm_core.inventory_to_q_exact(signed_base, self._quote_config())
        return int(round(q_exact)), float(q_exact), self._tau_remaining()

    def _pricing_state_payload(self, pair: str) -> dict[str, Any]:
        """The pricing coordinates, flattened for telemetry.

        ``q_residual`` is the part of the position the integer grid cannot
        represent. A persistently non-zero value means partial fills are leaving
        risk the model is not pricing, which is invisible in ``q`` alone.
        """
        try:
            q, q_exact, tau = self._pricing_state(pair)
        except Exception:
            return {
                "q": None,
                "q_exact": None,
                "q_residual": None,
                "tau_remaining_seconds": None,
                "episode_id": int(self._episode_id),
                "hjb_time_mode": str(self.hjb_time_mode),
            }
        return {
            "q": int(q),
            "q_exact": float(q_exact),
            "q_residual": float(q_exact) - float(q),
            "tau_remaining_seconds": None if tau is None else float(tau),
            "episode_id": int(self._episode_id),
            "hjb_time_mode": str(self.hjb_time_mode),
        }

    # ---- episode clock (hjb_time_mode="episodic") ----

    def _episodic(self) -> bool:
        return str(self.hjb_time_mode) == "episodic"

    def _episode_elapsed(self, now: datetime | None = None) -> float:
        now = now or self._now_utc()
        if self._episode_start_dt is None:
            self._episode_start_dt = now
            return 0.0
        return max(0.0, (now - self._episode_start_dt).total_seconds())

    def _tau_remaining(self, now: datetime | None = None) -> float | None:
        """Seconds left in the current episode, or None in stationary mode.

        None is the signal that mm_core should read the t=0 slice, which is what
        every caller did unconditionally before the surface existed.
        """
        if not self._episodic():
            return None
        horizon = float(self.hjb_horizon_seconds)
        return max(0.0, horizon - self._episode_elapsed(now))

    def _start_episode(self, reason: str, now: datetime | None = None) -> None:
        now = now or self._now_utc()
        self._episode_id = int(self._episode_id) + 1
        self._episode_start_dt = now
        self._debug_log_event(
            "episode_started",
            {
                "role": self.role,
                "episode_id": int(self._episode_id),
                "episode_start": now.isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                "reason": reason,
                "horizon_seconds": float(self.hjb_horizon_seconds),
            },
        )

    def _advance_episode_clock(self, q_net: int | None, now: datetime | None = None) -> None:
        """Roll the episode over when it expires, or once flat and old enough.

        The book liquidates whatever is left at T and pays alpha*q^2. We cannot:
        every quote here is post-only by construction, so taking liquidity to
        flatten would contradict the rest of the design. The terminal condition
        therefore acts through the depths alone and the clock simply restarts.
        That is a named departure -- see docs/UNITS.md -- not an oversight.
        """
        if not self._episodic():
            return
        now = now or self._now_utc()
        elapsed = self._episode_elapsed(now)
        horizon = float(self.hjb_horizon_seconds)
        if elapsed >= horizon:
            self._start_episode("horizon_elapsed", now)
            return
        if not self.hjb_episode_reset_on_flat or q_net is None or int(q_net) != 0:
            return
        # Restarting the moment inventory touches zero would pin the clock near
        # t=0 forever: a round trip completes in seconds and the horizon would
        # never advance far enough for the terminal slice to matter.
        if elapsed >= horizon * float(self.hjb_episode_min_elapsed_fraction):
            self._start_episode("flat_inventory", now)

    def _adopt_peer_episode(self, peer: dict[str, Any] | None) -> str | None:
        """Converge the two legs onto one episode clock.

        Both legs price the SAME net inventory, so a clock disagreement means
        one leg quotes a 140s-to-go surface while the other quotes 20s-to-go and
        the pair is internally inconsistent. Lowest episode_id wins: it is a pure
        function of the exchanged state, needing no negotiation, in the same
        style as route_sides. Returns the reason it moved, or None.
        """
        if not self._episodic() or not isinstance(peer, dict):
            return None
        peer_id = self._mm_core.finite_float_or_none(peer.get("episode_id"))
        peer_start = self._mm_core.parse_utc_timestamp(peer.get("episode_start"))
        if peer_id is None or peer_start is None:
            return None
        if int(peer_id) >= int(self._episode_id):
            return None
        self._episode_id = int(peer_id)
        self._episode_start_dt = peer_start
        return "adopted_peer_episode"

    def _reject_unexpected_short_position(self, pair: str, signed_base: float | None = None) -> bool:
        """Kill-switch on exposure pointing the wrong way for this role.

        Mirrored, not removed: the long leg still dies on a short position, and
        the short leg dies on a LONG one. Removing the check for the short leg
        would leave it with no wrong-way guard at all, which is the failure this
        function exists to prevent.

        Deliberately evaluated on this instance's OWN exposure, never on net
        inventory across the pair: net going short is the normal state of a
        working two-sided maker, and killing the long leg for it would take the
        pair down every time the short leg did its job.
        """
        if signed_base is None:
            signed_base = self._signed_base_position(pair)
        signed_base = float(signed_base)

        if self.can_short:
            if signed_base <= 0:
                return False
            reason = "unexpected_long_position"
        else:
            if signed_base >= 0:
                return False
            reason = "unexpected_short_position"

        payload = {
            "pair": pair,
            "signed_base_position": signed_base,
            "role": "short" if self.can_short else "long",
        }
        if self.fail_closed_reason != reason:
            self._trigger_kill_switch(reason, payload)
        return True

    def _signed_base_position(self, pair: str) -> float:
        exchange_position = self._signed_base_position_from_exchange(pair)
        if exchange_position is not None:
            return float(exchange_position)

        signed_base = 0.0
        try:
            open_trades = Trade.get_trades_proxy(is_open=True, pair=pair)
            for trade in open_trades:
                amount = abs(float(getattr(trade, "amount", 0.0) or 0.0))
                if bool(getattr(trade, "is_short", False)):
                    signed_base -= amount
                else:
                    signed_base += amount
        except Exception:
            pass
        if signed_base == 0.0:
            wallet_position = self._signed_base_position_from_wallet(pair)
            if wallet_position is not None:
                return float(wallet_position)
        return float(signed_base)

    def _signed_base_position_from_exchange(self, pair: str) -> float | None:
        exchange = getattr(self, "exchange", None)
        if exchange is None or not hasattr(exchange, "fetch_positions"):
            return None
        try:
            positions = exchange.fetch_positions([pair])
        except Exception:
            try:
                positions = exchange.fetch_positions()
            except Exception:
                return None

        symbol = self._symbol_from_pair(pair)
        for position in positions or []:
            if not isinstance(position, dict):
                continue
            info = position.get("info", {}) if isinstance(position.get("info", {}), dict) else {}
            identifiers = [
                position.get("symbol"),
                position.get("pair"),
                info.get("coin") if isinstance(info, dict) else None,
                info.get("symbol") if isinstance(info, dict) else None,
            ]
            if not any(value and (str(value) == pair or str(value).split("/", 1)[0] == symbol) for value in identifiers):
                continue

            signed_size = None
            for key in ("szi", "position", "contracts", "contractSize", "size", "amount"):
                value = info.get(key) if isinstance(info, dict) and key in info else position.get(key)
                if value is None:
                    continue
                try:
                    signed_size = float(value)
                    break
                except Exception:
                    continue
            if signed_size is None:
                return None

            side = str(
                position.get("side")
                or position.get("positionSide")
                or (info.get("side") if isinstance(info, dict) else "")
                or ""
            ).lower()
            if side == "short":
                return -abs(float(signed_size))
            if side == "long":
                return abs(float(signed_size))
            return float(signed_size)
        return None

    def _signed_base_position_from_wallet(self, pair: str) -> float | None:
        is_dry_run = bool(getattr(self, "config", {}).get("dry_run", True))
        wallets = getattr(self, "wallets", None)
        if not is_dry_run or wallets is None:
            return None
        symbol = self._symbol_from_pair(pair)
        for method_name in ("get_total", "get_free"):
            method = getattr(wallets, method_name, None)
            if not callable(method):
                continue
            try:
                value = method(symbol)
                if value is not None:
                    return max(0.0, float(value))
            except Exception:
                continue
        return None

    def _inventory_snapshot(self, pair: str) -> dict[str, Any]:
        signed_base = self._signed_base_position(pair)
        return {
            "signed_base_position": float(signed_base),
            "position": float(signed_base),
            "inventory_unit_base": float(self.inventory_unit_base),
            "max_abs_inventory_units": int(self.max_abs_inventory_units),
            # q and the coordinates around it come from the one place that
            # derives them, so a snapshot cannot disagree with what was quoted.
            **self._pricing_state_payload(pair),
        }

    def _account_equity_usdc(self, pair: str) -> float | None:
        config = getattr(self, "config", {}) if isinstance(getattr(self, "config", {}), dict) else {}
        for key in ("available_capital", "dry_run_wallet"):
            try:
                value = config.get(key)
                if value is not None and np.isfinite(float(value)) and float(value) > 0:
                    return float(value)
            except Exception:
                pass

        wallets = getattr(self, "wallets", None)
        if wallets is None:
            return None
        stake_currency = str(config.get("stake_currency") or self._quote_currency_from_pair(pair))
        for method_name in ("get_total", "get_free"):
            method = getattr(wallets, method_name, None)
            if not callable(method):
                continue
            try:
                value = method(stake_currency)
                if value is not None and np.isfinite(float(value)) and float(value) > 0:
                    return float(value)
            except Exception:
                continue
        return None

    def _position_risk_snapshot(
        self,
        pair: str,
        rate: float | None = None,
        side: str | None = None,
        amount: float | None = None,
    ) -> dict[str, Any]:
        signed_base = float(self._signed_base_position(pair))
        quote_side = "bid" if side in {"long", "bid", "entry"} else "ask" if side in {"ask", "exit", "short"} else None
        order_amount = None
        try:
            if amount is not None and np.isfinite(float(amount)) and float(amount) > 0:
                order_amount = float(amount)
        except Exception:
            order_amount = None
        if order_amount is None and quote_side is not None:
            if quote_side == "ask" and signed_base > 0:
                order_amount = min(abs(signed_base), float(self.inventory_unit_base))
            else:
                order_amount = float(self.inventory_unit_base)

        projected_base = signed_base
        if quote_side == "bid" and order_amount is not None:
            projected_base += order_amount
        elif quote_side == "ask" and order_amount is not None:
            projected_base -= order_amount
            if not self.can_short:
                projected_base = max(0.0, projected_base)

        reference_rate = self._finite_float_or_none(rate)
        if reference_rate is None:
            snapshot, _ = self._book_snapshot(pair)
            if snapshot is not None:
                reference_rate = self._finite_float_or_none(snapshot.get("mid"))

        current_notional = None
        projected_notional = None
        if reference_rate is not None and reference_rate > 0:
            current_notional = abs(signed_base) * reference_rate
            projected_notional = abs(projected_base) * reference_rate

        leverage = 1.0
        projected_margin = None
        if projected_notional is not None:
            projected_margin = projected_notional / leverage

        equity = self._account_equity_usdc(pair)
        maintenance_margin = None
        liquidation_buffer = None
        try:
            if projected_notional is not None:
                maintenance_margin = projected_notional * float(self.maintenance_margin_rate)
            if equity is not None and maintenance_margin is not None:
                liquidation_buffer = equity - maintenance_margin
        except Exception:
            maintenance_margin = None
            liquidation_buffer = None

        risk_reducing = abs(projected_base) < abs(signed_base)
        return {
            "signed_base_position": signed_base,
            "projected_base_position": float(projected_base),
            "position_delta_base": float(projected_base - signed_base),
            "risk_reducing": bool(risk_reducing),
            "reference_rate": float(reference_rate) if reference_rate is not None else None,
            "notional_exposure_usdc": float(projected_notional) if projected_notional is not None else None,
            "current_notional_exposure_usdc": float(current_notional) if current_notional is not None else None,
            "max_notional_exposure_usdc": float(self.max_notional_exposure_usdc),
            "margin_used_usdc": float(projected_margin) if projected_margin is not None else None,
            "max_margin_used_usdc": float(self.max_margin_used_usdc),
            "account_equity_usdc": float(equity) if equity is not None else None,
            "maintenance_margin_rate": float(self.maintenance_margin_rate),
            "maintenance_margin_usdc": float(maintenance_margin) if maintenance_margin is not None else None,
            "liquidation_buffer_usdc": float(liquidation_buffer) if liquidation_buffer is not None else None,
            "min_liquidation_buffer_usdc": float(self.min_liquidation_buffer_usdc),
        }

    def _position_risk_valid(
        self,
        pair: str,
        side: str,
        rate: float,
        amount: float | None = None,
    ) -> tuple[bool, str, dict[str, Any]]:
        snapshot = self._position_risk_snapshot(pair, rate=rate, side=side, amount=amount)
        if snapshot.get("reference_rate") is None:
            return False, "risk_rate_unavailable", snapshot

        if snapshot.get("risk_reducing") is True:
            return True, "ok", snapshot

        notional = snapshot.get("notional_exposure_usdc")
        if (
            notional is not None
            and float(self.max_notional_exposure_usdc) > 0
            and float(notional) > float(self.max_notional_exposure_usdc)
        ):
            return False, "notional_exposure_limit_reached", snapshot

        margin_used = snapshot.get("margin_used_usdc")
        if (
            margin_used is not None
            and float(self.max_margin_used_usdc) > 0
            and float(margin_used) > float(self.max_margin_used_usdc)
        ):
            return False, "margin_limit_reached", snapshot

        config = getattr(self, "config", {}) if isinstance(getattr(self, "config", {}), dict) else {}
        is_dry_run = bool(config.get("dry_run", True))
        min_buffer = float(self.min_liquidation_buffer_usdc)
        if not is_dry_run and min_buffer > 0:
            buffer_value = snapshot.get("liquidation_buffer_usdc")
            if buffer_value is None:
                return False, "liquidation_buffer_unknown", snapshot
            if float(buffer_value) < min_buffer:
                return False, "liquidation_buffer_too_low", snapshot

        return True, "ok", snapshot

    def _no_delta_reason(self) -> str:
        """Why there is no usable depth here: no model, or side off at this q.

        mm_core.select_delta returns None for BOTH -- an infinite depth is the
        model saying "not this side at this inventory", and finite_float_or_none
        collapses it to None. An operator reading the log has to tell those
        apart: one means the HJB never solved (parameters, estimator, import),
        the other is the boundary policy working exactly as designed.
        """
        return "no_hjb_delta" if self.hjb_cache is None else "boundary_side_disabled"

    def _select_delta(
        self,
        side: str,
        q: float,
        *,
        tau_remaining: float | None = None,
    ) -> float | None:
        """Model depth for one side, off the cached HJB surface.

        Delegates to mm_core so the replay and the live path read the surface
        the same way -- this used to reimplement mm_core.select_delta and its
        grid indexing verbatim, which is exactly how the two drift apart.

        ``tau_remaining=None`` means "read the t=0 slice"; pass
        ``self._tau_remaining()`` for the book's time-dependent control.
        """
        if not self.hjb_cache:
            return None
        return self._mm_core.select_delta(
            self.hjb_cache, q, side, tau_remaining=tau_remaining
        )

    def _resize_inventory_unit(self, pair: str, mid_price: float) -> None:
        """Re-derive inventory_unit_base from available capital, when flat.

        Only when flat: the unit is the denominator of the q-mapping and an
        input to phi_effective, so moving it while a position is open would
        reprice existing inventory onto a different grid.
        """
        if not self.auto_size_inventory_unit:
            return
        mid = self._finite_float_or_none(mid_price)
        if mid is None or mid <= 0:
            return
        if self._inventory_level(pair) != 0:
            return
        capital = self._finite_float_or_none(
            self.config.get("available_capital") if isinstance(self.config, dict) else None
        )
        if capital is None or capital <= 0:
            return
        denominator = float(self.hjb_q_max) * mid
        if denominator <= 0:
            return
        unit = (
            capital
            * float(self.target_capital_utilisation)
            * float(self.target_leverage)
        ) / denominator
        if not np.isfinite(unit) or unit <= 0:
            return
        previous = float(self.inventory_unit_base)
        # Ignore sub-1% drift so the unit is not rewritten on every tick.
        if previous > 0 and abs(unit - previous) / previous < 0.01:
            return
        self.inventory_unit_base = float(unit)
        self._debug_log_event(
            "inventory_unit_resized",
            {
                "pair": pair,
                "mid": mid,
                "available_capital": capital,
                "target_capital_utilisation": float(self.target_capital_utilisation),
                "target_leverage": float(self.target_leverage),
                "q_max": int(self.hjb_q_max),
                "previous_unit_base": previous,
                "new_unit_base": float(unit),
                "max_notional_at_q_max": float(unit) * float(self.hjb_q_max) * mid,
            },
        )

    def _quote_config(self):
        """mm_core.QuoteConfig mirroring this strategy's live attributes.

        Rebuilt per call rather than cached: _apply_runtime_safety_config can
        change the multiplier and the bps clamps at runtime, and a stale config
        would quote off the operator's previous band.
        """
        return self._mm_core.QuoteConfig(
            maker_fee_rate=float(self.fees_maker_HL),
            spread_multiplier=float(self.spread_multiplier),
            extra_cushion_bps=float(self.extra_cushion_bps),
            min_half_spread_bps=float(self.min_half_spread_bps),
            max_half_spread_bps=float(self.max_half_spread_bps),
            inventory_unit_base=float(self.inventory_unit_base),
            q_max=int(self.hjb_q_max),
            allow_short=bool(self.can_short),
            hjb_alpha=float(self.hjb_alpha),
            hjb_phi_kappa_t=float(self.hjb_phi_kappa_t),
            # This was never passed, so the ceiling silently sat at QuoteConfig's
            # default of 50 and any hjb_phi_kappa_t above it was clamped back --
            # a setting of 200 would have quoted exactly like a setting of 50,
            # with nothing in the logs to say so.
            hjb_phi_kappa_t_max=float(self.hjb_phi_kappa_t_max),
            hjb_alpha_kappa=float(self.hjb_alpha_kappa),
            hjb_phi=float(self.hjb_phi),
            hjb_horizon_seconds=float(self.hjb_horizon_seconds),
            hjb_time_mode=str(self.hjb_time_mode),
            gamma_inventory_risk=float(self.gamma_inventory_risk),
            use_asymmetric_kappa=bool(self.use_asymmetric_kappa),
            max_toxicity=float(self.max_toxicity),
            max_param_age_seconds=float(self.max_param_age_seconds),
        )

    def _assemble_half_spread(self, pair: str, quote_side: str, delta_model: float,
                              mid_price: float) -> tuple[float, dict[str, Any]]:
        """Assemble the final half-spread from the HJB model depth.

            delta_total = clamp(delta_model * spread_multiplier + fee*mid,
                                min_half_spread_bps, max_half_spread_bps)

        The fee cushion is ONE maker fee per side: a round trip costs two fees
        and collects the cushion twice (once per side). The multiplier scales
        only the model term, so widening quotes defensively never inflates the
        fee compensation. The bps clamps are the hard guarantee that quotes
        stay inside the operator-approved band.

        Returns (delta_total, info) where info carries the quote_decision
        diagnostics: clamped ("floor"/"cap"/None), delta_pre_clamp,
        fee_cushion, bps, and the calibration-range flag
        (delta_total beyond the kappa fit's depth_p95 for this side means the
        fill model is extrapolating past its data).
        """
        mid = float(mid_price)

        depth_p95 = None
        try:
            symbol = self._symbol_from_pair(pair)
            entry = self.kappas.get(symbol) if isinstance(self.kappas, dict) else None
            if isinstance(entry, dict):
                key = "depth_p95_plus" if quote_side == "ask" else "depth_p95_minus"
                raw = entry.get(key)
                if raw is not None:
                    candidate = float(raw)
                    if np.isfinite(candidate) and candidate > 0:
                        depth_p95 = candidate
        except Exception:
            depth_p95 = None

        spread = self._mm_core.assemble_half_spread(
            delta_model,
            mid,
            self._quote_config(),
            depth_p95=depth_p95,
        )
        if spread is None:
            # Disabled side, or an unusable mid. Callers already check finiteness
            # of the model delta before getting here, so this is belt-and-braces.
            return float("inf"), {
                "clamped": None,
                "delta_pre_clamp": None,
                "fee_cushion": None,
                "bps": None,
                "quote_outside_calibrated_range": None,
                "depth_p95": depth_p95,
            }

        info = spread.as_dict()
        info.pop("delta_total", None)
        info.pop("delta_model", None)
        return float(spread.delta), info

    def _hjb_is_stale(self, current_time: datetime) -> bool:
        refreshed_at = self._as_utc(self._hjb_last_refresh_dt)
        now = self._as_utc(current_time) or self._now_utc()
        if refreshed_at is None:
            return True
        return (now - refreshed_at).total_seconds() > float(self.max_param_age_seconds)

    def _hjb_age_seconds(self, now: datetime | None = None) -> float | None:
        refreshed_at = self._as_utc(self._hjb_last_refresh_dt)
        if refreshed_at is None:
            return None
        reference = self._as_utc(now) or self._now_utc()
        return max(0.0, (reference - refreshed_at).total_seconds())

    def _combined_params(self, symbol: str) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        for source in (self.kappas, self.epsilons, self.lambdas):
            if isinstance(source, dict) and isinstance(source.get(symbol), dict):
                payload.update(source[symbol])
        return payload

    def _param_source_entries(self, symbol: str) -> list[dict[str, Any]]:
        entries: list[dict[str, Any]] = []
        for source in (self.kappas, self.epsilons, self.lambdas):
            if isinstance(source, dict) and isinstance(source.get(symbol), dict):
                entries.append(source[symbol])
        return entries

    def _param_age_seconds(self, symbol: str, now: datetime | None = None) -> float | None:
        ages: list[float] = []
        reference = self._as_utc(now) or self._now_utc()
        for entry in self._param_source_entries(symbol):
            generated_at = self._parse_utc_timestamp(entry.get("generated_at"))
            if generated_at is None:
                continue
            ages.append(max(0.0, (reference - generated_at).total_seconds()))
        return max(ages) if ages else None

    def _param_update_status(self) -> tuple[bool, str]:
        configured_path = getattr(self, "param_update_status_path", None)
        if configured_path is None:
            status_path = Path(__file__).resolve().parent / "param_update_status.json"
        elif str(configured_path) == "":
            return True, "ok"
        else:
            status_path = Path(configured_path)
        lock_path = status_path.with_name("param_update.lock")
        if lock_path.exists():
            try:
                lock_payload = json.loads(lock_path.read_text(encoding="utf-8"))
            except Exception:
                return False, "estimator_lock_unreadable"
            started_at = self._parse_utc_timestamp(lock_payload.get("started_at"))
            if started_at is None:
                return False, "estimator_lock_timestamp_missing"
            age_seconds = (self._now_utc() - started_at).total_seconds()
            if age_seconds < -float(self.max_future_timestamp_skew_seconds):
                return False, "estimator_lock_timestamp_future"
            if age_seconds > float(self.param_update_lock_stale_seconds):
                return False, "estimator_lock_stale"
            return False, "estimator_running"
        if not status_path.exists():
            return True, "ok"
        try:
            data = json.loads(status_path.read_text(encoding="utf-8"))
        except Exception:
            return False, "param_status_unreadable"
        status = str(data.get("status", "")).lower()
        if status == "running":
            return False, "estimator_running"
        if status in {"failed", "interrupted"}:
            return False, "param_update_failed"
        return True, "ok"

    def _params_are_valid(self, pair: str) -> tuple[bool, str]:
        symbol = self._symbol_from_pair(pair)
        # The file lock guards against torn multi-file reads. When the snapshot
        # is sourced from Redis (single atomic blob) that can't happen, so the
        # lock is irrelevant — freshness is still enforced by the generated_at
        # age checks below. The file path keeps the lock gate.
        if self._param_source != "redis":
            ok, reason = self._param_update_status()
            if not ok:
                return False, reason

        params = self._combined_params(symbol)
        schema_versions: list[int] = []
        source_entries = self._param_source_entries(symbol)
        for entry in source_entries:
            version = entry.get("schema_version")
            if version is not None:
                try:
                    schema_versions.append(int(version))
                except Exception:
                    return False, "param_schema_unsupported"
        if len(schema_versions) < 3 or any(version != SUPPORTED_PARAM_SCHEMA_VERSION for version in schema_versions):
            return False, "param_schema_unsupported"
        if len(source_entries) < 3:
            return False, "param_schema_unsupported"
        lambda_entry = self.lambdas.get(symbol) if isinstance(self.lambdas, dict) else None
        if not isinstance(lambda_entry, dict) or lambda_entry.get("lambda_source") != "mo_survival_fit":
            return False, "invalid_lambda_source"

        for entry in source_entries:
            if str(entry.get("status", "")).lower() != "ok":
                return False, "param_status_not_ok"
            generated_at = entry.get("generated_at")
            if not generated_at:
                return False, "missing_param_timestamp"
            parsed = self._parse_utc_timestamp(generated_at)
            if parsed is None:
                return False, "invalid_param_timestamp"
            age = (self._now_utc() - parsed).total_seconds()
            if age < -float(self.max_future_timestamp_skew_seconds):
                return False, "param_timestamp_future"
            if age > float(self.max_param_age_seconds):
                return False, "stale_params"

        required = ("kappa+", "kappa-", "lambda+", "lambda-", "epsilon+", "epsilon-")
        for key in required:
            if key not in params:
                return False, f"missing_{key}"
            try:
                value = float(params[key])
            except Exception:
                return False, f"nonfinite_{key}"
            if not np.isfinite(value):
                return False, f"nonfinite_{key}"

        if float(params["kappa+"]) <= 0 or float(params["kappa-"]) <= 0:
            return False, "invalid_kappa"
        if float(params["lambda+"]) < 0 or float(params["lambda-"]) < 0:
            return False, "invalid_lambda"
        if float(params["epsilon+"]) < 0 or float(params["epsilon-"]) < 0:
            return False, "invalid_epsilon"

        toxicity = max(
            float(params["kappa+"]) * float(params["epsilon+"]),
            float(params["kappa-"]) * float(params["epsilon-"]),
        )
        if toxicity > float(self.max_toxicity):
            return False, "toxicity_too_high"

        for key in ("n_points_plus", "n_points_minus"):
            if key not in params or int(params.get(key) or 0) < int(self.min_kappa_fit_points):
                return False, "insufficient_kappa_diagnostics"

        for key in ("r2_plus", "r2_minus"):
            if key not in params:
                return False, "insufficient_kappa_diagnostics"
            try:
                r2 = float(params[key])
            except Exception:
                return False, "insufficient_kappa_diagnostics"
            if not np.isfinite(r2) or r2 < float(self.min_kappa_r2):
                return False, "insufficient_kappa_diagnostics"

        buy_events = int(params.get("n_buy_events") or 0)
        sell_events = int(params.get("n_sell_events") or 0)
        if buy_events < int(self.min_epsilon_events) or sell_events < int(self.min_epsilon_events):
            return False, "insufficient_epsilon_diagnostics"

        return True, "ok"

    def _book_snapshot(self, pair: str) -> tuple[dict[str, float] | None, str]:
        now = self._now_utc()
        cache = getattr(self, "_book_snapshot_cache", None)
        if not isinstance(cache, dict):
            cache = {}
            self._book_snapshot_cache = cache
        cached = cache.get(pair)
        if isinstance(cached, dict):
            checked_at = self._as_utc(cached.get("checked_at"))
            if (
                checked_at is not None
                and (now - checked_at).total_seconds() * 1000.0 <= float(self.book_snapshot_cache_ms)
            ):
                return cached.get("snapshot"), str(cached.get("reason", "ok"))

        try:
            ob = self.dp.orderbook(pair, maximum=1)
            if not ob or not ob.get("bids") or not ob.get("asks"):
                cache[pair] = {"checked_at": now, "snapshot": None, "reason": "empty_orderbook", "book_ts": None}
                return None, "empty_orderbook"
            best_bid = float(ob["bids"][0][0])
            best_ask = float(ob["asks"][0][0])
            if best_bid <= 0 or best_ask <= 0 or best_bid >= best_ask:
                cache[pair] = {
                    "checked_at": now,
                    "snapshot": None,
                    "reason": "crossed_or_invalid_book",
                    "book_ts": None,
                }
                return None, "crossed_or_invalid_book"
            book_ts = None
            if isinstance(ob, dict):
                for key in ("timestamp", "ts", "datetime"):
                    book_ts = self._parse_utc_timestamp(ob.get(key))
                    if book_ts is not None:
                        break
            snapshot = {"best_bid": best_bid, "best_ask": best_ask, "mid": (best_bid + best_ask) / 2.0}
            cache[pair] = {"checked_at": now, "snapshot": snapshot, "reason": "ok", "book_ts": book_ts}
            return snapshot, "ok"
        except Exception as exc:
            cache[pair] = {"checked_at": now, "snapshot": None, "reason": f"orderbook_error:{exc}", "book_ts": None}
            return None, f"orderbook_error:{exc}"

    def _book_age_ms(self, pair: str, current_time: datetime | None = None) -> float | None:
        self._book_snapshot(pair)
        cache = getattr(self, "_book_snapshot_cache", {})
        cached = cache.get(pair) if isinstance(cache, dict) else None
        if not isinstance(cached, dict):
            return None
        reference = self._as_utc(current_time) or self._now_utc()
        timestamp = self._as_utc(cached.get("book_ts"))
        if timestamp is None:
            timestamp = self._as_utc(cached.get("checked_at"))
        if timestamp is None:
            return None
        return max(0.0, (reference - timestamp).total_seconds() * 1000.0)

    def _book_is_fresh(self, pair: str, current_time: datetime) -> tuple[bool, str]:
        snapshot, reason = self._book_snapshot(pair)
        if snapshot is None:
            return False, reason
        age_ms = self._book_age_ms(pair, current_time)
        if age_ms is not None and age_ms > float(self.max_book_age_seconds) * 1000.0:
            return False, "stale_orderbook"
        return True, "ok"

    def _maker_safe(self, pair: str, quote_side: str, rate: float) -> tuple[bool, str]:
        snapshot, reason = self._book_snapshot(pair)
        if snapshot is None:
            return False, reason
        return self._mm_core.maker_safe(
            quote_side, rate, snapshot["best_bid"], snapshot["best_ask"]
        )

    def _model_ready(self, pair: str) -> bool:
        ok, _ = self._params_are_valid(pair)
        if not ok or self.hjb_cache is None:
            return False
        ok, _ = self._market_data_fresh(self._symbol_from_pair(pair))
        return ok

    def _inventory_allows_bid(self, pair: str) -> bool:
        """Can this instance rest a bid?

        For the long leg a bid ADDS inventory, so it is capped by q_max. For the
        short leg a bid COVERS, so it needs an existing short to cover -- the
        mirror image, and the reason this cannot be one shared rule.
        """
        if self._reject_unexpected_short_position(pair):
            return False
        q = self._inventory_level(pair)
        if self.can_short:
            return q < 0
        return q < min(int(self.hjb_q_max), int(self.max_abs_inventory_units))

    def _inventory_allows_ask(self, pair: str) -> bool:
        """Can this instance rest an ask?

        For the long leg an ask REDUCES, so it needs inventory to sell. For the
        short leg an ask ADDS short exposure, so it is capped by q_max.
        """
        if self._reject_unexpected_short_position(pair):
            return False
        q = self._inventory_level(pair)
        if self.can_short:
            return abs(q) < min(int(self.hjb_q_max), int(self.max_abs_inventory_units))
        return q > 0

    def _physical_quote_side(self, side: str | None) -> str:
        """Which side of the BOOK a freqtrade entry/exit corresponds to.

        Freqtrade speaks in entries and exits; the book only knows bids and
        asks, and the mapping between them is role-dependent. For the long leg
        an entry is a bid and an exit an ask. For the short leg it is mirrored:
        an entry is an ask (adding short) and an exit is a bid (covering).
        Getting this backwards would price the short leg's cover off the ask
        depth, i.e. off the wrong side of the model.
        """
        side_text = str(side or "").strip().lower()
        if side_text in {"bid", "ask"}:
            return side_text
        if side_text in {"long", "short", "buy", "sell", "entry", ""}:
            return "ask" if self.can_short else "bid"
        if side_text in {"exit", "close", "close_long", "close_short"}:
            return "bid" if self.can_short else "ask"
        # Silently treating an unknown string as an exit is how a wrong-side
        # quote gets priced. Every caller passes a known token.
        raise ValueError(f"unrecognised quote side/action: {side!r}")

    def _inventory_allows_quote(self, pair: str, freqtrade_action: str) -> bool:
        """May this role rest the book side that a freqtrade entry/exit implies?

        The bid/ask guards are mirror images (a bid ADDS for the long leg but
        COVERS for the short leg), so asking the wrong one is not conservative,
        it is simply wrong: the short leg was asked "do you have a short to
        cover?" when opening one, got False at q=0, and every entry was rejected
        as position_limit_reached.
        """
        side = self._physical_quote_side(freqtrade_action)
        if side == "ask":
            return self._inventory_allows_ask(pair)
        return self._inventory_allows_bid(pair)

    def _quote_side_and_sign(self, freqtrade_action: str) -> tuple[str, float]:
        """Book side and price direction for a freqtrade entry/exit on this role.

            long leg :  entry = bid (mid - delta),  exit = ask (mid + delta)
            short leg:  entry = ask (mid + delta),  exit = bid (mid - delta)

        Both halves have to flip together. Taking the depth from one side of the
        HJB and the sign from the other quotes a price on the wrong side of the
        book, which the maker-safety check then rejects -- the short leg was
        priced at mid MINUS the half-spread and every entry was denied.
        """
        side = self._physical_quote_side(freqtrade_action)
        return side, (-1.0 if side == "bid" else 1.0)

    def _quote_state_valid(self, pair: str, side: str, rate: float, current_time: datetime) -> tuple[bool, str]:
        if not self.trading_enabled:
            return False, self.fail_closed_reason or "trading_disabled"
        if self.hjb_cache is None:
            return False, "no_hjb_cache"
        if not np.isfinite(float(rate)) or float(rate) <= 0:
            return False, "invalid_rate"
        if self._hjb_is_stale(current_time):
            return False, "stale_hjb"

        ok, reason = self._params_are_valid(pair)
        if not ok:
            return False, reason

        ok, reason = self._fee_state_valid(pair)
        if not ok:
            return False, reason

        ok, reason = self._book_is_fresh(pair, current_time)
        if not ok:
            return False, "stale_orderbook" if reason == "empty_orderbook" else reason

        symbol = self._symbol_from_pair(pair)
        ok, reason = self._market_data_fresh(symbol)
        if not ok:
            if reason.startswith("collector_data_stale") or reason.startswith("missing_collector_streams"):
                return False, "stale_collector_data"
            return False, reason

        signed_base = self._signed_base_position(pair)
        if self._reject_unexpected_short_position(pair, signed_base):
            return False, "unexpected_short_position"

        _, q_exact, tau = self._pricing_state(pair)
        quote_side = self._physical_quote_side(side)
        delta = self._select_delta(quote_side, q_exact, tau_remaining=tau)
        if delta is None or not np.isfinite(float(delta)):
            return False, self._no_delta_reason()

        if quote_side == "bid" and not self._inventory_allows_bid(pair):
            return False, "position_limit_reached"
        if quote_side == "ask" and not self._inventory_allows_ask(pair):
            return False, "position_limit_reached"

        is_dry_run = bool(getattr(self, "config", {}).get("dry_run", True))
        if not self.post_only_verified and self.trading_enabled and not is_dry_run:
            return False, "post_only_not_verified"
        if self.trading_enabled and not is_dry_run:
            ok, reason, _ = self._live_deployment_gate_state()
            if not ok:
                return False, reason

        ok, reason, _ = self._position_risk_valid(pair, side, rate)
        if not ok:
            return False, reason

        return True, "ok"

    def _price_tick(self, pair: str) -> float | None:
        try:
            market = self.exchange.markets.get(pair, {}) if getattr(self, "exchange", None) else {}
            precision = market.get("precision", {}).get("price")
            if isinstance(precision, int):
                return 10 ** (-precision)
            if precision:
                return float(precision)
        except Exception:
            pass
        return None

    def _round_quote_price(self, pair: str, quote_side: str, raw_rate: float) -> float:
        tick = self._price_tick(pair)
        # Decimal rounding via mm_core/hyperliquid_alo_executor rather than
        # binary float floor/ceil: a bid rounded one ULP up can cross the ask and
        # turn a post-only order into a reject. Direction is unchanged -- bids
        # down, asks up, never toward the touch.
        rounded = self._mm_core.round_price_for_side(
            side=quote_side, price=float(raw_rate), price_tick_size=tick
        )
        try:
            if getattr(self, "exchange", None) and hasattr(self.exchange, "price_to_precision"):
                rounded = float(self.exchange.price_to_precision(pair, rounded))
        except Exception:
            pass
        return float(rounded)

    def _amount_step(self, pair: str) -> float | None:
        try:
            market = self.exchange.markets.get(pair, {}) if getattr(self, "exchange", None) else {}
            precision = market.get("precision", {}).get("amount")
            if isinstance(precision, int):
                return 10 ** (-precision)
            if precision:
                return float(precision)
        except Exception:
            pass
        return None

    def _round_quote_amount(self, pair: str, amount: float) -> float:
        amount = float(amount)
        step = self._amount_step(pair)
        if step and step > 0:
            rounded = math.floor(amount / step) * step
        else:
            rounded = amount
        try:
            if getattr(self, "exchange", None) and hasattr(self.exchange, "amount_to_precision"):
                exchange_rounded = float(self.exchange.amount_to_precision(pair, rounded))
                if step and step > 0 and exchange_rounded > amount:
                    exchange_rounded = max(0.0, exchange_rounded - step)
                rounded = min(exchange_rounded, amount)
        except Exception:
            pass
        return max(0.0, float(rounded))

    def _amount_lot_safe(self, pair: str, amount: float, rate: float) -> tuple[bool, str, float]:
        try:
            amount = float(amount)
            rate = float(rate)
        except Exception:
            return False, "invalid_amount", 0.0
        if not np.isfinite(amount) or amount <= 0:
            return False, "invalid_amount", 0.0
        if not np.isfinite(rate) or rate <= 0:
            return False, "invalid_rate", 0.0

        rounded = self._round_quote_amount(pair, amount)
        if rounded <= 0:
            return False, "invalid_amount", rounded
        if abs(rounded - amount) > max(1e-12, amount * 1e-9):
            return False, "amount_not_lot_safe", rounded

        try:
            market = self.exchange.markets.get(pair, {}) if getattr(self, "exchange", None) else {}
            limits = market.get("limits", {})
            min_amount = (limits.get("amount") or {}).get("min")
            min_cost = (limits.get("cost") or {}).get("min")
            if min_amount is not None and rounded < float(min_amount):
                return False, "amount_below_min", rounded
            if min_cost is not None and rounded * rate < float(min_cost):
                return False, "cost_below_min", rounded
        except Exception:
            pass

        return True, "ok", rounded

    def _price_tick_safe(self, pair: str, quote_side: str, rate: float) -> tuple[bool, str, float]:
        try:
            rate = float(rate)
        except Exception:
            return False, "invalid_rate", 0.0
        if not np.isfinite(rate) or rate <= 0:
            return False, "invalid_rate", 0.0

        rounded = self._round_quote_price(pair, quote_side, rate)
        if not np.isfinite(float(rounded)) or float(rounded) <= 0:
            return False, "invalid_rate", float(rounded)
        if abs(float(rounded) - rate) > max(1e-12, abs(rate) * 1e-9):
            return False, "price_not_tick_safe", float(rounded)
        return True, "ok", float(rounded)

    def _is_limit_order_type(self, order_type: str | None) -> bool:
        return str(order_type or "").strip().lower() == "limit"

    def _entry_side_rejection_reason(self, side: str | None) -> str | None:
        """Which entry sides this ROLE may open.

        Role-aware rather than long-only: the short leg of the pair must be able
        to open shorts, and -- just as importantly -- must NOT be able to open
        longs. can_short=True means "short only", not "either direction"; a
        short instance drifting long is the same class of fault as a long
        instance drifting short.
        """
        side_text = str(side or "").strip().lower()
        long_sides = {"long", "buy", "bid", "entry", ""}
        short_sides = {"short", "sell", "ask", "open_short"}

        if side_text in short_sides:
            return None if self.can_short else "short_entries_disabled"
        if side_text in long_sides:
            # An explicit long on the short leg is a role violation. The empty
            # string is freqtrade not telling us a side, so it stays permitted.
            if self.can_short and side_text != "":
                return "long_entries_disabled"
            return None
        return "unsupported_entry_side"

    def _trigger_kill_switch(self, reason: str, payload: dict[str, Any] | None = None) -> None:
        self.trading_enabled = False
        self.fail_closed_reason = reason
        payload = dict(payload or {})
        pair = payload.get("pair")
        try:
            payload.update(self._cancel_open_orders_for_kill_switch(pair))
        except Exception as exc:
            payload["cancel_error"] = str(exc)
        flatten_request = None
        try:
            flatten_request = self._risk_flatten_request_payload(str(pair), reason, payload) if pair else None
            if flatten_request is not None:
                payload["risk_flatten_request_emitted"] = True
                payload["risk_action_id"] = flatten_request.get("risk_action_id")
            else:
                payload["risk_flatten_request_emitted"] = False
        except Exception as exc:
            payload["risk_flatten_request_emitted"] = False
            payload["risk_flatten_request_error"] = str(exc)
        self._debug_log_event("kill_switch", {"reason": reason, **payload})
        if flatten_request is not None:
            self._debug_log_event("risk_flatten_requested", flatten_request)

    def _next_risk_action_id(self) -> str:
        sequence = int(getattr(self, "_risk_action_sequence", 0)) + 1
        self._risk_action_sequence = sequence
        return f"risk-{sequence:012d}"

    def _risk_session_id(self) -> str:
        mm_config = self._mm_config()
        for value in (
            mm_config.get("session_id"),
            getattr(self, "config", {}).get("bot_name") if isinstance(getattr(self, "config", {}), dict) else None,
        ):
            if value not in (None, ""):
                return str(value)
        return "freqtrade"

    def _risk_flatten_client_order_id(self, session_id: str, risk_action_id: str, side: str, reason: str) -> str:
        return "|".join(
            [
                "risk",
                f"sess={session_id or 'unknown'}",
                f"rid={risk_action_id or 'unknown'}",
                "mode=flatten",
                f"side={side}",
                f"reason={reason or 'unspecified'}",
            ]
        )

    def _risk_flatten_cloid(self, client_order_id: str) -> str:
        return "0x" + hashlib.sha256(str(client_order_id).encode("utf-8")).hexdigest()[:32]

    def _risk_flatten_reference_price(
        self,
        pair: str,
        payload: dict[str, Any],
    ) -> tuple[float | None, str]:
        for key in ("price", "reference_rate", "mid", "current_rate", "proposed_rate", "rate"):
            value = self._finite_float_or_none(payload.get(key))
            if value is not None and value > 0:
                return float(value), str(key)
        snapshot, book_reason = self._book_snapshot(pair)
        if snapshot is not None:
            value = self._finite_float_or_none(snapshot.get("mid"))
            if value is not None and value > 0:
                return float(value), "orderbook_mid"
        return None, book_reason

    def _risk_flatten_request_payload(
        self,
        pair: str,
        reason: str,
        kill_payload: dict[str, Any],
    ) -> dict[str, Any] | None:
        signed_base = self._finite_float_or_none(kill_payload.get("signed_base_position"))
        if signed_base is None:
            signed_base = self._signed_base_position(pair)
        if signed_base is None or abs(float(signed_base)) <= 1e-12:
            return None

        side = "sell" if float(signed_base) > 0 else "buy"
        reference_price, reference_source = self._risk_flatten_reference_price(pair, kill_payload)
        size_base = abs(float(signed_base))
        notional = size_base * reference_price if reference_price is not None else None
        risk_action_id = self._next_risk_action_id()
        session_id = self._risk_session_id()
        client_order_id = self._risk_flatten_client_order_id(session_id, risk_action_id, side, reason)
        max_notional = float(self.max_notional_exposure_usdc)
        return {
            "risk_action_id": risk_action_id,
            "session_id": session_id,
            "pair": pair,
            "symbol": self._symbol_from_pair(pair),
            "reason": reason,
            "signed_base_position": float(signed_base),
            "flatten_side": side,
            "size_base": float(size_base),
            "reference_price": float(reference_price) if reference_price is not None else None,
            "reference_price_source": reference_source,
            "notional_usdc": float(notional) if notional is not None else None,
            "max_notional_usdc": max_notional,
            "exceeds_default_flatten_notional_cap": bool(notional is not None and max_notional > 0 and notional > max_notional),
            "executor": "hyperliquid_risk_executor.py",
            "executor_mode": "submit-flatten",
            "order_type": "limit",
            "time_in_force": "Ioc",
            "reduce_only": True,
            "client_order_id": client_order_id,
            "cloid": self._risk_flatten_cloid(client_order_id),
            "requires_env": "HYPERLIQUID_RISK_FLATTEN_ALLOW=1",
            "requires_acknowledgement": "--acknowledge-risk-reducing-taker",
            "dry_run": bool(getattr(self, "config", {}).get("dry_run", True))
            if isinstance(getattr(self, "config", {}), dict)
            else True,
        }

    def _next_quote_id(self) -> str:
        sequence = int(getattr(self, "_quote_id_sequence", 0)) + 1
        self._quote_id_sequence = sequence
        return f"quote-{sequence:012d}"

    def _quote_link_tolerance(self, rate: float | None) -> float:
        if rate is None:
            return 1e-8
        return max(1e-8, abs(float(rate)) * 1e-9)

    def _trim_quote_link_cache(self, cache: list[dict[str, Any]]) -> list[dict[str, Any]]:
        limit = max(1, int(getattr(self, "quote_link_cache_limit", 500)))
        return cache[-limit:]

    def _remember_quote_decision(self, payload: dict[str, Any], timestamp: datetime) -> None:
        if payload.get("decision") != "accept":
            return
        price = self._finite_float_or_none(payload.get("rounded_price"))
        quote_id = payload.get("quote_id")
        if price is None or quote_id in (None, ""):
            return
        cache = list(getattr(self, "_accepted_quote_decisions", []) or [])
        cache.append(
            {
                "quote_id": str(quote_id),
                "ts": timestamp,
                "pair": payload.get("pair"),
                "side": payload.get("side"),
                "action": payload.get("action"),
                "price": float(price),
            }
        )
        self._accepted_quote_decisions = self._trim_quote_link_cache(cache)

    def _match_quote_link_cache(
        self,
        cache_name: str,
        pair: str,
        quote_side: str | None,
        rate: float | None,
        current_time: datetime,
    ) -> dict[str, Any] | None:
        price = self._finite_float_or_none(rate)
        side = str(quote_side or "").strip().lower()
        now = self._as_utc(current_time) or self._now_utc()
        if price is None or side not in {"bid", "ask"}:
            return None
        tolerance = self._quote_link_tolerance(float(price))
        max_age = max(0.0, float(getattr(self, "quote_link_max_age_seconds", 900)))
        candidates: list[dict[str, Any]] = []
        for item in getattr(self, cache_name, []) or []:
            item_ts = self._as_utc(item.get("ts"))
            item_price = self._finite_float_or_none(item.get("price"))
            if item_ts is None or item_price is None:
                continue
            age = (now - item_ts).total_seconds()
            if age < -1.0 or age > max_age:
                continue
            if item.get("pair") != pair or item.get("side") != side:
                continue
            if abs(float(item_price) - float(price)) > tolerance:
                continue
            candidates.append(item)
        if not candidates:
            return None
        return max(candidates, key=lambda item: self._as_utc(item.get("ts")) or datetime.min.replace(tzinfo=timezone.utc))

    def _remember_order_attempt(
        self,
        *,
        pair: str,
        quote_side: str,
        rate: float,
        amount: float,
        current_time: datetime,
        time_in_force: str | None,
        quote_match: dict[str, Any] | None,
    ) -> None:
        quote_id = quote_match.get("quote_id") if quote_match else None
        cache = list(getattr(self, "_accepted_order_attempt_links", []) or [])
        cache.append(
            {
                "quote_id": str(quote_id) if quote_id not in (None, "") else None,
                "ts": self._as_utc(current_time) or self._now_utc(),
                "pair": pair,
                "side": quote_side,
                "price": float(rate),
                "amount": float(amount),
                "time_in_force": time_in_force,
            }
        )
        self._accepted_order_attempt_links = self._trim_quote_link_cache(cache)

    def _record_quote_decision(self, pair: str, decision: str, reason: str) -> None:
        self._quote_decisions_count = int(getattr(self, "_quote_decisions_count", 0)) + 1
        post_only_reasons = {
            "bid_crosses_ask",
            "ask_crosses_bid",
            "crossed_or_invalid_book",
            "empty_orderbook",
            "post_only_not_verified",
            "not_post_only_supported",
            "time_in_force_not_post_only",
        }
        if decision == "reject" and reason in post_only_reasons:
            self._post_only_rejects = int(getattr(self, "_post_only_rejects", 0)) + 1

        attempts = int(getattr(self, "_quote_decisions_count", 0))
        rejects = int(getattr(self, "_post_only_rejects", 0))
        if (
            self.trading_enabled
            and attempts >= int(self.min_post_only_reject_samples)
            and rejects / max(attempts, 1) > float(self.max_post_only_reject_rate)
        ):
            self._trigger_kill_switch(
                "post_only_reject_rate_exceeded",
                {"pair": pair, "quote_decisions": attempts, "post_only_rejects": rejects},
            )

    def _remember_custom_price_rejection(
        self,
        *,
        pair: str,
        quote_side: str,
        reason: str,
        current_time: datetime,
        rate: float | None = None,
    ) -> None:
        cache = getattr(self, "_custom_price_rejections", None)
        if not isinstance(cache, dict):
            cache = {}
            self._custom_price_rejections = cache
        cache[(pair, quote_side)] = {
            "reason": reason,
            "ts": self._as_utc(current_time) or self._now_utc(),
            "rate": self._finite_float_or_none(rate),
        }

    def _clear_custom_price_rejection(self, pair: str, quote_side: str) -> None:
        cache = getattr(self, "_custom_price_rejections", None)
        if isinstance(cache, dict):
            cache.pop((pair, quote_side), None)

    def _pending_custom_price_rejection_reason(
        self,
        pair: str,
        quote_side: str,
        current_time: datetime,
    ) -> str | None:
        cache = getattr(self, "_custom_price_rejections", None)
        if not isinstance(cache, dict):
            return None
        item = cache.get((pair, quote_side))
        if not isinstance(item, dict):
            return None
        item_ts = self._as_utc(item.get("ts"))
        now = self._as_utc(current_time) or self._now_utc()
        if item_ts is None:
            cache.pop((pair, quote_side), None)
            return None
        age = (now - item_ts).total_seconds()
        if age < -1.0 or age > float(self.quote_link_max_age_seconds):
            cache.pop((pair, quote_side), None)
            return None
        return str(item.get("reason") or "custom_price_rejected")

    def _custom_price_distance_valid(
        self,
        rate: float,
        proposed_rate: float,
    ) -> tuple[bool, str, dict[str, Any]]:
        try:
            rate_f = float(rate)
            proposed_f = float(proposed_rate)
        except Exception:
            return False, "invalid_rate", {}
        if not np.isfinite(rate_f) or rate_f <= 0 or not np.isfinite(proposed_f) or proposed_f <= 0:
            return False, "invalid_rate", {}
        config = getattr(self, "config", {}) if isinstance(getattr(self, "config", {}), dict) else {}
        try:
            max_ratio = float(config.get("custom_price_max_distance_ratio", 0.0) or 0.0)
        except Exception:
            max_ratio = 0.0
        if max_ratio <= 0:
            return True, "ok", {"custom_price_distance_ratio": None, "custom_price_max_distance_ratio": None}
        distance_ratio = abs(rate_f - proposed_f) / proposed_f
        payload = {
            "custom_price_distance_ratio": float(distance_ratio),
            "custom_price_max_distance_ratio": float(max_ratio),
        }
        if distance_ratio > max_ratio:
            return False, "custom_price_too_far", payload
        return True, "ok", payload

    def _record_order_attempt_accepted(
        self,
        *,
        pair: str,
        quote_side: str,
        rate: float,
        amount: float,
        time_in_force: str | None,
        current_time: datetime,
    ) -> None:
        self._accepted_order_attempts = int(getattr(self, "_accepted_order_attempts", 0)) + 1
        quote_match = self._match_quote_link_cache("_accepted_quote_decisions", pair, quote_side, rate, current_time)
        config = getattr(self, "config", {}) if isinstance(getattr(self, "config", {}), dict) else {}
        expected_tif = self._expected_time_in_force(quote_side)
        expected_tif_canonical = self._canonical_tif(expected_tif)
        actual_tif_canonical = self._canonical_tif(time_in_force)
        self._remember_order_attempt(
            pair=pair,
            quote_side=quote_side,
            rate=float(rate),
            amount=float(amount),
            current_time=current_time,
            time_in_force=time_in_force,
            quote_match=quote_match,
        )
        self._debug_log_event(
            "order_attempt_accepted",
            {
                "pair": pair,
                "side": quote_side,
                "rate": float(rate),
                "amount": float(amount),
                "time_in_force": time_in_force,
                "time_in_force_canonical": actual_tif_canonical,
                "expected_tif": expected_tif,
                "expected_tif_canonical": expected_tif_canonical,
                "post_only": actual_tif_canonical == "post_only",
                "post_only_verified": bool(self.post_only_verified),
                "trading_enabled": bool(self.trading_enabled),
                "dry_run": bool(config.get("dry_run", True)),
                "quote_id": quote_match.get("quote_id") if quote_match else None,
                "quote_id_source": "quote_decision_cache" if quote_match else "unmatched",
                "accepted_order_attempts": int(getattr(self, "_accepted_order_attempts", 0)),
            },
        )

    def _record_open_order_cancel_request(self, count: int = 1) -> None:
        self._cancel_open_order_requests = int(getattr(self, "_cancel_open_order_requests", 0)) + max(1, int(count))

    def _reset_daily_risk_if_needed(self, current_time: datetime) -> None:
        now = self._as_utc(current_time) or self._now_utc()
        day = now.date().isoformat()
        if getattr(self, "_daily_risk_date", None) != day:
            self._daily_risk_date = day
            self._daily_realized_pnl_usdc = 0.0
            self._consecutive_losses = 0

    def _extract_realized_pnl_usdc(self, trade: Trade, order: Order) -> float | None:
        for source in (order, trade):
            for attr in ("realized_pnl", "realized_profit", "close_profit_abs", "profit_abs"):
                value = getattr(source, attr, None)
                if value is None:
                    continue
                try:
                    value = float(value)
                except Exception:
                    continue
                if np.isfinite(value):
                    return value
        return None

    def _finite_float_or_none(self, value: Any) -> float | None:
        try:
            value_float = float(value)
        except Exception:
            return None
        return value_float if np.isfinite(value_float) else None

    def _normalize_liquidity(self, liquidity: Any) -> str:
        if liquidity is None:
            return "unknown"
        text = str(liquidity).strip().lower()
        if text in {"maker", "m", "add_liquidity", "added_liquidity", "post_only"}:
            return "maker"
        if text in {"taker", "t", "remove_liquidity", "removed_liquidity"}:
            return "taker"
        return text or "unknown"

    def _quote_side_from_order_side(self, side: Any) -> str | None:
        if side is None:
            return None
        text = str(side).strip().lower()
        if text in {"buy", "long", "bid", "entry", "open_long", "close_short"}:
            return "bid"
        if text in {"sell", "short", "ask", "exit", "open_short", "close_long"}:
            return "ask"
        return text or None

    def _canonical_tif(self, tif: Any) -> str | None:
        if tif is None:
            return None
        text = str(tif).strip().lower().replace("-", "_")
        if text in {"alo", "po", "post_only", "postonly"}:
            return "post_only"
        if text in {"gtc", "good_til_cancelled", "good_till_cancelled"}:
            return "gtc"
        if text in {"ioc", "immediate_or_cancel"}:
            return "ioc"
        return text or None

    def _configured_time_in_force(self, quote_side: str | None) -> Any:
        config = getattr(self, "config", {}) or {}
        config_tif = config.get("order_time_in_force") if isinstance(config, dict) else None
        if not isinstance(config_tif, dict):
            config_tif = {}
        strategy_tif = self.order_time_in_force if isinstance(self.order_time_in_force, dict) else {}
        if quote_side == "bid":
            return config_tif.get("entry", strategy_tif.get("entry"))
        if quote_side == "ask":
            return config_tif.get("exit", strategy_tif.get("exit"))
        return None

    def _configured_post_only_tif_valid(self) -> tuple[bool, str, dict[str, Any]]:
        entry_tif = self._configured_time_in_force("bid")
        exit_tif = self._configured_time_in_force("ask")
        entry_canonical = self._canonical_tif(entry_tif)
        exit_canonical = self._canonical_tif(exit_tif)
        payload = {
            "entry_time_in_force": entry_tif,
            "exit_time_in_force": exit_tif,
            "entry_time_in_force_canonical": entry_canonical,
            "exit_time_in_force_canonical": exit_canonical,
        }
        if entry_canonical != "post_only" or exit_canonical != "post_only":
            return False, "time_in_force_not_post_only", payload
        return True, "ok", payload

    def _expected_time_in_force(self, quote_side: str | None) -> str | None:
        configured = self._configured_time_in_force(quote_side)
        return "Alo" if self.post_only_verified else configured

    def _time_in_force_valid(self, quote_side: str, time_in_force: str | None) -> tuple[bool, str]:
        expected_tif = self._expected_time_in_force(quote_side)
        expected_canonical = self._canonical_tif(expected_tif)
        actual_canonical = self._canonical_tif(time_in_force)
        if expected_canonical == "post_only" and actual_canonical != "post_only":
            return False, "time_in_force_not_post_only"
        return True, "ok"

    def _config_fee_rate(self) -> float | None:
        config = getattr(self, "config", {}) or {}
        if not isinstance(config, dict):
            return None
        return self._finite_float_or_none(config.get("fee"))

    def _config_fee_state_valid(self) -> tuple[bool, str]:
        config_fee = self._config_fee_rate()
        if config_fee is None:
            return False, "missing_config_fee"
        if not self._fee_rate_matches(float(self.fees_maker_HL), config_fee):
            return False, "config_fee_mismatch"
        return True, "ok"

    def _fee_rate_matches(self, expected: float | None, observed: float | None, tolerance: float = 1e-9) -> bool | None:
        if expected is None or observed is None:
            return None
        return abs(float(expected) - float(observed)) <= float(tolerance)

    def _extract_fee_rates_from_mapping(self, payload: Any) -> tuple[float | None, float | None]:
        if not isinstance(payload, dict):
            return None, None

        maker = None
        taker = None
        for key in ("maker", "maker_fee", "makerFee", "maker_rate", "makerRate"):
            if key in payload:
                maker = self._finite_float_or_none(payload.get(key))
                if maker is not None:
                    break
        for key in ("taker", "taker_fee", "takerFee", "taker_rate", "takerRate"):
            if key in payload:
                taker = self._finite_float_or_none(payload.get(key))
                if taker is not None:
                    break
        if maker is not None or taker is not None:
            return maker, taker

        for key in ("trading", "fees", "info"):
            nested = payload.get(key)
            if isinstance(nested, dict):
                maker, taker = self._extract_fee_rates_from_mapping(nested)
                if maker is not None or taker is not None:
                    return maker, taker
        return None, None

    def _cached_exchange_fee_snapshot(self, pair: str) -> dict[str, Any] | None:
        cache = getattr(self, "_fee_snapshot_cache", None)
        if not isinstance(cache, dict):
            return None
        entry = cache.get(pair)
        if not isinstance(entry, dict):
            return None
        checked_at = self._as_utc(entry.get("checked_at"))
        if checked_at is None:
            return None
        age = (self._now_utc() - checked_at).total_seconds()
        if age > float(self.fee_snapshot_cache_seconds):
            return None
        snapshot = entry.get("snapshot")
        return snapshot if isinstance(snapshot, dict) else None

    def _exchange_fee_snapshot(self, pair: str) -> dict[str, Any]:
        cached = self._cached_exchange_fee_snapshot(pair)
        if cached is not None:
            return cached

        exchange = getattr(self, "exchange", None)
        maker = None
        taker = None
        source = "unavailable"

        if exchange is not None:
            try:
                market = getattr(exchange, "markets", {}).get(pair, {})
            except Exception:
                market = {}
            maker, taker = self._extract_fee_rates_from_mapping(market)
            if maker is not None or taker is not None:
                source = "exchange_markets"

            if maker is None and taker is None:
                maker, taker = self._extract_fee_rates_from_mapping(getattr(exchange, "fees", None))
                if maker is not None or taker is not None:
                    source = "exchange_fees"

            if (
                maker is None
                and taker is None
                and bool(self._mm_config().get("fetch_exchange_fee_snapshot", False))
            ):
                method = getattr(exchange, "fetch_trading_fee", None)
                if callable(method):
                    try:
                        fee_payload = method(pair)
                    except Exception as exc:
                        source = f"fetch_trading_fee_error:{exc}"
                    else:
                        maker, taker = self._extract_fee_rates_from_mapping(fee_payload)
                        source = "fetch_trading_fee"

        snapshot = {
            "source": source,
            "maker_fee_rate": float(maker) if maker is not None else None,
            "taker_fee_rate": float(taker) if taker is not None else None,
        }
        cache = getattr(self, "_fee_snapshot_cache", None)
        if not isinstance(cache, dict):
            cache = {}
            self._fee_snapshot_cache = cache
        cache[pair] = {"checked_at": self._now_utc(), "snapshot": snapshot}
        return snapshot

    def _fee_snapshot(self, pair: str, actual_fee_rate: float | None = None) -> dict[str, Any]:
        exchange_snapshot = self._exchange_fee_snapshot(pair)
        strategy_fee = float(self.fees_maker_HL)
        config_fee = self._config_fee_rate()
        exchange_maker_fee = self._finite_float_or_none(exchange_snapshot.get("maker_fee_rate"))
        exchange_taker_fee = self._finite_float_or_none(exchange_snapshot.get("taker_fee_rate"))
        config_matches = self._fee_rate_matches(strategy_fee, config_fee)
        exchange_maker_matches = self._fee_rate_matches(strategy_fee, exchange_maker_fee)
        actual_matches = self._fee_rate_matches(strategy_fee, actual_fee_rate)
        observed_matches = [
            match
            for match in (config_matches, exchange_maker_matches, actual_matches)
            if match is not None
        ]
        return {
            "strategy_maker_fee_rate": strategy_fee,
            "config_fee_rate": float(config_fee) if config_fee is not None else None,
            "config_fee_matches_strategy": config_matches,
            "exchange_fee_source": exchange_snapshot.get("source"),
            "exchange_maker_fee_rate": exchange_maker_fee,
            "exchange_taker_fee_rate": exchange_taker_fee,
            "exchange_maker_fee_matches_strategy": exchange_maker_matches,
            "actual_fee_rate": float(actual_fee_rate) if actual_fee_rate is not None else None,
            "actual_fee_matches_strategy": actual_matches,
            "fee_agreement_ok": all(observed_matches) if observed_matches else None,
        }

    def _fee_state_valid(self, pair: str) -> tuple[bool, str]:
        ok, reason = self._config_fee_state_valid()
        if not ok:
            return False, reason

        snapshot = self._fee_snapshot(pair)
        if snapshot.get("exchange_maker_fee_matches_strategy") is False:
            return False, "exchange_fee_mismatch"

        is_dry_run = bool(getattr(self, "config", {}).get("dry_run", True))
        if (
            bool(self.trading_enabled)
            and not is_dry_run
            and bool(self.post_only_verified)
            and bool(self.require_exchange_fee_match_live)
            and snapshot.get("exchange_maker_fee_rate") is None
        ):
            return False, "exchange_fee_unavailable"

        return True, "ok"

    def _markout_value(self, quote_side: str | None, fill_price: float, future_mid_price: float) -> float | None:
        if quote_side == "bid":
            return float(future_mid_price) - float(fill_price)
        if quote_side == "ask":
            return float(fill_price) - float(future_mid_price)
        return None

    def _pending_fill_markout_entries(self) -> list[dict[str, Any]]:
        pending = getattr(self, "_pending_fill_markouts", None)
        if not isinstance(pending, list):
            pending = []
            self._pending_fill_markouts = pending
        return pending

    def _schedule_fill_markouts(self, fill_payload: dict[str, Any], current_time: datetime) -> None:
        quote_side = fill_payload.get("quote_side")
        fill_price = self._finite_float_or_none(fill_payload.get("price"))
        amount = self._finite_float_or_none(fill_payload.get("amount"))
        if quote_side not in {"bid", "ask"} or fill_price is None or amount is None or amount <= 0:
            return

        horizons = []
        for horizon in getattr(self, "fill_markout_horizons_ms", ()):
            try:
                horizon_int = int(horizon)
            except Exception:
                continue
            if horizon_int > 0:
                horizons.append(horizon_int)
        if not horizons:
            return

        fill_ts = self._as_utc(current_time) or self._now_utc()
        self._pending_fill_markout_entries().append(
            {
                "pair": fill_payload.get("pair"),
                "trade_id": fill_payload.get("trade_id"),
                "order_id": fill_payload.get("order_id"),
                "quote_side": quote_side,
                "fill_price": float(fill_price),
                "amount": float(amount),
                "fill_ts": fill_ts,
                "remaining_horizons_ms": sorted(set(horizons)),
            }
        )

    def _process_pending_fill_markouts(self, pair: str, current_time: datetime) -> None:
        pending = self._pending_fill_markout_entries()
        if not pending:
            return

        now = self._as_utc(current_time) or self._now_utc()
        keep: list[dict[str, Any]] = []
        for entry in pending:
            if entry.get("pair") != pair:
                keep.append(entry)
                continue

            fill_ts = self._as_utc(entry.get("fill_ts"))
            if fill_ts is None:
                continue

            due_horizons = []
            remaining_horizons = []
            for horizon_ms in entry.get("remaining_horizons_ms", []):
                due_at = fill_ts + timedelta(milliseconds=int(horizon_ms))
                if now >= due_at:
                    due_horizons.append(int(horizon_ms))
                else:
                    remaining_horizons.append(int(horizon_ms))

            if due_horizons:
                future_mid = self.get_mid_price(pair, float(entry["fill_price"]))
                for horizon_ms in due_horizons:
                    markout = self._markout_value(entry.get("quote_side"), float(entry["fill_price"]), future_mid)
                    if markout is None:
                        continue
                    self._debug_log_event(
                        "fill_markout",
                        {
                            "pair": pair,
                            "trade_id": entry.get("trade_id"),
                            "order_id": entry.get("order_id"),
                            "quote_side": entry.get("quote_side"),
                            "horizon_ms": int(horizon_ms),
                            "fill_ts": fill_ts.isoformat().replace("+00:00", "Z"),
                            "markout_ts": now.isoformat().replace("+00:00", "Z"),
                            "fill_price": float(entry["fill_price"]),
                            "future_mid": float(future_mid),
                            "amount": float(entry["amount"]),
                            "markout_usdc_per_base": float(markout),
                            "markout_usdc": float(markout) * float(entry["amount"]),
                        },
                    )

            if remaining_horizons:
                entry["remaining_horizons_ms"] = remaining_horizons
                keep.append(entry)

        self._pending_fill_markouts = keep

    def _extract_order_fee_paid(self, order: Order, price: float | None, amount: float | None) -> float | None:
        fee = getattr(order, "fee", None)
        if isinstance(fee, dict):
            for key in ("cost", "fee_cost", "paid", "amount"):
                value = self._finite_float_or_none(fee.get(key))
                if value is not None:
                    return value
            rate = self._finite_float_or_none(fee.get("rate"))
            if rate is not None and price is not None and amount is not None:
                return abs(float(price) * float(amount) * rate)
        else:
            value = self._finite_float_or_none(fee)
            if value is not None:
                return value

        for attr in ("fee_cost", "ft_fee_cost", "cost"):
            value = self._finite_float_or_none(getattr(order, attr, None))
            if value is not None:
                return value
        return None

    def _extract_order_fee_rate(
        self,
        order: Order,
        fee_paid: float | None,
        price: float | None,
        amount: float | None,
    ) -> float | None:
        fee = getattr(order, "fee", None)
        if isinstance(fee, dict):
            value = self._finite_float_or_none(fee.get("rate"))
            if value is not None:
                return value

        for attr in ("fee_rate", "ft_fee_rate"):
            value = self._finite_float_or_none(getattr(order, attr, None))
            if value is not None:
                return value

        if fee_paid is not None and price is not None and amount is not None:
            notional = abs(float(price) * float(amount))
            if notional > 0:
                return abs(float(fee_paid)) / notional
        return None

    def _record_realized_pnl(self, pair: str, pnl_usdc: float, current_time: datetime, payload: dict[str, Any]) -> None:
        self._reset_daily_risk_if_needed(current_time)
        event_id = payload.get("order_id")
        if event_id is not None:
            seen = getattr(self, "_seen_pnl_event_ids", None)
            if seen is None:
                seen = set()
                self._seen_pnl_event_ids = seen
            if event_id in seen:
                return
            seen.add(event_id)

        self._daily_realized_pnl_usdc = float(getattr(self, "_daily_realized_pnl_usdc", 0.0)) + float(pnl_usdc)
        if pnl_usdc < 0:
            self._consecutive_losses = int(getattr(self, "_consecutive_losses", 0)) + 1
        elif pnl_usdc > 0:
            self._consecutive_losses = 0

        risk_payload = {
            "pair": pair,
            "realized_pnl": float(pnl_usdc),
            "daily_realized_pnl": float(self._daily_realized_pnl_usdc),
            "max_daily_loss_usdc": float(self.max_daily_loss_usdc),
            "consecutive_losses": int(self._consecutive_losses),
            "max_consecutive_losses": int(self.max_consecutive_losses),
            "order_id": payload.get("order_id"),
            "trade_id": payload.get("trade_id"),
            "quote_side": payload.get("quote_side"),
            "liquidity": payload.get("liquidity"),
        }
        self._debug_log_event("risk_update", risk_payload)

        if self.trading_enabled and self._daily_realized_pnl_usdc <= -abs(float(self.max_daily_loss_usdc)):
            self._trigger_kill_switch(
                "drawdown_limit_reached",
                {**payload, **risk_payload},
            )
        if self.trading_enabled and self._consecutive_losses >= int(self.max_consecutive_losses):
            self._trigger_kill_switch(
                "consecutive_losses_limit_reached",
                {**payload, **risk_payload},
            )

    def _log_spread(self, side: str, mid_price: float, delta: float, source: str) -> None:
        """
        Log the applied spread in basis points off mid, with its origin.
        """
        if mid_price <= 0:
            bps = float("nan")
        else:
            bps = (delta / mid_price) * 10_000.0
        logger.info(
            f"[spread] side={side} bps={bps:.2f} abs={delta:.6f} mid={mid_price:.6f} source={source}"
        )

    def _open_order_count(self, pair: str) -> int | None:
        exchange = getattr(self, "exchange", None)
        if exchange is not None:
            for method_name in ("fetch_open_orders", "get_open_orders"):
                method = getattr(exchange, method_name, None)
                if not callable(method):
                    continue
                try:
                    orders = method(pair)
                except TypeError:
                    try:
                        orders = method()
                    except Exception:
                        continue
                except Exception:
                    continue
                try:
                    self._last_open_order_count_source = method_name
                    return len(list(orders or []))
                except Exception:
                    return None

            orders = getattr(exchange, "open_orders", None)
            if isinstance(orders, dict):
                if pair in orders and isinstance(orders[pair], list):
                    self._last_open_order_count_source = "exchange_open_orders"
                    return len(orders[pair])
                count = 0
                for value in orders.values():
                    if isinstance(value, list):
                        count += len(value)
                self._last_open_order_count_source = "exchange_open_orders"
                return count
            if isinstance(orders, list):
                count = 0
                for order in orders:
                    if not isinstance(order, dict):
                        continue
                    symbol = order.get("symbol") or order.get("pair")
                    if symbol is None or str(symbol) == pair:
                        count += 1
                self._last_open_order_count_source = "exchange_open_orders"
                return count
        return self._open_order_count_from_trades(pair)

    def _exchange_open_orders_for_pair(self, pair: str) -> tuple[list[Any] | None, str | None]:
        exchange = getattr(self, "exchange", None)
        if exchange is None:
            return None, None

        for method_name in ("fetch_open_orders", "get_open_orders"):
            method = getattr(exchange, method_name, None)
            if not callable(method):
                continue
            try:
                orders = method(pair)
            except TypeError:
                try:
                    orders = method()
                except Exception:
                    continue
            except Exception:
                continue
            try:
                order_list = list(orders or [])
            except TypeError:
                order_list = []
            return [order for order in order_list if self._order_matches_pair(order, pair)], method_name

        orders = getattr(exchange, "open_orders", None)
        if isinstance(orders, dict):
            if pair in orders and isinstance(orders[pair], list):
                return list(orders[pair]), "exchange_open_orders"
            order_list: list[Any] = []
            for value in orders.values():
                if isinstance(value, list):
                    order_list.extend(value)
            return [order for order in order_list if self._order_matches_pair(order, pair)], "exchange_open_orders"
        if isinstance(orders, list):
            return [order for order in orders if self._order_matches_pair(order, pair)], "exchange_open_orders"
        return None, None

    def _order_matches_pair(self, order: Any, pair: str) -> bool:
        if isinstance(order, dict):
            symbol = order.get("symbol") or order.get("pair")
        else:
            symbol = getattr(order, "symbol", None) or getattr(order, "pair", None)
        return symbol is None or str(symbol) == pair

    def _order_id_for_cancel(self, order: Any) -> Any:
        if isinstance(order, dict):
            for key in ("id", "order_id", "ft_order_id", "clientOrderId", "client_order_id"):
                value = order.get(key)
                if value not in (None, ""):
                    return value
            return None
        for attr in ("id", "order_id", "ft_order_id", "clientOrderId", "client_order_id"):
            value = getattr(order, attr, None)
            if value not in (None, ""):
                return value
        return None

    def _cancel_open_orders_for_kill_switch(self, pair: Any) -> dict[str, Any]:
        if not pair:
            return {"cancel_open_orders_requested": 0, "cancel_method": "no_pair"}
        exchange = getattr(self, "exchange", None)
        if exchange is None:
            return {"cancel_open_orders_requested": 0, "cancel_method": "no_exchange"}

        cancel_all = getattr(exchange, "cancel_all_orders", None)
        if callable(cancel_all):
            cancel_count = self._open_order_count(str(pair))
            cancel_all(pair)
            requested = int(cancel_count) if cancel_count is not None else 1
            if requested > 0:
                self._record_open_order_cancel_request(requested)
            return {
                "cancel_open_orders_requested": requested,
                "cancel_method": "cancel_all_orders",
            }

        cancel_one = getattr(exchange, "cancel_order", None) or getattr(exchange, "cancel", None)
        if not callable(cancel_one):
            return {"cancel_open_orders_requested": 0, "cancel_method": "unavailable"}

        orders, source = self._exchange_open_orders_for_pair(str(pair))
        if orders is None:
            return {"cancel_open_orders_requested": 0, "cancel_method": "no_open_order_source"}

        cancelled_ids: list[str] = []
        cancel_errors: list[dict[str, Any]] = []
        for order in orders:
            if not self._order_looks_open(order):
                continue
            order_id = self._order_id_for_cancel(order)
            if order_id is None:
                cancel_errors.append({"order_id": None, "error": "missing_order_id"})
                continue
            try:
                try:
                    cancel_one(order_id, str(pair))
                except TypeError:
                    cancel_one(order_id)
                cancelled_ids.append(str(order_id))
            except Exception as exc:
                cancel_errors.append({"order_id": str(order_id), "error": str(exc)})

        if cancelled_ids:
            self._record_open_order_cancel_request(len(cancelled_ids))
        return {
            "cancel_open_orders_requested": len(cancelled_ids),
            "cancel_method": getattr(cancel_one, "__name__", "cancel_order"),
            "cancel_source": source,
            "cancelled_order_ids": cancelled_ids,
            "cancel_errors": cancel_errors,
        }

    def _open_order_count_from_trades(self, pair: str) -> int | None:
        open_order_trades = self._freqtrade_open_order_trades(pair)
        if open_order_trades:
            count = 0
            for trade in open_order_trades:
                order_count = self._open_order_count_for_trade(trade)
                count += order_count if order_count is not None else 1
            self._last_open_order_count_source = "freqtrade_open_order_trades"
            return count

        try:
            open_trades = list(Trade.get_trades_proxy(is_open=True, pair=pair) or [])
        except Exception:
            return self._estimated_open_order_count()

        if not open_trades:
            self._last_open_order_count_source = "freqtrade_open_trades"
            return 0

        count = 0
        observed_order_state = False
        for trade in open_trades:
            orders = getattr(trade, "orders", None)
            if callable(orders):
                try:
                    orders = orders()
                except Exception:
                    orders = None
            if orders is not None:
                try:
                    order_list = list(orders)
                except TypeError:
                    order_list = []
                observed_order_state = True
                count += sum(1 for order in order_list if self._order_looks_open(order))
                continue

            has_open_orders = getattr(trade, "has_open_orders", None)
            if callable(has_open_orders):
                try:
                    has_open_orders = has_open_orders()
                except Exception:
                    has_open_orders = None
            if has_open_orders is not None:
                observed_order_state = True
                if bool(has_open_orders):
                    count += 1

        if observed_order_state:
            self._last_open_order_count_source = "freqtrade_open_trades"
            return count
        return self._estimated_open_order_count()

    def _estimated_open_order_count(self) -> int:
        attempts = int(getattr(self, "_accepted_order_attempts", 0))
        fills = int(getattr(self, "_maker_fill_count", 0)) + int(getattr(self, "_taker_fill_count", 0))
        cancels = int(getattr(self, "_cancel_open_order_requests", 0))
        self._last_open_order_count_source = "accepted_confirmation_estimate"
        return max(0, attempts - fills - cancels)

    def _freqtrade_open_order_trades(self, pair: str) -> list[Any] | None:
        method = getattr(Trade, "get_open_order_trades", None)
        if not callable(method):
            return None
        try:
            trades = list(method() or [])
        except Exception:
            return None

        matching = []
        for trade in trades:
            trade_pair = getattr(trade, "pair", None)
            if trade_pair is None or str(trade_pair) == pair:
                matching.append(trade)
        return matching

    def _open_order_count_for_trade(self, trade: Any) -> int | None:
        orders = getattr(trade, "orders", None)
        if callable(orders):
            try:
                orders = orders()
            except Exception:
                orders = None
        if orders is not None:
            try:
                order_list = list(orders)
            except TypeError:
                order_list = []
            return sum(1 for order in order_list if self._order_looks_open(order))

        has_open_orders = getattr(trade, "has_open_orders", None)
        if callable(has_open_orders):
            try:
                has_open_orders = has_open_orders()
            except Exception:
                has_open_orders = None
        if has_open_orders is not None:
            return 1 if bool(has_open_orders) else 0
        return None

    def _order_looks_open(self, order: Any) -> bool:
        if isinstance(order, dict):
            status = order.get("status")
            is_open = order.get("is_open")
            remaining = order.get("remaining", order.get("safe_remaining"))
        else:
            status = getattr(order, "status", None)
            is_open = getattr(order, "is_open", None)
            remaining = getattr(order, "remaining", getattr(order, "safe_remaining", None))

        if is_open is not None:
            return bool(is_open)

        text = str(status).strip().lower() if status is not None else ""
        if text in {"closed", "filled", "canceled", "cancelled", "expired", "rejected"}:
            return False

        remaining_float = self._finite_float_or_none(remaining)
        if remaining_float is not None and remaining_float > 0:
            return True

        if not text:
            return False
        if text in {"open", "new", "created", "pending", "partially_filled", "partially-filled"}:
            return True
        return False

    def _unrealized_pnl_usdc(self, pair: str) -> float | None:
        mid_price = self.get_mid_price(pair, 0.0)
        if not np.isfinite(float(mid_price)) or float(mid_price) <= 0:
            return None

        signed_base = self._signed_base_position(pair)
        if abs(float(signed_base)) <= 1e-12:
            return 0.0

        try:
            open_trades = list(Trade.get_trades_proxy(is_open=True, pair=pair) or [])
        except Exception:
            open_trades = []

        pnl = 0.0
        measured_base = 0.0
        for trade in open_trades:
            amount = self._finite_float_or_none(getattr(trade, "amount", None))
            open_rate = self._finite_float_or_none(getattr(trade, "open_rate", None))
            if amount is None or open_rate is None or open_rate <= 0:
                continue
            amount = abs(float(amount))
            if amount <= 0:
                continue
            if bool(getattr(trade, "is_short", False)):
                pnl += (float(open_rate) - float(mid_price)) * amount
                measured_base -= amount
            else:
                pnl += (float(mid_price) - float(open_rate)) * amount
                measured_base += amount

        if abs(measured_base) <= 1e-12:
            return None
        return float(pnl)

    def _debug_log_path(self) -> Path:
        """Shared JSONL path, with the emitting role stamped on every record.

        Both instances write here. That is deliberate: run_safety_gates.py,
        verify_dry_run_{enabled,disabled}.py and calibrate_replay_from_logs.py
        all default to this exact path and thread a single Path through many
        call sites, so a per-role filename points every gate at a file nothing
        writes. Attribution is solved by the "role" field on each record instead
        (see _debug_log_event).

        Known limitation: two writers share one rotation. _rotate_debug_log_if_needed
        can therefore drop records from the other leg at the rotation boundary.
        Acceptable for a diagnostic stream; do not put trading state here.
        """
        try:
            base = Path(__file__).resolve().parent.parent  # user_data
        except Exception:
            base = Path.cwd()
        return base / "logs" / self.debug_json_log_filename

    def _rotate_debug_log_if_needed(self, path: Path) -> None:
        """Roll .1 -> .2 -> ... -> debug_json_log_backup_count, dropping the oldest.

        Keeping a single backup bounded the retained history at roughly two
        files' worth -- about 66 minutes at the measured 3.7 MB/hour against the
        2 MB cap. Everything downstream reads this stream
        (calibrate_replay_from_logs.py for the replay's fill model, and the
        dry-run quality / live canary / fee evidence gates), so that cap was
        deciding how much evidence a multi-day run could ever produce.
        """
        max_bytes = int(getattr(self, "debug_json_log_max_bytes", 0) or 0)
        if max_bytes <= 0:
            return
        keep = max(1, int(getattr(self, "debug_json_log_backup_count", 1) or 1))
        try:
            if not path.exists() or path.stat().st_size <= max_bytes:
                return
            oldest = path.with_suffix(f"{path.suffix}.{keep}")
            if oldest.exists():
                oldest.unlink()
            for index in range(keep - 1, 0, -1):
                source = path.with_suffix(f"{path.suffix}.{index}")
                if source.exists():
                    source.replace(path.with_suffix(f"{path.suffix}.{index + 1}"))
            path.replace(path.with_suffix(f"{path.suffix}.1"))
        except Exception:
            return

    def _debug_log_event(self, event: str, payload: dict[str, Any]) -> None:
        if not getattr(self, "debug_json_log", False):
            return
        record = {
            # datetime.utcnow() is deprecated from Python 3.12 (the image runs
            # 3.13) and returns a naive datetime that only looks like UTC. Use
            # the same aware-UTC helper every other timestamp in this file uses.
            "ts": self._now_utc().isoformat(timespec="milliseconds").replace("+00:00", "Z"),
            "event": event,
            # Which leg emitted this. Both instances share the file, and without
            # this a rejected quote cannot be attributed to the leg that made it.
            "role": str(getattr(self, "role", "") or "") or None,
            **payload,
        }
        path = self._debug_log_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with self._debug_log_lock:
                self._rotate_debug_log_if_needed(path)
                with path.open("a", encoding="utf-8") as f:
                    json.dump(record, f, ensure_ascii=False, separators=(",", ":"), default=str)
                    f.write("\n")
        except Exception:
            return

    def _params_snapshot(self, symbol: str) -> dict[str, Any]:
        snapshot: dict[str, Any] = {"symbol": symbol, "sources": {}}
        sources: dict[str, Any] = snapshot["sources"]
        try:
            if isinstance(self.kappas, dict):
                entry = self.kappas[symbol]
                snapshot["kappa_plus"] = float(entry["kappa+"])
                snapshot["kappa_minus"] = float(entry["kappa-"])
                sources["kappa"] = self._param_source_metadata(
                    entry,
                    extra_keys=("n_points_plus", "n_points_minus", "r2_plus", "r2_minus", "window_start", "window_end"),
                )
        except Exception:
            pass
        try:
            if isinstance(self.epsilons, dict):
                entry = self.epsilons[symbol]
                snapshot["epsilon_plus"] = float(entry["epsilon+"])
                snapshot["epsilon_minus"] = float(entry["epsilon-"])
                sources["epsilon"] = self._param_source_metadata(
                    entry,
                    extra_keys=("n_buy_events", "n_sell_events", "estimator", "window_ms", "window_start", "window_end"),
                )
        except Exception:
            pass
        try:
            if isinstance(self.lambdas, dict):
                entry = self.lambdas.get(symbol, {})
                snapshot["lambda_plus"] = float(entry.get("lambda+", 0.0))
                snapshot["lambda_minus"] = float(entry.get("lambda-", 0.0))
                sources["lambda"] = self._param_source_metadata(
                    entry,
                    extra_keys=("lambda_source", "n_trades", "n_trades_total", "window_start", "window_end"),
                )
        except Exception:
            pass

        snapshot["fees_maker_HL"] = float(self.fees_maker_HL)
        snapshot["hjb_alpha"] = float(self.hjb_alpha)
        snapshot["hjb_phi"] = float(self.hjb_phi)
        snapshot["hjb_q_max"] = int(self.hjb_q_max)
        snapshot["hjb_horizon_seconds"] = float(self.hjb_horizon_seconds)
        snapshot["use_asymmetric_kappa"] = bool(self.use_asymmetric_kappa)

        return snapshot

    def _param_source_metadata(self, entry: Any, *, extra_keys: tuple[str, ...]) -> dict[str, Any]:
        if not isinstance(entry, dict):
            return {}
        metadata: dict[str, Any] = {}
        for key in ("schema_version", "status", "generated_at", *extra_keys):
            if key in entry:
                metadata[key] = entry.get(key)
        return metadata

    def _params_fingerprint(self, snapshot: dict[str, Any]) -> str:
        payload = json.dumps(snapshot, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]

    def _hjb_snapshot(self) -> dict[str, Any] | None:
        cache = self.hjb_cache
        if not cache:
            return None

        def to_list(val: Any) -> Any:
            if val is None:
                return None
            if isinstance(val, np.ndarray):
                return [float(x) for x in val.tolist()]
            if isinstance(val, (list, tuple)):
                return [float(x) for x in val]
            if isinstance(val, (np.floating, np.integer)):
                return val.item()
            return val

        tau = self._tau_remaining()
        snapshot = {
            "method": cache.get("method", "matrix_exponential"),
            "q_grid": to_list(cache.get("q_grid")),
            # The t=0 slice. In episodic mode that is the START of the episode,
            # not what is being quoted right now -- see delta_*_at_tau below.
            # Deliberately whitelisted rather than dumped: the (t,q) surface is
            # ~600x13 floats and would swamp every JSONL record.
            "delta_plus": to_list(cache.get("delta_plus")),
            "delta_minus": to_list(cache.get("delta_minus")),
            "kappa_sym": to_list(cache.get("kappa_sym")),
            "kappa_plus": to_list(cache.get("kappa_plus")),
            "kappa_minus": to_list(cache.get("kappa_minus")),
            "dt": to_list(cache.get("dt")),
            "n_steps": to_list(cache.get("n_steps")),
            "hjb_time_mode": cache.get("hjb_time_mode", "stationary"),
            "has_surface": "delta_plus_surface" in cache,
            "tau_remaining_seconds": None if tau is None else float(tau),
            "episode_id": int(self._episode_id),
            # The risk parameters the solve actually ran with, as opposed to the
            # configured targets. phi is derived from hjb_phi_kappa_t and then
            # has the volatility term added, so neither the config nor the
            # params snapshot tells you what was solved; without these the
            # sigma2 channel is invisible in every log we keep.
            "phi_effective": to_list(cache.get("phi_effective")),
            "phi_source": cache.get("phi_source"),
            "alpha_effective": to_list(cache.get("alpha_effective")),
            "sigma2_per_sec": to_list(cache.get("sigma2_per_sec")),
        }
        if tau is not None and "delta_plus_surface" in cache:
            q_grid = np.asarray(cache["q_grid"])
            snapshot["delta_plus_at_tau"] = [
                self._mm_core.select_delta(cache, int(q), "ask", tau_remaining=tau)
                for q in q_grid
            ]
            snapshot["delta_minus_at_tau"] = [
                self._mm_core.select_delta(cache, int(q), "bid", tau_remaining=tau)
                for q in q_grid
            ]
        return snapshot

    def _log_quote_decision(
        self,
        *,
        pair: str,
        symbol: str,
        side: str,
        action: str,
        decision: str,
        reason: str,
        mid_price: float,
        proposed_rate: float,
        raw_price: float | None = None,
        rounded_price: float | None = None,
        delta_model: float | None = None,
        fee_cushion: float | None = None,
        delta_total: float | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        now = self._now_utc()
        quote_id = self._next_quote_id()
        snapshot, book_snapshot_reason = self._book_snapshot(pair)
        params_ok, params_reason = self._params_are_valid(pair)
        collector_ok, collector_reason = self._market_data_fresh(symbol)
        book_ok, book_reason = self._book_is_fresh(pair, now)
        expected_tif = self._expected_time_in_force(side)
        expected_tif_canonical = self._canonical_tif(expected_tif)
        config = getattr(self, "config", {}) if isinstance(getattr(self, "config", {}), dict) else {}
        payload = {
            "quote_id": quote_id,
            "action": action,
            "pair": pair,
            "symbol": symbol,
            "side": side,
            "trading_enabled": bool(self.trading_enabled),
            "dry_run": bool(config.get("dry_run", True)),
            "decision": decision,
            "reason": reason,
            "mid": float(mid_price) if mid_price is not None else None,
            "best_bid": snapshot.get("best_bid") if snapshot else None,
            "best_ask": snapshot.get("best_ask") if snapshot else None,
            "proposed_rate": float(proposed_rate) if proposed_rate is not None else None,
            "raw_price": float(raw_price) if raw_price is not None else None,
            "rounded_price": float(rounded_price) if rounded_price is not None else None,
            "delta_model": float(delta_model) if delta_model is not None else None,
            "fee_cushion": float(fee_cushion) if fee_cushion is not None else None,
            "delta_total": float(delta_total) if delta_total is not None else None,
            "hjb_generation": int(self._hjb_generation),
            "hjb_last_refresh_ts": self._hjb_last_refresh_ts,
            "hjb_param_fingerprint": self._hjb_param_fingerprint,
            "hjb_age_seconds": self._hjb_age_seconds(now),
            # Derived here rather than passed in by each of the ~20 call sites:
            # a coordinate only some decisions carry is worse than useless when
            # you are trying to explain a fill after the fact.
            **self._pricing_state_payload(pair),
            "param_age_seconds": self._param_age_seconds(symbol, now),
            "collector_age_seconds": self._collector_age_seconds(symbol, now),
            "book_age_ms": self._book_age_ms(pair, now),
            "params_fresh": bool(params_ok),
            "params_fresh_reason": params_reason,
            "collector_fresh": bool(collector_ok),
            "collector_fresh_reason": collector_reason,
            "book_fresh": bool(book_ok),
            "book_fresh_reason": book_reason if snapshot else book_snapshot_reason,
            "expected_tif": expected_tif,
            "expected_tif_canonical": expected_tif_canonical,
            "post_only": expected_tif_canonical == "post_only",
            "post_only_verified": bool(self.post_only_verified),
            "params": self._params_snapshot(symbol),
            "hjb_params": self._hjb_params_snapshot,
            "fee_snapshot": self._fee_snapshot(pair),
            **self._inventory_snapshot(pair),
            "position_risk": self._position_risk_snapshot(pair, rate=rounded_price or proposed_rate, side=side),
            **(extra or {}),
        }
        if action in {"entry", "exit", "adjust_entry", "adjust_exit"}:
            self._record_quote_decision(pair, decision, reason)
        self._remember_quote_decision(payload, now)
        self._debug_log_event("quote_decision", payload)

    def _log_health(self, pair: str, current_time: datetime) -> None:
        now = self._as_utc(current_time) or self._now_utc()
        if self._last_health_log and (now - self._last_health_log) < timedelta(seconds=60):
            return
        symbol = self._symbol_from_pair(pair)
        params_ok, params_reason = self._params_are_valid(pair)
        collector_ok, collector_reason = self._market_data_fresh(symbol)
        book_ok, book_reason = self._book_is_fresh(pair, now)
        hjb_fresh = self.hjb_cache is not None and not self._hjb_is_stale(now)
        open_order_count = self._open_order_count(pair)
        open_order_source = getattr(self, "_last_open_order_count_source", "unavailable")
        config = getattr(self, "config", {}) if isinstance(getattr(self, "config", {}), dict) else {}
        mm_config = self._mm_config()
        entry_tif = self._expected_time_in_force("bid")
        exit_tif = self._expected_time_in_force("ask")
        self._debug_log_event(
            "health",
            {
                "pair": pair,
                "symbol": symbol,
                "trading_enabled": bool(self.trading_enabled),
                "fail_closed_reason": self.fail_closed_reason,
                "dry_run": bool(config.get("dry_run", True)),
                "stake_amount": config.get("stake_amount"),
                "tradable_balance_ratio": config.get("tradable_balance_ratio"),
                "collector_fresh": collector_ok,
                "collector_fresh_reason": collector_reason,
                "collector_age_seconds": self._collector_age_seconds(symbol, now),
                "params_fresh": params_ok,
                "params_fresh_reason": params_reason,
                "param_age_seconds": self._param_age_seconds(symbol, now),
                "param_source": self._param_source,
                "book_fresh": book_ok,
                "book_fresh_reason": book_reason,
                "book_age_ms": self._book_age_ms(pair, now),
                "hjb_fresh": hjb_fresh,
                "hjb_age_seconds": self._hjb_age_seconds(now),
                "post_only_verified": bool(self.post_only_verified),
                "deployment_stage": str(mm_config.get("deployment_stage") or "research"),
                "deployment_gate_reports_required": True,
                "manual_monitoring_ack": bool(mm_config.get("manual_monitoring_ack", False)),
                "max_deployment_report_age_seconds": float(self.max_deployment_report_age_seconds),
                "expected_entry_time_in_force": entry_tif,
                "expected_exit_time_in_force": exit_tif,
                "expected_entry_time_in_force_canonical": self._canonical_tif(entry_tif),
                "expected_exit_time_in_force_canonical": self._canonical_tif(exit_tif),
                "kill_on_taker_fill": bool(self.kill_on_taker_fill),
                "kill_on_time_in_force_mismatch": bool(self.kill_on_time_in_force_mismatch),
                "kill_on_unknown_liquidity_fill": bool(self.kill_on_unknown_liquidity_fill),
                "fee_snapshot": self._fee_snapshot(pair),
                "open_orders": open_order_count,
                "open_orders_source": open_order_source,
                "accepted_order_attempts": int(getattr(self, "_accepted_order_attempts", 0)),
                "open_order_cancels_requested": int(getattr(self, "_cancel_open_order_requests", 0)),
                "maker_fills": int(getattr(self, "_maker_fill_count", 0)),
                "taker_fills": int(getattr(self, "_taker_fill_count", 0)),
                "post_only_rejects": int(getattr(self, "_post_only_rejects", 0)),
                "max_post_only_reject_rate": float(self.max_post_only_reject_rate),
                "quote_decisions": int(getattr(self, "_quote_decisions_count", 0)),
                "realized_pnl": float(getattr(self, "_daily_realized_pnl_usdc", 0.0)),
                "max_daily_loss_usdc": float(self.max_daily_loss_usdc),
                "unrealized_pnl": self._unrealized_pnl_usdc(pair),
                "consecutive_losses": int(getattr(self, "_consecutive_losses", 0)),
                "max_consecutive_losses": int(self.max_consecutive_losses),
                "max_abs_inventory_units": int(self.max_abs_inventory_units),
                **{
                    key: value
                    for key, value in self._position_risk_snapshot(pair).items()
                    if key
                    in {
                        "notional_exposure_usdc",
                        "current_notional_exposure_usdc",
                        "max_notional_exposure_usdc",
                        "margin_used_usdc",
                        "max_margin_used_usdc",
                        "account_equity_usdc",
                        "maintenance_margin_usdc",
                        "liquidation_buffer_usdc",
                        "min_liquidation_buffer_usdc",
                    }
                },
                **self._inventory_snapshot(pair),
            },
        )
        self._last_health_log = now

    def custom_entry_price(self, pair: str, trade: Trade | None, current_time: datetime, proposed_rate: float,
                           entry_tag: str | None, side: str, **kwargs) -> float:

        if side == 'short' and not self.can_short:
            return proposed_rate

        mid_price = self.get_mid_price(pair, proposed_rate)
        symbol = self._symbol_from_pair(pair)
        if self.hjb_cache is None:
            self._refresh_hjb(pair)

        _, q_exact, tau = self._pricing_state(pair)
        delta_m = self._select_delta(
            self._physical_quote_side('entry'), q_exact, tau_remaining=tau
        )
        if delta_m is None or not np.isfinite(float(delta_m)):
            logger.warning("No HJB delta available for bid; skipping entry pricing.")
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("entry"),
                action="entry",
                decision="reject",
                reason=self._no_delta_reason(),
                mid_price=mid_price,
                proposed_rate=proposed_rate,
            )
            return proposed_rate
        if not self._inventory_allows_quote(pair, "entry"):
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("entry"),
                action="entry",
                decision="reject",
                reason="position_limit_reached",
                mid_price=mid_price,
                proposed_rate=proposed_rate,
            )
            return proposed_rate
        delta_source = "hjb_grid"

        delta_model = float(delta_m)
        quote_side, side_sign = self._quote_side_and_sign("entry")
        delta_total, spread_info = self._assemble_half_spread(pair, quote_side, delta_model, mid_price)
        fee_cushion = float(spread_info["fee_cushion"])
        raw_rate = mid_price + side_sign * delta_total
        returned_rate = self._round_quote_price(pair, quote_side, raw_rate)
        self._log_spread("bid", mid_price, delta_total, delta_source)
        logger.info(f"Calculated bid: {returned_rate:.5f}")

        ok, reason = self._quote_state_valid(pair, self._physical_quote_side("entry"), returned_rate, current_time)
        if not ok:
            self._remember_custom_price_rejection(
                pair=pair,
                quote_side=self._physical_quote_side("entry"),
                reason=reason,
                current_time=current_time,
                rate=returned_rate,
            )
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("entry"),
                action="entry",
                decision="reject",
                reason=reason,
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                raw_price=raw_rate,
                rounded_price=returned_rate,
                delta_model=delta_model,
                fee_cushion=fee_cushion,
                delta_total=delta_total,
                extra=dict(spread_info),
            )
            return proposed_rate

        distance_ok, distance_reason, distance_payload = self._custom_price_distance_valid(returned_rate, proposed_rate)
        if not distance_ok:
            self._remember_custom_price_rejection(
                pair=pair,
                quote_side=self._physical_quote_side("entry"),
                reason=distance_reason,
                current_time=current_time,
                rate=returned_rate,
            )
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("entry"),
                action="entry",
                decision="reject",
                reason=distance_reason,
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                raw_price=raw_rate,
                rounded_price=returned_rate,
                delta_model=delta_model,
                fee_cushion=fee_cushion,
                delta_total=delta_total,
                extra={
                    **spread_info,
                    **distance_payload,
                },
            )
            return proposed_rate

        ok, reason = self._maker_safe(pair, self._physical_quote_side("entry"), returned_rate)
        if not ok:
            self._remember_custom_price_rejection(
                pair=pair,
                quote_side=self._physical_quote_side("entry"),
                reason=reason,
                current_time=current_time,
                rate=returned_rate,
            )
        else:
            self._clear_custom_price_rejection(pair, "bid")
        self._log_quote_decision(
            pair=pair,
            symbol=symbol,
            side=self._physical_quote_side("entry"),
            action="entry",
            decision="accept" if ok else "reject",
            reason=reason,
            mid_price=mid_price,
            proposed_rate=proposed_rate,
            raw_price=raw_rate,
            rounded_price=returned_rate,
            delta_model=delta_model,
            fee_cushion=fee_cushion,
            delta_total=delta_total,
            extra={
                **spread_info,
                **distance_payload,
            },
        )
        return returned_rate if ok else proposed_rate

    def custom_stake_amount(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        proposed_stake: float,
        min_stake: float | None,
        max_stake: float,
        leverage: float = 1.0,
        entry_tag: str | None = None,
        side: str = "long",
        **kwargs,
    ) -> float:
        if side == "short" and not self.can_short:
            return proposed_stake
        try:
            rate = float(current_rate)
            proposed = float(proposed_stake)
            maximum = float(max_stake) if max_stake is not None else proposed
        except Exception:
            return proposed_stake
        if not np.isfinite(rate) or rate <= 0 or not np.isfinite(proposed) or proposed <= 0:
            return proposed_stake

        one_unit_stake = float(self.inventory_unit_base) * rate
        risk_cap = min(proposed, maximum, one_unit_stake)
        min_stake_value = None
        if min_stake is not None:
            try:
                min_stake_value = float(min_stake)
            except Exception:
                min_stake_value = None
        if min_stake_value is not None and min_stake_value > risk_cap:
            self._debug_log_event(
                "stake_rejected",
                {
                    "pair": pair,
                    "side": side,
                    "entry_tag": entry_tag,
                    "reason": "min_stake_exceeds_inventory_unit",
                    "current_rate": rate,
                    "proposed_stake": proposed,
                    "min_stake": min_stake_value,
                    "max_stake": maximum,
                    "risk_cap": float(risk_cap),
                    "inventory_unit_base": float(self.inventory_unit_base),
                    "leverage": float(leverage),
                },
            )
            return 0.0

        stake = float(risk_cap)
        raw_amount = stake / rate
        rounded_amount = self._round_quote_amount(pair, raw_amount)
        amount_rounding_applied = False
        if rounded_amount <= 0:
            self._debug_log_event(
                "stake_rejected",
                {
                    "pair": pair,
                    "side": side,
                    "entry_tag": entry_tag,
                    "reason": "amount_rounds_to_zero",
                    "current_rate": rate,
                    "proposed_stake": proposed,
                    "returned_stake": 0.0,
                    "inventory_unit_base": float(self.inventory_unit_base),
                    "raw_amount": float(raw_amount),
                    "rounded_amount": float(rounded_amount),
                    "leverage": float(leverage),
                },
            )
            return 0.0

        unit = float(self.inventory_unit_base)
        if unit > 0 and abs(float(rounded_amount) - unit) / unit > 0.25:
            # The HJB treats one fill as exactly one inventory unit; a real
            # order amount drifting from inventory_unit_base degrades the
            # q-grid mapping. Diagnostic only (no hard fail in dry-run).
            self._debug_log_event(
                "inventory_unit_mismatch",
                {
                    "pair": pair,
                    "side": side,
                    "current_rate": rate,
                    "rounded_amount": float(rounded_amount),
                    "inventory_unit_base": unit,
                    "deviation": abs(float(rounded_amount) - unit) / unit,
                },
            )

        rounded_stake = min(float(rounded_amount) * rate, maximum, proposed)
        if min_stake_value is not None and rounded_stake < min_stake_value:
            self._debug_log_event(
                "stake_rejected",
                {
                    "pair": pair,
                    "side": side,
                    "entry_tag": entry_tag,
                    "reason": "rounded_stake_below_min_stake",
                    "current_rate": rate,
                    "proposed_stake": proposed,
                    "min_stake": min_stake_value,
                    "returned_stake": 0.0,
                    "risk_cap": float(risk_cap),
                    "inventory_unit_base": float(self.inventory_unit_base),
                    "raw_amount": float(raw_amount),
                    "rounded_amount": float(rounded_amount),
                    "rounded_stake": float(rounded_stake),
                    "leverage": float(leverage),
                },
            )
            return 0.0

        amount_rounding_applied = rounded_stake < stake - max(1e-12, stake * 1e-9)
        stake = rounded_stake
        self._debug_log_event(
            "stake_sized",
            {
                "pair": pair,
                "side": side,
                "entry_tag": entry_tag,
                "current_rate": rate,
                "proposed_stake": proposed,
                "returned_stake": stake,
                "inventory_unit_base": float(self.inventory_unit_base),
                "raw_amount": float(raw_amount),
                "rounded_amount": float(rounded_amount),
                "amount_rounding_applied": bool(amount_rounding_applied),
                "leverage": float(leverage),
            },
        )
        return float(stake)

    def adjust_trade_position(
        self,
        trade,
        current_time: datetime,
        current_rate: float,
        current_profit: float,
        min_stake: float | None,
        max_stake: float,
        current_entry_rate: float,
        current_exit_rate: float,
        current_entry_profit: float,
        current_exit_profit: float,
        **kwargs,
    ):
        """Scale the single open position by one inventory unit.

        This is what makes |q| > 1 reachable at all. Freqtrade allows one trade
        per pair, so inventory cannot be carried as a COUNT of trades -- it is
        carried as the SIZE of one trade, moved a unit at a time from here.
        Positive stake adds, negative reduces.

        Freqtrade calls this on every iteration, and unlike the documented
        example we deliberately do not bail out on ``trade.has_open_orders``.

        WHAT ACTUALLY PACES THE REQUOTES (verified against freqtrade 2025.10's
        FreqtradeBot.manage_open_orders / replace_order, and measured live on
        2026-08-18). An earlier version of this docstring claimed the cadence was
        governed by ``_should_refresh_quote``. No such method has ever existed --
        ``git log -S"def _should_refresh_quote"`` is empty across all history --
        and freqtrade does not cancel-and-replace on any price change either.
        The real mechanism is three paths, and the one that dominates is not the
        one you would expect:

        1. TIMEOUT (dominant). ``manage_open_orders`` checks ``ft_check_timed_out``
           FIRST and cancels on ``unfilledtimeout``; freqtrade's own docstring
           says "Timeout setting takes priority over limit order adjustment
           request". The order is then re-placed on a later iteration. So the
           cadence is ``unfilledtimeout`` plus however many
           ``internals.process_throttle_secs`` iterations the cancel/re-place
           round trip needs. At 3 s / 2 s that measured p10 1.0 s, p50 5.5 s,
           p90 10.9 s between order placements.

        2. CANDLE-GATED REPLACE (rare). ``replace_order`` is only reached when
           the timeout did NOT fire, and it gates on a new candle
           (``latest_candle_close_date > order_obj.order_date_utc``) before
           calling ``adjust_order_price`` -> our ``adjust_entry_price`` /
           ``adjust_exit_price``. With ``timeframe='1m'`` and a 3 s
           ``unfilledtimeout``, an order only lives across a candle boundary
           about 3/60 of the time, so those two callbacks fire on roughly 5% of
           orders. They are not dead code, but they are not the requote path
           either -- raising ``unfilledtimeout`` above the timeframe is what
           would make them primary.

        3. POSITION-ADJUST REPLACE (this callback, live since 2026-08-19). The
           two paths above were measured while THIS METHOD CRASHED on every call,
           so they were the whole story only by accident. With the crash fixed,
           ``process_open_trade_positions`` reaches here on an entry that has not
           filled, we return a one-unit stake, and freqtrade logs
           "Position adjust: about to create a new order" immediately followed by
           "Buy order cancelled to be replaced by new limit order". It does not
           stack a second order -- it cancels and re-places the resting one, at
           the price ``custom_entry_price`` computes this iteration. So it is a
           genuine third requote path, and it is not candle-gated.

           Inventory cannot run away through it: the trade carries
           ``amount=0`` while unfilled, so ``_inventory_level`` stays flat and
           each cycle re-places the same single unit.

        There is therefore no separate refresh gate to configure: the cadence is
        set by ``unfilledtimeout``, ``internals.process_throttle_secs`` and the
        rate this callback is reached. Note the first two do not compose linearly
        -- dropping them from 15 s / 15 s to 3 s / 2 s took the median from 30.3 s
        to ~10 s, but tightening further to 2 s / 1 s measured no faster while
        doubling API load. The p10 1.0 / p50 5.5 / p90 10.9 s figures quoted above
        predate path 3 and are now an upper bound on the interval.

        Sizing is re-derived here rather than inherited: custom_stake_amount is
        NOT called for position adjustments, so its one-unit cap would otherwise
        be silently bypassed.
        """
        pair = getattr(trade, "pair", "") or ""
        # `trading_enabled` IS the kill switch: `_trigger_kill_switch` clears it.
        # An earlier version also read `self._kill_switch_active`, an attribute that
        # has never been assigned anywhere -- so this callback raised AttributeError
        # on every single call from d20b27d until 2026-08-19, and inventory was never
        # adjusted live. Keep this guard spelled the same way as the other three.
        if not self.trading_enabled:
            return None
        if not self._model_ready(pair):
            return None

        rate = self._finite_float_or_none(current_rate)
        if rate is None or rate <= 0:
            return None

        target_q = self._target_inventory_units(pair)
        if target_q is None:
            return None
        current_q = self._inventory_level(pair)
        if target_q == current_q:
            return None

        # One unit at a time: the HJB's arrival process is unit-jump (eq. 10.2),
        # so a multi-unit step would be priced by a control that never
        # contemplated it.
        unit_stake = float(self.inventory_unit_base) * rate / max(float(self.target_leverage), 1e-9)

        # TWO SEPARATE QUESTIONS, and conflating them inverted the whole short leg.
        #
        #   1. Which side of the BOOK is this step? q is signed and rises on a
        #      bid, so `target_q > current_q` means a bid on either leg.
        #   2. Does that GROW or SHRINK the freqtrade position? A bid on the long
        #      leg buys and adds. A bid on the SHORT leg buys back and REDUCES.
        #
        # freqtrade reads the sign of the return as (2): positive grows the
        # position in its own direction, negative gives some back. The previous
        # code derived it from (1) alone, so on the short leg every cover was
        # submitted as an add and every add as a cover. It also gated only the
        # positive branch on _inventory_allows_bid, which meant the short leg's
        # adds -- which landed in the ungated branch -- ignored q_max entirely
        # and could grow past the inventory cap.
        physical_side = "bid" if target_q > current_q else "ask"
        is_short = bool(getattr(trade, "is_short", False))
        adding = (physical_side == "ask") if is_short else (physical_side == "bid")

        # Gate on the physical side, for both directions. _inventory_allows_bid /
        # _inventory_allows_ask already carry the per-leg meaning (long: bid is
        # capped by q_max and ask needs inventory to sell; short: the mirror), so
        # this is the same rule the quoting path uses.
        if physical_side == "bid":
            if not self._inventory_allows_bid(pair):
                return None
        elif not self._inventory_allows_ask(pair):
            return None

        if adding:
            if min_stake is not None and unit_stake < float(min_stake):
                self._debug_log_event(
                    "position_adjustment_rejected",
                    {
                        "pair": pair,
                        "reason": "unit_stake_below_min_stake",
                        "unit_stake": unit_stake,
                        "min_stake": float(min_stake),
                    },
                )
                return None
            capped = min(unit_stake, float(max_stake)) if max_stake else unit_stake
            return float(capped)

        # Reducing: never hand back more than the position actually holds.
        held = abs(float(getattr(trade, "stake_amount", 0.0) or 0.0))
        if held <= 0:
            return None
        return -float(min(unit_stake, held))

    def _param_store_module(self):
        """The Redis transport module, loaded once. None if unavailable."""
        if not self._param_store_loaded:
            self._param_store = load_param_store()
            self._param_store_loaded = True
        return self._param_store

    def _publish_inventory_heartbeat(self, pair: str) -> None:
        """Tell the peer what this leg is holding.

        Unconditional by design. If a stalled instance stopped publishing, its
        peer would see staleness, stop quoting, stop publishing in turn, and the
        pair would never recover.
        """
        store = self._param_store_module()
        if store is None or not hasattr(store, "publish_inventory"):
            return
        try:
            store.publish_inventory(
                self._redis_url(),
                self._symbol_from_pair(pair),
                self.role,
                q_own=self._inventory_level(pair),
                param_fingerprint=getattr(self, "_hjb_param_fingerprint", None),
                published_at=self._now_utc().isoformat(),
                ttl_seconds=int(max(self.max_peer_inventory_age_seconds * 2, 10)),
                episode_id=int(self._episode_id) if self._episodic() else None,
                episode_start=(
                    self._episode_start_dt.isoformat()
                    if self._episodic() and self._episode_start_dt is not None
                    else None
                ),
            )
        except Exception as exc:
            self._debug_log_event("inventory_heartbeat_failed", {"pair": pair, "error": str(exc)})

    def _net_inventory(self, pair: str) -> tuple[int | None, str]:
        """Net inventory across both legs, or None with a reason to stop quoting."""
        store = self._param_store_module()
        if store is None or not hasattr(store, "fetch_inventory"):
            return None, "peer_transport_unavailable"
        symbol = self._symbol_from_pair(pair)
        try:
            peer = store.fetch_inventory(self._redis_url(), symbol, store.peer_role(self.role))
        except Exception:
            peer = None
        # Converge the clocks before pricing off them, not after: a leg that
        # quoted this cycle on its own clock and adopted the peer's on the next
        # would have priced one cycle at the wrong point on the surface.
        adopted = self._adopt_peer_episode(peer)
        if adopted:
            self._debug_log_event(
                "episode_clock_adopted",
                {
                    "pair": pair,
                    "role": self.role,
                    "episode_id": int(self._episode_id),
                    "episode_start": (
                        self._episode_start_dt.isoformat()
                        if self._episode_start_dt is not None
                        else None
                    ),
                    "reason": adopted,
                },
            )
        return self._mm_core.resolve_net_inventory(
            self._inventory_level(pair),
            peer,
            getattr(self, "_hjb_param_fingerprint", None),
            now=self._now_utc(),
            max_peer_age_seconds=float(self.max_peer_inventory_age_seconds),
        )

    def _my_quote_side(self, pair: str) -> str | None:
        """Which side of the book this leg owns right now, per the routing rule.

        Returns None when the pair's state gives this leg nothing to post --
        which happens legitimately at the net inventory boundary, where the
        model disables one side and the other leg posts the survivor.
        """
        q_net, reason = self._net_inventory(pair)
        if q_net is None:
            return None
        q_own = self._inventory_level(pair)
        q_peer = q_net - q_own
        q_long, q_short = (q_own, q_peer) if self.role == "long" else (q_peer, q_own)
        return self._mm_core.route_sides(q_long, q_short, int(self.hjb_q_max)).get(self.role)

    def _target_inventory_units(self, pair: str) -> int | None:
        """Inventory this leg should be carrying next, in signed units.

        One unit in the direction of whichever side this leg currently owns: a
        resting bid moves it up one, a resting ask moves it down one. That keeps
        every step a unit jump, which is what the HJB's arrival process assumes
        (eq. 10.2).
        """
        side = self._my_quote_side(pair)
        if side is None:
            return None
        q_own = self._inventory_level(pair)
        return q_own + 1 if side == "bid" else q_own - 1

    def leverage(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        proposed_leverage: float,
        max_leverage: float,
        entry_tag: str | None,
        side: str,
        **kwargs,
    ) -> float:
        """Fixed leverage, capped by whatever the venue allows.

        Leverage does not appear anywhere in the Cartea-Jaimungal model -- it
        changes only how much margin backs a given notional, not the inventory
        risk, adverse selection or funding, all of which are set by
        q * inventory_unit_base * mid. It is a financing choice sitting outside
        the model, so it is a constant rather than anything the solver drives.
        """
        target = float(self.target_leverage)
        try:
            ceiling = float(max_leverage)
        except (TypeError, ValueError):
            return target
        if not np.isfinite(ceiling) or ceiling <= 0:
            return target
        return float(min(target, ceiling))

    def custom_exit_price(self, pair: str, trade: Trade,
                        current_time: datetime, proposed_rate: float,
                        current_profit: float, exit_tag: str, **kwargs) -> float:
        
        # The short leg prices its own quotes from the HJB like any other;
        # only a long-only instance treats a short as out of scope.
        if trade.is_short and not self.can_short:
            return proposed_rate
            
        mid_price = self.get_mid_price(pair, proposed_rate)
        symbol = self._symbol_from_pair(pair)
        if self.hjb_cache is None:
            self._refresh_hjb(pair)

        _, q_exact, tau = self._pricing_state(pair)
        delta_p = self._select_delta(
            self._physical_quote_side('exit'), q_exact, tau_remaining=tau
        )
        if delta_p is None or not np.isfinite(float(delta_p)):
            logger.error("No HJB delta available for ask; using proposed_rate for exit pricing.")
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("exit"),
                action="exit",
                decision="reject",
                reason=self._no_delta_reason(),
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                extra={"trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None},
            )
            return proposed_rate
        if not self._inventory_allows_quote(pair, "exit"):
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("exit"),
                action="exit",
                decision="reject",
                reason="position_limit_reached",
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                extra={"trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None},
            )
            return proposed_rate
        delta_source = "hjb_grid"

        delta_model = float(delta_p)
        quote_side, side_sign = self._quote_side_and_sign("exit")
        delta_total, spread_info = self._assemble_half_spread(pair, quote_side, delta_model, mid_price)
        fee_cushion = float(spread_info["fee_cushion"])
        raw_rate = mid_price + side_sign * delta_total
        returned_rate = self._round_quote_price(pair, quote_side, raw_rate)

        self._log_spread("ask", mid_price, delta_total, delta_source)
        logger.info(f"Calculated ask: {returned_rate:.5f}")

        ok, reason = self._quote_state_valid(pair, self._physical_quote_side("exit"), returned_rate, current_time)
        if not ok:
            self._remember_custom_price_rejection(
                pair=pair,
                quote_side=self._physical_quote_side("exit"),
                reason=reason,
                current_time=current_time,
                rate=returned_rate,
            )
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("exit"),
                action="exit",
                decision="reject",
                reason=reason,
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                raw_price=raw_rate,
                rounded_price=returned_rate,
                delta_model=delta_model,
                fee_cushion=fee_cushion,
                delta_total=delta_total,
                extra={
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    "open_rate": float(trade.open_rate) if getattr(trade, "open_rate", None) is not None else None,
                    "current_profit": float(current_profit) if current_profit is not None else None,
                    "exit_tag": exit_tag,
                    **spread_info,
                },
            )
            return proposed_rate

        distance_ok, distance_reason, distance_payload = self._custom_price_distance_valid(returned_rate, proposed_rate)
        if not distance_ok:
            self._remember_custom_price_rejection(
                pair=pair,
                quote_side=self._physical_quote_side("exit"),
                reason=distance_reason,
                current_time=current_time,
                rate=returned_rate,
            )
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("exit"),
                action="exit",
                decision="reject",
                reason=distance_reason,
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                raw_price=raw_rate,
                rounded_price=returned_rate,
                delta_model=delta_model,
                fee_cushion=fee_cushion,
                delta_total=delta_total,
                extra={
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    "open_rate": float(trade.open_rate) if getattr(trade, "open_rate", None) is not None else None,
                    "current_profit": float(current_profit) if current_profit is not None else None,
                    "exit_tag": exit_tag,
                    **spread_info,
                    **distance_payload,
                },
            )
            return proposed_rate

        ok, reason = self._maker_safe(pair, self._physical_quote_side("exit"), returned_rate)
        if not ok:
            self._remember_custom_price_rejection(
                pair=pair,
                quote_side=self._physical_quote_side("exit"),
                reason=reason,
                current_time=current_time,
                rate=returned_rate,
            )
        else:
            self._clear_custom_price_rejection(pair, "ask")
        self._log_quote_decision(
            pair=pair,
            symbol=symbol,
            side=self._physical_quote_side("exit"),
            action="exit",
            decision="accept" if ok else "reject",
            reason=reason,
            mid_price=mid_price,
            proposed_rate=proposed_rate,
            raw_price=raw_rate,
            rounded_price=returned_rate,
            delta_model=delta_model,
            fee_cushion=fee_cushion,
            delta_total=delta_total,
            extra={
                "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                "open_rate": float(trade.open_rate) if getattr(trade, "open_rate", None) is not None else None,
                "current_profit": float(current_profit) if current_profit is not None else None,
                "exit_tag": exit_tag,
                **spread_info,
                **distance_payload,
            },
        )

        return returned_rate if ok else proposed_rate

    def confirm_trade_entry(
        self,
        pair: str,
        order_type: str,
        amount: float,
        rate: float,
        time_in_force: str,
        current_time: datetime,
        entry_tag: str | None,
        side: str,
        **kwargs,
    ) -> bool:
        side_reason = self._entry_side_rejection_reason(side)
        if side_reason is not None:
            self._debug_log_event(
                "entry_rejected",
                {
                    "pair": pair,
                    "reason": side_reason,
                    "rate": float(rate),
                    "side": side,
                    "order_type": order_type,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        if not self._is_limit_order_type(order_type):
            self._debug_log_event(
                "entry_rejected",
                {
                    "pair": pair,
                    "reason": "non_limit_order_type",
                    "rate": float(rate),
                    "side": side,
                    "order_type": order_type,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        ok, reason = self._time_in_force_valid("bid", time_in_force)
        if not ok:
            self._record_quote_decision(pair, "reject", reason)
            self._debug_log_event(
                "entry_rejected",
                {
                    "pair": pair,
                    "reason": reason,
                    "rate": float(rate),
                    "side": side,
                    "order_type": order_type,
                    "time_in_force": time_in_force,
                    "expected_tif": self._expected_time_in_force("bid"),
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        pending_reason = self._pending_custom_price_rejection_reason(pair, "bid", current_time)
        if pending_reason is not None:
            self._debug_log_event(
                "entry_rejected",
                {
                    "pair": pair,
                    "reason": pending_reason,
                    "rate": float(rate),
                    "side": side,
                    "order_type": order_type,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        ok, reason = self._quote_state_valid(pair, self._physical_quote_side("entry"), rate, current_time)
        if not ok:
            self._debug_log_event(
                "entry_rejected",
                {
                    "pair": pair,
                    "reason": reason,
                    "rate": float(rate),
                    "side": side,
                    "order_type": order_type,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        price_ok, price_reason, rounded_rate = self._price_tick_safe(pair, self._physical_quote_side("entry"), rate)
        if not price_ok:
            self._debug_log_event(
                "entry_rejected",
                {
                    "pair": pair,
                    "reason": price_reason,
                    "rate": float(rate),
                    "rounded_price": float(rounded_rate),
                    "side": side,
                    "order_type": order_type,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        amount_ok, amount_reason, rounded_amount = self._amount_lot_safe(pair, amount, rate)
        if not amount_ok:
            self._debug_log_event(
                "entry_rejected",
                {
                    "pair": pair,
                    "reason": amount_reason,
                    "rate": float(rate),
                    "amount": float(amount),
                    "rounded_amount": float(rounded_amount),
                    "side": side,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        risk_ok, risk_reason, risk_snapshot = self._position_risk_valid(pair, self._physical_quote_side("entry"), rate, rounded_amount)
        if not risk_ok:
            self._debug_log_event(
                "entry_rejected",
                {
                    "pair": pair,
                    "reason": risk_reason,
                    "rate": float(rate),
                    "amount": float(amount),
                    "rounded_amount": float(rounded_amount),
                    "side": side,
                    "position_risk": risk_snapshot,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        ok, reason = self._maker_safe(pair, self._physical_quote_side("entry"), rate)
        if not ok:
            self._record_quote_decision(pair, "reject", reason)
            self._debug_log_event(
                "entry_rejected",
                {"pair": pair, "reason": reason, "rate": float(rate), "side": side, **self._inventory_snapshot(pair)},
            )
            return False

        self._clear_custom_price_rejection(pair, "bid")
        self._record_order_attempt_accepted(
            pair=pair,
            quote_side=self._physical_quote_side("entry"),
            rate=float(rate),
            amount=float(amount),
            time_in_force=time_in_force,
            current_time=current_time,
        )
        return True

    def confirm_trade_exit(
        self,
        pair: str,
        trade: Trade,
        order_type: str,
        amount: float,
        rate: float,
        time_in_force: str,
        exit_reason: str,
        current_time: datetime,
        **kwargs,
    ) -> bool:
        protected_exit_reasons = {
            "stop_loss",
            "stoploss",
            "stoploss_on_exchange",
            "liquidation",
            "emergency_exit",
            "force_exit",
            "force_sell",
        }
        if exit_reason in protected_exit_reasons:
            return True

        if not self._is_limit_order_type(order_type):
            self._debug_log_event(
                "exit_rejected",
                {
                    "pair": pair,
                    "reason": "non_limit_order_type",
                    "rate": float(rate),
                    "order_type": order_type,
                    "exit_reason": exit_reason,
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        ok, reason = self._time_in_force_valid("ask", time_in_force)
        if not ok:
            self._record_quote_decision(pair, "reject", reason)
            self._debug_log_event(
                "exit_rejected",
                {
                    "pair": pair,
                    "reason": reason,
                    "rate": float(rate),
                    "order_type": order_type,
                    "time_in_force": time_in_force,
                    "expected_tif": self._expected_time_in_force("ask"),
                    "exit_reason": exit_reason,
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        pending_reason = self._pending_custom_price_rejection_reason(pair, "ask", current_time)
        if pending_reason is not None:
            self._debug_log_event(
                "exit_rejected",
                {
                    "pair": pair,
                    "reason": pending_reason,
                    "rate": float(rate),
                    "exit_reason": exit_reason,
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        ok, reason = self._quote_state_valid(pair, self._physical_quote_side("exit"), rate, current_time)
        if not ok:
            self._debug_log_event(
                "exit_rejected",
                {
                    "pair": pair,
                    "reason": reason,
                    "rate": float(rate),
                    "exit_reason": exit_reason,
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        price_ok, price_reason, rounded_rate = self._price_tick_safe(pair, self._physical_quote_side("exit"), rate)
        if not price_ok:
            self._debug_log_event(
                "exit_rejected",
                {
                    "pair": pair,
                    "reason": price_reason,
                    "rate": float(rate),
                    "rounded_price": float(rounded_rate),
                    "exit_reason": exit_reason,
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        amount_ok, amount_reason, rounded_amount = self._amount_lot_safe(pair, amount, rate)
        if not amount_ok:
            self._debug_log_event(
                "exit_rejected",
                {
                    "pair": pair,
                    "reason": amount_reason,
                    "rate": float(rate),
                    "amount": float(amount),
                    "rounded_amount": float(rounded_amount),
                    "exit_reason": exit_reason,
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        risk_ok, risk_reason, risk_snapshot = self._position_risk_valid(pair, self._physical_quote_side("exit"), rate, rounded_amount)
        if not risk_ok:
            self._debug_log_event(
                "exit_rejected",
                {
                    "pair": pair,
                    "reason": risk_reason,
                    "rate": float(rate),
                    "amount": float(amount),
                    "rounded_amount": float(rounded_amount),
                    "exit_reason": exit_reason,
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    "position_risk": risk_snapshot,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        ok, reason = self._maker_safe(pair, self._physical_quote_side("exit"), rate)
        if not ok:
            self._record_quote_decision(pair, "reject", reason)
            self._debug_log_event(
                "exit_rejected",
                {
                    "pair": pair,
                    "reason": reason,
                    "rate": float(rate),
                    "exit_reason": exit_reason,
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    **self._inventory_snapshot(pair),
                },
            )
            return False

        self._clear_custom_price_rejection(pair, "ask")
        self._record_order_attempt_accepted(
            pair=pair,
            quote_side=self._physical_quote_side("exit"),
            rate=float(rate),
            amount=float(amount),
            time_in_force=time_in_force,
            current_time=current_time,
        )
        return True

    def order_filled(self, pair: str, trade: Trade, order: Order, current_time: datetime, **kwargs) -> None:
        config = getattr(self, "config", {}) if isinstance(getattr(self, "config", {}), dict) else {}
        raw_liquidity = (
            getattr(order, "liquidity", None)
            or getattr(order, "ft_liquidity", None)
            or getattr(order, "filled_liquidity", None)
            or "unknown"
        )
        liquidity = self._normalize_liquidity(raw_liquidity)
        order_type = getattr(order, "order_type", None) or getattr(order, "type", None)
        tif = getattr(order, "time_in_force", None) or getattr(order, "ft_time_in_force", None)
        raw_side = getattr(order, "ft_order_side", None) or getattr(order, "side", None)
        quote_side = self._quote_side_from_order_side(raw_side)
        price = getattr(order, "price", None) or getattr(order, "safe_price", None)
        # `filled` first, not `amount`: `amount` is what was REQUESTED, so a
        # partially filled order was recorded at full size and every fee,
        # notional and markout figure derived from it was overstated. Partial
        # fills are also exactly what puts inventory between the HJB's integer
        # grid points, so mis-recording them hides the residual being carried.
        amount = getattr(order, "filled", None) or getattr(order, "amount", None)
        requested_amount = self._finite_float_or_none(getattr(order, "amount", None))
        price_float = self._finite_float_or_none(price)
        amount_float = self._finite_float_or_none(amount)
        fee_paid = self._extract_order_fee_paid(order, price_float, amount_float)
        fee_rate = self._extract_order_fee_rate(order, fee_paid, price_float, amount_float)
        order_id = getattr(order, "id", None) or getattr(order, "order_id", None) or getattr(order, "ft_order_id", None)
        client_order_id = (
            getattr(order, "client_order_id", None)
            or getattr(order, "clientOrderId", None)
            or getattr(order, "ft_client_order_id", None)
        )
        order_quote_id = getattr(order, "quote_id", None) or getattr(order, "ft_quote_id", None)
        quote_id = order_quote_id or client_order_id
        quote_id_source = None
        if order_quote_id not in (None, ""):
            quote_id_source = "order_attribute"
        elif client_order_id not in (None, ""):
            quote_id_source = "client_order_id"
        elif price_float is not None and quote_side is not None:
            quote_match = self._match_quote_link_cache(
                "_accepted_order_attempt_links",
                pair,
                quote_side,
                price_float,
                current_time,
            )
            if quote_match and quote_match.get("quote_id") not in (None, ""):
                quote_id = quote_match.get("quote_id")
                quote_id_source = "accepted_order_attempt"
        if quote_id_source is None:
            quote_id_source = "unavailable"
        realized_pnl = self._extract_realized_pnl_usdc(trade, order)
        expected_tif = self._expected_time_in_force(quote_side)
        tif_canonical = self._canonical_tif(tif)
        expected_tif_canonical = self._canonical_tif(expected_tif)

        payload = {
            "pair": pair,
            "trading_enabled": bool(self.trading_enabled),
            "dry_run": bool(config.get("dry_run", True)),
            "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
            "order_id": order_id,
            "client_order_id": client_order_id,
            "quote_id": quote_id,
            "quote_id_source": quote_id_source,
            "raw_liquidity": raw_liquidity,
            "liquidity": liquidity,
            "liquidity_normalized": liquidity,
            "is_maker_fill": liquidity == "maker",
            "is_taker_fill": liquidity == "taker",
            "expected_fee_rate": float(self.fees_maker_HL),
            "actual_fee_paid": float(fee_paid) if fee_paid is not None else None,
            "actual_fee_rate": float(fee_rate) if fee_rate is not None else None,
            "fee_snapshot": self._fee_snapshot(pair, fee_rate),
            "order_type": order_type,
            "tif": tif,
            "tif_canonical": tif_canonical,
            "expected_tif": expected_tif,
            "expected_tif_canonical": expected_tif_canonical,
            "tif_matches_expected": (
                tif_canonical == expected_tif_canonical
                if tif_canonical is not None and expected_tif_canonical is not None
                else None
            ),
            "raw_order_side": raw_side,
            "quote_side": quote_side,
            "post_only_verified": bool(self.post_only_verified),
            "price": price_float,
            "amount": amount_float,
            "requested_amount": requested_amount,
            "is_partial_fill": (
                None
                if amount_float is None or requested_amount is None
                else amount_float < requested_amount * 0.999
            ),
            "realized_pnl": float(realized_pnl) if realized_pnl is not None else None,
            **self._inventory_snapshot(pair),
        }
        self._debug_log_event("fill", payload)
        self._schedule_fill_markouts(payload, current_time)

        if liquidity == "maker":
            self._maker_fill_count = int(getattr(self, "_maker_fill_count", 0)) + 1
        if liquidity == "taker":
            self._taker_fill_count = int(getattr(self, "_taker_fill_count", 0)) + 1

        if realized_pnl is not None:
            self._record_realized_pnl(pair, realized_pnl, current_time, payload)

        tif_missing_when_required = (
            expected_tif_canonical == "post_only"
            and tif_canonical is None
        )
        tif_mismatch = payload["tif_matches_expected"] is False or tif_missing_when_required
        if self.kill_on_time_in_force_mismatch and self.post_only_verified and tif_mismatch:
            self._trigger_kill_switch("unexpected_time_in_force", payload)

        if (
            self.kill_on_unknown_liquidity_fill
            and self.post_only_verified
            and liquidity not in {"maker", "taker"}
        ):
            self._trigger_kill_switch("unknown_fill_liquidity", payload)

        if self.kill_on_taker_fill and liquidity == "taker":
            self._trigger_kill_switch("unexpected_taker_fill", payload)

    def adjust_entry_price(self, trade: Trade, order: Order, pair: str,
                            current_time: datetime, proposed_rate: float, current_order_rate: float,
                            entry_tag: str, side: str, **kwargs) -> float | None:
        
        # The short leg prices its own quotes from the HJB like any other;
        # only a long-only instance treats a short as out of scope.
        if trade.is_short and not self.can_short:
            return current_order_rate
            
        mid_price = self.get_mid_price(pair, proposed_rate)
        symbol = self._symbol_from_pair(pair)

        if self.hjb_cache is None:
            self._refresh_hjb(pair)

        ok, reason = self._quote_state_valid(pair, self._physical_quote_side("entry"), current_order_rate, current_time)
        if not ok:
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("entry"),
                action="adjust_entry",
                decision="reject",
                reason=reason,
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                rounded_price=current_order_rate,
                extra={
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    "current_order_rate": float(current_order_rate),
                    "cancel_open_order": True,
                },
            )
            self._record_open_order_cancel_request()
            return None

        _, q_exact, tau = self._pricing_state(pair)
        delta_m = self._select_delta(
            self._physical_quote_side('entry'), q_exact, tau_remaining=tau
        )
        if delta_m is None or not np.isfinite(float(delta_m)):
            logger.warning("No HJB delta available for bid adjust; cancelling open order.")
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("entry"),
                action="adjust_entry",
                decision="reject",
                reason=self._no_delta_reason(),
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                rounded_price=current_order_rate,
                extra={
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    "current_order_rate": float(current_order_rate),
                    "cancel_open_order": True,
                },
            )
            self._record_open_order_cancel_request()
            return None
        delta_source = "hjb_grid"
        delta_model = float(delta_m)
        quote_side, side_sign = self._quote_side_and_sign("entry")
        delta_total, spread_info = self._assemble_half_spread(pair, quote_side, delta_model, mid_price)
        fee_cushion = float(spread_info["fee_cushion"])
        raw_rate = mid_price + side_sign * delta_total
        returned_rate = self._round_quote_price(pair, quote_side, raw_rate)

        self._log_spread("bid_adjust", mid_price, delta_total, delta_source)

        distance_ok, distance_reason, distance_payload = self._custom_price_distance_valid(returned_rate, proposed_rate)
        if not distance_ok:
            ok, reason = False, distance_reason
        else:
            ok, reason = self._maker_safe(pair, self._physical_quote_side("entry"), returned_rate)
        self._log_quote_decision(
            pair=pair,
            symbol=symbol,
            side=self._physical_quote_side("entry"),
            action="adjust_entry",
            decision="accept" if ok else "reject",
            reason=reason,
            mid_price=mid_price,
            proposed_rate=proposed_rate,
            raw_price=raw_rate,
            rounded_price=returned_rate,
            delta_model=delta_model,
            fee_cushion=fee_cushion,
            delta_total=delta_total,
            extra={
                "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                "current_order_rate": float(current_order_rate),
                "cancel_open_order": not ok,
                **spread_info,
                **distance_payload,
            },
        )

        if not ok:
            self._record_open_order_cancel_request()
            return None
        return returned_rate

    def adjust_exit_price(self, trade: Trade, order: Order, pair: str,
                          current_time: datetime, proposed_rate: float, current_order_rate: float,
                          entry_tag: str | None, side: str, **kwargs) -> float | None:
        # NOTE: freqtrade passes the tag positionally/by keyword as `entry_tag`
        # for adjust_exit_price (not `exit_tag`); the parameter name must match
        # or freqtrade raises "missing required positional argument".
        # The short leg prices its own quotes from the HJB like any other;
        # only a long-only instance treats a short as out of scope.
        if trade.is_short and not self.can_short:
            return current_order_rate

        mid_price = self.get_mid_price(pair, proposed_rate)
        symbol = self._symbol_from_pair(pair)

        if self.hjb_cache is None:
            self._refresh_hjb(pair)

        ok, reason = self._quote_state_valid(pair, self._physical_quote_side("exit"), current_order_rate, current_time)
        if not ok:
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("exit"),
                action="adjust_exit",
                decision="reject",
                reason=reason,
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                rounded_price=current_order_rate,
                extra={
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    "current_order_rate": float(current_order_rate),
                    "exit_tag": entry_tag,
                    "cancel_open_order": True,
                },
            )
            self._record_open_order_cancel_request()
            return None

        _, q_exact, tau = self._pricing_state(pair)
        delta_p = self._select_delta(
            self._physical_quote_side('exit'), q_exact, tau_remaining=tau
        )
        if delta_p is None or not np.isfinite(float(delta_p)):
            logger.warning("No HJB delta available for ask adjust; cancelling open order.")
            self._log_quote_decision(
                pair=pair,
                symbol=symbol,
                side=self._physical_quote_side("exit"),
                action="adjust_exit",
                decision="reject",
                reason=self._no_delta_reason(),
                mid_price=mid_price,
                proposed_rate=proposed_rate,
                rounded_price=current_order_rate,
                extra={
                    "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                    "current_order_rate": float(current_order_rate),
                    "exit_tag": entry_tag,
                    "cancel_open_order": True,
                },
            )
            self._record_open_order_cancel_request()
            return None

        delta_source = "hjb_grid"
        delta_model = float(delta_p)
        quote_side, side_sign = self._quote_side_and_sign("exit")
        delta_total, spread_info = self._assemble_half_spread(pair, quote_side, delta_model, mid_price)
        fee_cushion = float(spread_info["fee_cushion"])
        raw_rate = mid_price + side_sign * delta_total
        returned_rate = self._round_quote_price(pair, quote_side, raw_rate)

        self._log_spread("ask_adjust", mid_price, delta_total, delta_source)

        distance_ok, distance_reason, distance_payload = self._custom_price_distance_valid(returned_rate, proposed_rate)
        if not distance_ok:
            ok, reason = False, distance_reason
        else:
            ok, reason = self._maker_safe(pair, self._physical_quote_side("exit"), returned_rate)
        self._log_quote_decision(
            pair=pair,
            symbol=symbol,
            side=self._physical_quote_side("exit"),
            action="adjust_exit",
            decision="accept" if ok else "reject",
            reason=reason,
            mid_price=mid_price,
            proposed_rate=proposed_rate,
            raw_price=raw_rate,
            rounded_price=returned_rate,
            delta_model=delta_model,
            fee_cushion=fee_cushion,
            delta_total=delta_total,
            extra={
                "trade_id": int(trade.id) if getattr(trade, "id", None) is not None else None,
                "current_order_rate": float(current_order_rate),
                "exit_tag": entry_tag,
                "cancel_open_order": not ok,
                **spread_info,
                **distance_payload,
            },
        )

        if not ok:
            self._record_open_order_cancel_request()
            return None
        return returned_rate

    # @property
    # def protections(self):
    #     return [
    #         {
    #             "method": "MaxDrawdown",
    #             "lookback_period": 10080,  # 1 week
    #             "trade_limit": 0,  # Evaluate all trades since the bot started
    #             "stop_duration_candles": 10000000,  # Stop trading indefinitely
    #             "max_allowed_drawdown": 0.05  # Maximum drawdown of 5% before stopping
    #         },
    #     ]
