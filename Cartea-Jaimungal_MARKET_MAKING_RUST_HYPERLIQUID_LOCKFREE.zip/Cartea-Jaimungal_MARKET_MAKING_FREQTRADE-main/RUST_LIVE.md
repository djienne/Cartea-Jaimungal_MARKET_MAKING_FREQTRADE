# Moteur live Rust — Hyperliquid, sans Freqtrade

Cette extension remplace **uniquement la boucle live** de Freqtrade. Les calibrations, solveurs HJB, notebooks, replays et rapports existants restent en Python. Le processus Rust reçoit les données de marché, tient l'inventaire, calcule les deux quotes, simule ou envoie les ordres et applique les limites de risque.

Le mode par défaut est `dry_run`. Aucun ordre réel n'est possible sans trois activations indépendantes : `runtime.mode = "live"`, l'option CLI `--enable-live` et une variable de confirmation exacte. Mainnet ajoute une quatrième confirmation.

## Architecture

```text
                         COLD PATH
   Python calibration / HJB / estimation
                  |
                  | atomic JSON snapshot
                  v
        snapshot watcher + validation -------- telemetry / state writer
                  | ArcSwap                         ^
                  | atomic model bit                | state seqlock
                  v                                 |
+-----------------+---------------------------------+----------------+
|                         DEDICATED HOT PATH                          |
| public WS -> BBO seqlock -> atomic wake bitset -> quote/risk/state |
|                                      ^                |             |
|                                      | HotEvent ArrayQueue          |
+--------------------------------------+----------------+-------------+
                                                       |
                                                       v
                           EXECUTION / ACCOUNT PATH
     dry-run MarketProbe ArrayQueue OR signed Hyperliquid WS actions
                           ^                    |
                           |          private-event ArrayQueue
                           +------ public/private WebSockets
```

### Hot path

Le calcul de quotes tourne sur un thread OS dédié, éventuellement épinglé avec `runtime.hot_path_cpu`. Le BBO, les quotes désirées et l'état persistant sont publiés dans trois seqlocks atomiques cache-alignés. Une lecture ne peut donc jamais observer un objet partiellement écrit, et aucune allocation `Arc` n'est nécessaire à chaque tick.

Les réveils marché, modèle, événements privés et arrêt sont coalescés dans un bitset atomique. Le thread se parque lorsqu'aucun bit n'est actif ; `unpark` ne transporte aucune donnée et ne sert qu'à éviter le busy-spin. Les fills et resynchronisations de position passent par un `ArrayQueue` borné et prioritaire. Les événements qui entrent dans cette file sont de taille fixe : les chaînes et détails d'order management restent hors du hot path. En mode réel, la publication d'ordres reste bloquée jusqu'à ce que le flux privé soit connecté **et** qu'un snapshot de position autoritatif ait été reçu ; une déconnexion invalide les deux conditions.

Le hot path ne fait aucun accès disque, appel HTTP/REST, parsing JSON, résolution HJB, signature, journalisation ni attente réseau. Il utilise des prix et quantités entiers et publie le dernier état de quote par atomiques lock-free, avec une notification Tokio uniquement pour réveiller le consommateur asynchrone lorsqu'il dort.

### Cold path

Le cold path assure :

- connexions/reconnexions WebSocket et parsing JSON ;
- signature EIP-712/L1 des actions Hyperliquid ;
- placement `Alo`, annulation par `oid`/`cloid` et `batchModify` dès que l'`oid` est connu ;
- `scheduleCancel` renouvelé en réel ;
- simulation de file d'attente et fills en dry-run ;
- rechargement atomique des paramètres Python ;
- métriques, logs et persistance d'état.

Trois connexions spécialisées évitent le head-of-line blocking : marché public, événements privés et RPC WebSocket `post` pour les actions/info. HTTP n'est utilisé que par le script facultatif de découverte des métadonnées, jamais par la boucle live.

### Ring buffers et politiques de saturation

Trois capacités, toutes positives et puissances de deux, sont configurables dans `[runtime]` :

- `market_probe_ring_capacity` : BBO/trades ordonnés utilisés uniquement par le simulateur dry-run. Le producteur WebSocket ne bloque jamais ; un probe refusé est compté dans `dropped_market_probes` ou `dropped_trades`. Le BBO est inséré dans le ring avant le réveil du calcul, et le simulateur traite ce probe avant la quote dérivée afin d'éviter un fill avec anticipation sur le même tick.
- `private_event_ring_capacity` : `orderUpdates`, `userFills` et snapshots de position. Cette file applique une backpressure asynchrone bornée plutôt que de perdre un fill ou de croître sans limite.
- `hot_event_ring_capacity` : sous-ensemble fixe et prioritaire des fills/positions/états de connexion transmis au thread hot. Cette file applique également une backpressure bornée.

La publication BBO et quote reste « latest value » : les notifications redondantes sont coalescées par atomique, mais le consommateur lit toujours le snapshot complet le plus récent. Les rings maintiennent en outre un high-water mark atomique, journalisé à l'arrêt du backend pour dimensionner les capacités. Les attentes `not_empty`/`not_full` n'interviennent qu'en cas de ring vide ou plein ; plusieurs producteurs sont enregistrés explicitement avant la vérification de capacité afin de ne pas perdre un réveil coalescé.

Le `tokio::mpsc` du client RPC est volontairement conservé : il transporte des commandes réseau peu fréquentes avec réponse `oneshot`, timeout et annulation ; ce chemin est dominé par l'I/O et n'appartient pas au calcul critique BBO → quote.

## Démarrage dry-run

Depuis la racine du dépôt :

```bash
cp config/live.example.toml config/live.toml
cp config/strategy_snapshot.example.json config/strategy_snapshot.json

cargo test --manifest-path rust_live/Cargo.toml
cargo build --manifest-path rust_live/Cargo.toml --release --bin mm-live

./rust_live/target/release/mm-live --config config/live.toml
```

Le flux public Hyperliquid est réel, mais les ordres restent internes au simulateur. Le simulateur tient compte d'une quantité placée devant le bot (`queue_ahead_fraction`) puis remplit sur les trades agressifs qui touchent ou traversent le prix. `fill_on_touch=false` est volontairement conservateur.

Pour vérifier uniquement la configuration :

```bash
./rust_live/target/release/mm-live \
  --config config/live.toml \
  --validate-only
```

## Export des paramètres Python

Le moteur recharge un fichier JSON complet uniquement après validation. L'écriture doit être atomique ; le helper fourni le garantit :

```bash
python scripts/export_rust_live_snapshot.py \
  --output config/strategy_snapshot.json \
  --gamma 0.05 \
  --kappa 1.5 \
  --sigma 0.5 \
  --horizon-sec 5 \
  --quote-size-lots 2
```

Depuis le code Python existant :

```python
from scripts.export_rust_live_snapshot import write_snapshot

write_snapshot(
    "config/strategy_snapshot.json",
    {
        "revision": calibration_timestamp_ms,
        "model": {
            "gamma": gamma,
            "kappa": kappa,
            "sigma": sigma,
            "horizon_sec": horizon_sec,
        },
        "risk": {
            "max_inventory_lots": max_inventory,
            "reduce_only_threshold_lots": reduce_threshold,
        },
    },
)
```

Pour conserver exactement une politique HJB Python, exportez un CSV régulier :

```csv
inventory_lots,bid_offset_ticks,ask_offset_ticks
-2,1,5
-1,2,4
0,3,3
1,4,2
2,5,1
```

Puis :

```bash
python scripts/export_rust_live_snapshot.py \
  --hjb-csv output/hjb_offsets.csv \
  --output config/strategy_snapshot.json
```

Quand `hjb` est présent, Rust utilise ces offsets pré-calculés. Sinon il applique l'approximation Cartea/Avellaneda–Stoikov plus les planchers et le skew d'inventaire configurés.

## Métadonnées instrument

Ne supposez jamais l'index d'un actif ou ses décimales. Le script de setup interroge l'endpoint `info` dans le cold path :

```bash
python scripts/fetch_hyperliquid_meta.py ETH --network testnet
```

Reportez `asset_id`, `size_decimals` et `price_decimals` dans `config/live.toml`. Les prix sont ensuite arrondis simultanément au tick configuré et au nombre maximal de chiffres significatifs.

## Testnet réel

1. Utiliser une clé d'API agent dédiée, jamais une seed phrase.
2. Mettre `runtime.mode = "live"`, `runtime.network = "testnet"` et renseigner `execution.asset_id`.
3. Définir l'adresse du compte principal/vault dans `runtime.wallet_address` si elle diffère de l'agent.
4. Charger les secrets hors du dépôt :

```bash
export HL_PRIVATE_KEY='0x...'
export HL_LIVE_CONFIRMATION='I_UNDERSTAND_THIS_SENDS_REAL_ORDERS'
```

5. Lancer avec le second facteur CLI :

```bash
./rust_live/target/release/mm-live \
  --config config/live.toml \
  --enable-live
```

Sans l'une de ces étapes, le binaire s'arrête avant d'ouvrir les flux d'exécution.

## Mainnet

Mainnet requiert en plus :

```bash
export HL_MAINNET_CONFIRMATION='I_UNDERSTAND_THIS_USES_MAINNET_FUNDS'
```

Validez d'abord sur une longue période en dry-run, puis sur testnet réel avec des tailles minimales. Les limites du snapshot sont appliquées avant chaque quote, mais elles ne remplacent pas les limites de compte, la supervision externe ni un kill switch opérationnel.

Pour couper immédiatement les quotes sans redémarrer, publiez un snapshot avec :

```json
{"risk": {"kill_switch": true}}
```

Le helper fusionne cette valeur avec le dernier jeu de paramètres complet. En réel, le processus annule aussi ses ordres suivis à l'arrêt et le dead-man switch `scheduleCancel` couvre une perte du processus ou de la connexion.

## Réglages de latence

- Compiler avec `--release`; le profil active LTO, un seul codegen unit et `panic=abort`.
- Épingler `hot_path_cpu` sur un cœur physique isolé du traitement réseau et des IRQ.
- Exécuter le processus près de l'infrastructure Hyperliquid et mesurer le RTT réel.
- Ne pas réduire `stale_after_ms` avant d'avoir mesuré les pauses réseau normales.
- Garder `quote_replace_threshold_ticks` et `min_order_lifetime_ms` assez élevés pour éviter le cancel/replace inutile.
- Désactiver les logs verbeux ; aucune trace n'est émise depuis le hot path.

Micro-benchmark local :

```bash
cargo run --manifest-path rust_live/Cargo.toml \
  --release --bin hot-path-bench
```

Le binaire imprime séparément le coût du calcul de quote, du seqlock BBO, de la publication atomique des quotes et d'un cycle `push`/`pop` du ring. Il ne mesure ni la latence réseau, ni la signature, ni l'acquittement exchange.

## Fichiers ajoutés

- `rust_live/` : moteur, connecteurs WebSocket, signature, simulation et tests ;
- `config/live.example.toml` : configuration sûre par défaut ;
- `config/strategy_snapshot.example.json` : contrat Python → Rust ;
- `scripts/export_rust_live_snapshot.py` : publication atomique ;
- `scripts/fetch_hyperliquid_meta.py` : bootstrap instrument ;
- `deploy/mm-live.service` : exemple systemd durci ;
- `.env.live.example` : noms de secrets et confirmations.

Le code Freqtrade d'origine n'est pas supprimé afin de préserver la reproductibilité des backtests. Il n'est plus nécessaire pour `mm-live`.
