#!/usr/bin/env python3
"""Print the cold-path instrument metadata required by config/live.toml."""

from __future__ import annotations

import argparse
import json
import urllib.request


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("coin")
    parser.add_argument("--network", choices=("testnet", "mainnet"), default="testnet")
    args = parser.parse_args()
    base = (
        "https://api.hyperliquid.xyz"
        if args.network == "mainnet"
        else "https://api.hyperliquid-testnet.xyz"
    )
    request = urllib.request.Request(
        f"{base}/info",
        data=json.dumps({"type": "meta"}).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        meta = json.load(response)
    for index, asset in enumerate(meta["universe"]):
        if asset["name"] == args.coin:
            size_decimals = int(asset["szDecimals"])
            print(f"asset_id = {index}")
            print(f"size_decimals = {size_decimals}")
            print(f"size_step_units = 1")
            print(f"price_decimals = {max(0, 6 - size_decimals)}")
            print("price_tick_units = 1")
            print("max_price_significant_figures = 5")
            return 0
    raise SystemExit(f"coin not found: {args.coin}")


if __name__ == "__main__":
    raise SystemExit(main())
