#!/usr/bin/env bash
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUST_DIR="$ROOT/rust_live"
OUT_DIR="$ROOT/validation"
mkdir -p "$OUT_DIR"
rm -f "$OUT_DIR"/*.log "$OUT_DIR"/*.code "$OUT_DIR/build_status.json" 2>/dev/null || true

run_check() {
  local name="$1"; shift
  local log="$OUT_DIR/${name}.log"
  set +e
  (cd "$ROOT" && "$@") >"$log" 2>&1
  local code=$?
  set -e
  printf '%s\n' "$code" > "$OUT_DIR/${name}.code"
  return 0
}

run_check rustfmt bash -lc 'cd rust_live && cargo fmt --all -- --check'
run_check rust_tests bash -lc 'cd rust_live && cargo test --all-targets'
run_check rust_release bash -lc 'cd rust_live && cargo build --release --bin mm-live --bin hot-path-bench'
run_check python_compile bash -lc 'python3 -m py_compile scripts/export_rust_live_snapshot.py scripts/fetch_hyperliquid_meta.py'
run_check exporter_help bash -lc 'python3 scripts/export_rust_live_snapshot.py --help'
run_check metadata_help bash -lc 'python3 scripts/fetch_hyperliquid_meta.py --help'

# Validate the shipped configuration/model with the compiled binary when available.
if [[ -x "$RUST_DIR/target/release/mm-live" ]]; then
  run_check config_validate bash -lc 'rust_live/target/release/mm-live --config config/live.example.toml --validate-only'
else
  printf '127\n' > "$OUT_DIR/config_validate.code"
  printf 'release binary unavailable\n' > "$OUT_DIR/config_validate.log"
fi

# Verify that a live configuration cannot start without the explicit CLI unlock.
TMP_LIVE="$OUT_DIR/live_guard.toml"
python3 - "$ROOT/config/live.example.toml" "$TMP_LIVE" <<'PY'
from pathlib import Path
import re, sys
src = Path(sys.argv[1]).read_text()
src = re.sub(r'(?m)^mode\s*=\s*"dry_run"\s*$', 'mode = "live"', src, count=1)
Path(sys.argv[2]).write_text(src)
PY
if [[ -x "$RUST_DIR/target/release/mm-live" ]]; then
  set +e
  (cd "$ROOT" && env -u HL_PRIVATE_KEY -u HL_LIVE_CONFIRMATION -u HL_MAINNET_CONFIRMATION \
    timeout --signal=INT 5s rust_live/target/release/mm-live --config validation/live_guard.toml) \
    >"$OUT_DIR/live_guard.log" 2>&1
  guard_code=$?
  set -e
  # A non-zero exit is the expected/pass condition for this negative test.
  if [[ $guard_code -ne 0 ]]; then
    printf '0\n' > "$OUT_DIR/live_guard.code"
  else
    printf '1\n' > "$OUT_DIR/live_guard.code"
    printf '\nERROR: live configuration was accepted without explicit unlock\n' >> "$OUT_DIR/live_guard.log"
  fi
else
  printf '127\n' > "$OUT_DIR/live_guard.code"
  printf 'release binary unavailable\n' > "$OUT_DIR/live_guard.log"
fi
rm -f "$TMP_LIVE"

# A short network smoke test is informative only: CI/build hosts may block egress.
if [[ -x "$RUST_DIR/target/release/mm-live" ]] && command -v timeout >/dev/null 2>&1; then
  set +e
  (cd "$ROOT" && timeout --signal=INT 10s rust_live/target/release/mm-live --config config/live.example.toml) \
    >"$OUT_DIR/dry_network_smoke.log" 2>&1
  smoke_code=$?
  set -e
  case "$smoke_code" in
    0|124|130) normalized=0 ;;
    *) normalized="$smoke_code" ;;
  esac
  printf '%s\n' "$normalized" > "$OUT_DIR/dry_network_smoke.code"
  printf '%s\n' "$smoke_code" > "$OUT_DIR/dry_network_smoke.raw_code"
else
  printf '77\n' > "$OUT_DIR/dry_network_smoke.code"
  printf 'smoke skipped: binary or timeout unavailable\n' > "$OUT_DIR/dry_network_smoke.log"
fi

python3 - "$ROOT" <<'PY'
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import json, sys

root = Path(sys.argv[1])
out = root / "validation"
checks = [
    ("rustfmt", "cargo fmt --check", True),
    ("rust_tests", "cargo test --all-targets", True),
    ("rust_release", "cargo build --release", True),
    ("python_compile", "Python py_compile", True),
    ("exporter_help", "Snapshot exporter CLI", True),
    ("metadata_help", "Hyperliquid metadata CLI", True),
    ("config_validate", "Example config/model validation", True),
    ("live_guard", "Live mode negative guard test", True),
    ("dry_network_smoke", "10 s dry-run network smoke", False),
]
rows=[]
required_ok=True
for key,label,required in checks:
    cp=out/f"{key}.code"
    try: code=int(cp.read_text().strip())
    except Exception: code=999
    ok=(code==0)
    if required and not ok: required_ok=False
    rows.append({"key":key,"label":label,"required":required,"exit_code":code,"ok":ok})

payload={
    "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    "required_checks_ok": required_ok,
    "checks": rows,
}
(out/"build_status.json").write_text(json.dumps(payload, indent=2)+"\n")

lines=[
    "# Validation — moteur live Rust / Hyperliquid",
    "",
    f"Généré le `{payload['generated_at_utc']}`.",
    "",
    f"**Résultat des contrôles requis : {'RÉUSSI' if required_ok else 'ÉCHEC'}**",
    "",
    "| Contrôle | Requis | Code | État |",
    "|---|:---:|---:|:---:|",
]
for row in rows:
    state="OK" if row["ok"] else ("AVERTISSEMENT" if not row["required"] else "ÉCHEC")
    lines.append(f"| {row['label']} | {'oui' if row['required'] else 'non'} | `{row['exit_code']}` | {state} |")
lines += [
    "",
    "Le test réseau dry-run est informatif : un hôte sans sortie Internet peut le faire échouer alors que la compilation et les tests déterministes réussissent.",
    "",
    "## Journaux",
    "",
    "Les journaux complets sont dans `validation/*.log`. En cas d’échec requis, les dernières lignes sont reproduites ci-dessous.",
]
for row in rows:
    if row["required"] and not row["ok"]:
        log=out/f"{row['key']}.log"
        text=log.read_text(errors="replace") if log.exists() else "journal absent"
        tail="\n".join(text.splitlines()[-80:])
        lines += ["", f"### {row['label']}", "", "```text", tail, "```"]
(root/"VALIDATION.md").write_text("\n".join(lines)+"\n")
PY

cat "$OUT_DIR/build_status.json"
