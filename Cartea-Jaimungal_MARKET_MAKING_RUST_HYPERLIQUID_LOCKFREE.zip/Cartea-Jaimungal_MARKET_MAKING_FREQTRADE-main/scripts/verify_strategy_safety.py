#!/usr/bin/env python3
"""Verify checked-in strategy defaults keep the fail-closed PLAN.md posture."""

from __future__ import annotations

import argparse
import ast
import json
import operator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DEFAULT_STRATEGY = Path("user_data/strategies/Market_Making.py")
DEFAULT_OUTPUT = Path("docs/strategy_safety_report.json")


BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}


# The capital the strategy is configured against (user_data/config.json
# available_capital). Used only to size the notional/margin cap check.
DEFAULT_AVAILABLE_CAPITAL = 1000.0


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def safe_eval(node: ast.AST) -> Any:
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -safe_eval(node.operand)
    if isinstance(node, ast.BinOp):
        op = BIN_OPS.get(type(node.op))
        if op is None:
            raise ValueError("unsupported_binop")
        return op(safe_eval(node.left), safe_eval(node.right))
    if isinstance(node, ast.Dict):
        return {safe_eval(key): safe_eval(value) for key, value in zip(node.keys, node.values)}
    if isinstance(node, ast.Tuple):
        return tuple(safe_eval(item) for item in node.elts)
    if isinstance(node, ast.List):
        return [safe_eval(item) for item in node.elts]
    raise ValueError(f"unsupported_node:{type(node).__name__}")


def finite_float(value: Any) -> float | None:
    try:
        number = float(value)
    except Exception:
        return None
    if number != number or number in (float("inf"), float("-inf")):
        return None
    return number


def call_arg_constant(call: ast.Call, index: int) -> Any:
    if len(call.args) <= index:
        return None
    arg = call.args[index]
    if isinstance(arg, ast.Constant):
        return arg.value
    return None


def function_calls_price_tick_guard(fn: ast.FunctionDef, quote_side: str) -> bool:
    for node in ast.walk(fn):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if not isinstance(func, ast.Attribute) or func.attr != "_price_tick_safe":
            continue
        value = func.value
        if not isinstance(value, ast.Name) or value.id != "self":
            continue
        if call_arg_constant(node, 1) == quote_side:
            return True
        # The side is role-derived now (an entry is a bid for the long leg and an
        # ask for the short leg), so the literal was replaced by a call. Accept
        # the equivalent expression rather than reporting the guard as missing.
        arg = node.args[1] if len(node.args) > 1 else None
        if isinstance(arg, ast.Call) and isinstance(arg.func, ast.Attribute):
            if arg.func.attr == "_physical_quote_side":
                action = call_arg_constant(arg, 0)
                if action == {"bid": "entry", "ask": "exit"}.get(quote_side):
                    return True
    return False


def parse_strategy_source(source: str) -> tuple[dict[str, Any], dict[str, list[str]], dict[str, bool], str | None]:
    try:
        module = ast.parse(source)
    except SyntaxError as exc:
        return {}, {}, {}, f"strategy_syntax_error:{exc}"

    strategy_class: ast.ClassDef | None = None
    for node in module.body:
        if isinstance(node, ast.ClassDef) and node.name == "Market_Making":
            strategy_class = node
            break
    if strategy_class is None:
        return {}, {}, {}, "market_making_class_missing"

    defaults: dict[str, Any] = {}
    signatures: dict[str, list[str]] = {}
    guards: dict[str, bool] = {
        "entry_price_tick_guard": False,
        "exit_price_tick_guard": False,
        "internal_estimator_call": False,
    }
    for node in strategy_class.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    try:
                        defaults[target.id] = safe_eval(node.value)
                    except Exception:
                        pass
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            try:
                defaults[node.target.id] = safe_eval(node.value) if node.value is not None else None
            except Exception:
                pass
        elif isinstance(node, ast.FunctionDef):
            signatures[node.name] = [arg.arg for arg in node.args.args]
            for child in ast.walk(node):
                if isinstance(child, ast.Call) and isinstance(child.func, ast.Name) and child.func.id == "schedule_tests":
                    guards["internal_estimator_call"] = True
            if node.name == "confirm_trade_entry":
                guards["entry_price_tick_guard"] = function_calls_price_tick_guard(node, "bid")
            elif node.name == "confirm_trade_exit":
                guards["exit_price_tick_guard"] = function_calls_price_tick_guard(node, "ask")
    return defaults, signatures, guards, None


def check_role_configs(strategy_path: Path) -> list[str]:
    """Validate the per-role configs the source parser structurally cannot see.

    ``can_short`` stopped being a single class-level constant when the strategy
    became two cooperating instances, so "the default is False" is no longer the
    whole safety property. What must hold now is that the long leg cannot short
    and the short leg can -- and that they disagree, because two legs configured
    identically are not a two-sided market maker, they are the same bot twice.
    """
    reasons: list[str] = []
    user_data = strategy_path.resolve().parent.parent
    expected = {"long": False, "short": True}
    seen: dict[str, Any] = {}

    for role, expected_can_short in expected.items():
        path = user_data / f"config.{role}.json"
        if not path.exists():
            reasons.append(f"role_config_missing:{role}")
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            reasons.append(f"role_config_unreadable:{role}")
            continue
        section = payload.get("market_making")
        if not isinstance(section, dict):
            reasons.append(f"role_config_market_making_missing:{role}")
            continue
        if section.get("role") != role:
            reasons.append(f"role_config_role_mismatch:{role}")
        if section.get("can_short") is not expected_can_short:
            reasons.append(f"role_config_can_short_wrong:{role}")
        seen[role] = section.get("can_short")

    if len(seen) == 2 and seen.get("long") == seen.get("short"):
        reasons.append("role_configs_do_not_differ")
    return reasons


def build_strategy_safety_report(
    source: str | None,
    *,
    strategy_path: Path,
    load_error: str | None = None,
) -> dict[str, Any]:
    reasons: list[str] = []
    defaults: dict[str, Any] = {}
    signatures: dict[str, list[str]] = {}
    guards: dict[str, bool] = {}
    parse_error = None
    if load_error is not None:
        reasons.append(load_error)
    else:
        defaults, signatures, guards, parse_error = parse_strategy_source(source or "")
        if parse_error is not None:
            reasons.append(parse_error)

    def require_value(key: str, expected: Any, reason: str) -> None:
        if defaults.get(key) != expected:
            reasons.append(reason)

    require_value("trading_enabled", False, "trading_enabled_default_not_false")
    require_value("fail_closed_reason", "initial_safety_lock", "fail_closed_reason_default_changed")
    require_value("post_only_verified", False, "post_only_verified_default_not_false")
    # can_short is now a per-INSTANCE setting (false on the long leg, true on the
    # short leg), supplied by config.long.json / config.short.json. The class
    # default must still be the safe one, so a strategy started without a role
    # config cannot short by accident. Role consistency itself is checked in
    # check_role_configs below -- a source-level parser cannot see runtime config.
    require_value("can_short", False, "can_short_default_not_false")
    require_value("use_exit_signal", True, "use_exit_signal_not_true")
    # position_adjustment_enable must now be TRUE: freqtrade rests one order per
    # pair, so inventory is carried as the SIZE of a single trade and |q| > 1 is
    # unreachable without it. The bound is q_max, enforced in
    # adjust_trade_position and by the HJB boundary, not by disabling the feature.
    require_value("position_adjustment_enable", True, "position_adjustment_enable_not_true")

    minimal_roi = defaults.get("minimal_roi")
    if not isinstance(minimal_roi, dict):
        reasons.append("minimal_roi_missing")
    elif finite_float(minimal_roi.get("0")) == -1:
        reasons.append("minimal_roi_force_exit_minus_one")
    elif finite_float(minimal_roi.get("0")) != 10:
        reasons.append("minimal_roi_not_disabled_default")

    order_types = defaults.get("order_types")
    if not isinstance(order_types, dict):
        reasons.append("order_types_missing")
    else:
        if str(order_types.get("entry") or "").lower() != "limit":
            reasons.append("entry_order_type_not_limit")
        if str(order_types.get("exit") or "").lower() != "limit":
            reasons.append("exit_order_type_not_limit")
        if str(order_types.get("emergency_exit") or "").lower() != "market":
            reasons.append("emergency_exit_order_type_not_market")

    for key in ("hjb_alpha", "hjb_phi", "inventory_unit_base"):
        value = finite_float(defaults.get(key))
        if value is None or value <= 0:
            reasons.append(f"{key}_not_positive")

    # q_max and the hard inventory cap must agree. If they drift apart you either
    # quote past the model's boundary or go dark inside it, and neither failure
    # is visible from the logs.
    q_max = finite_float(defaults.get("hjb_q_max"))
    max_units = finite_float(defaults.get("max_abs_inventory_units"))
    if q_max is None or q_max < 1:
        reasons.append("hjb_q_max_not_positive")
    if max_units is None or max_units < 1:
        reasons.append("max_abs_inventory_units_not_positive")
    if q_max is not None and max_units is not None and q_max != max_units:
        reasons.append("hjb_q_max_and_inventory_cap_disagree")

    # Notional/margin caps are checked against what the sizing can actually
    # reach. That is price-INDEPENDENT: the auto-sizing identity
    #   unit = available_capital * utilisation * leverage / (q_max * mid)
    # means q_max * unit * mid == available_capital * utilisation * leverage,
    # so no reference price is needed (and assuming one made this check wrong the
    # moment the symbol moved from ETH at ~1900 to CASHCAT at ~0.1).
    # Only meaningful when the strategy actually declares its capital sizing;
    # a strategy without those attributes has no reachable notional to compare.
    leverage = finite_float(defaults.get("target_leverage"))
    utilisation = finite_float(defaults.get("target_capital_utilisation"))
    reachable_notional = None
    if leverage is not None and utilisation is not None:
        reachable_notional = DEFAULT_AVAILABLE_CAPITAL * utilisation * leverage

    max_notional = finite_float(defaults.get("max_notional_exposure_usdc"))
    if max_notional is None or max_notional <= 0:
        reasons.append("max_notional_exposure_not_positive")
    elif reachable_notional is not None and max_notional < reachable_notional:
        # A cap below what the strategy can reach dead-stops the quoter.
        reasons.append("max_notional_exposure_below_reachable_inventory")
    elif max_notional > 4000:
        reasons.append("max_notional_exposure_above_plan_limit")

    max_margin = finite_float(defaults.get("max_margin_used_usdc"))
    if max_margin is None or max_margin <= 0:
        reasons.append("max_margin_used_not_positive")
    elif (
        reachable_notional is not None
        and leverage is not None
        and leverage > 0
        and max_margin < reachable_notional / leverage
    ):
        reasons.append("max_margin_used_below_reachable_inventory")
    elif max_margin > 2000:
        reasons.append("max_margin_used_above_plan_limit")
    min_liquidation_buffer = finite_float(defaults.get("min_liquidation_buffer_usdc"))
    if min_liquidation_buffer is None or min_liquidation_buffer <= 0:
        reasons.append("min_liquidation_buffer_not_positive")
    if finite_float(defaults.get("max_daily_loss_usdc")) is None or float(defaults.get("max_daily_loss_usdc")) > 20:
        reasons.append("max_daily_loss_above_plan_limit")

    for key in ("kill_on_taker_fill", "kill_on_time_in_force_mismatch", "kill_on_unknown_liquidity_fill"):
        if defaults.get(key) is not True:
            reasons.append(f"{key}_not_true")

    expected_entry_signature = ["self", "pair", "trade", "current_time", "proposed_rate"]
    if signatures.get("custom_entry_price", [])[:5] != expected_entry_signature:
        reasons.append("custom_entry_price_signature_mismatch")
    expected_stake_signature = [
        "self",
        "pair",
        "current_time",
        "current_rate",
        "proposed_stake",
        "min_stake",
        "max_stake",
        "leverage",
        "entry_tag",
    ]
    if signatures.get("custom_stake_amount", [])[:9] != expected_stake_signature:
        reasons.append("custom_stake_amount_signature_mismatch")
    for callback in (
        "confirm_trade_entry",
        "confirm_trade_exit",
        "custom_exit_price",
        "custom_stake_amount",
        "leverage",
        # Inventory is carried as the size of one trade, so this callback is the
        # only path to |q| > 1 and its absence would silently pin the strategy
        # to a two-state toggle.
        "adjust_trade_position",
        "adjust_entry_price",
        "adjust_exit_price",
        "_risk_flatten_request_payload",
        "_risk_flatten_cloid",
    ):
        if callback not in signatures:
            reasons.append(f"{callback}_missing")
    if "_price_tick_safe" not in signatures:
        reasons.append("price_tick_safe_guard_missing")
    if guards.get("entry_price_tick_guard") is not True:
        reasons.append("entry_price_tick_guard_missing")
    if guards.get("exit_price_tick_guard") is not True:
        reasons.append("exit_price_tick_guard_missing")
    if guards.get("internal_estimator_call") is True:
        reasons.append("internal_estimator_call_present")

    reasons.extend(check_role_configs(strategy_path))

    return {
        "generated_at": utc_now_iso(),
        "ok": not reasons,
        "reasons": reasons,
        "strategy_path": str(strategy_path),
        "observed": {
            "defaults": {
                key: defaults.get(key)
                for key in (
                    "trading_enabled",
                    "fail_closed_reason",
                    "post_only_verified",
                    "can_short",
                    "use_exit_signal",
                    "position_adjustment_enable",
                    "minimal_roi",
                    "order_types",
                    "hjb_alpha",
                    "hjb_phi",
                    "hjb_q_max",
                    "inventory_unit_base",
                    "max_abs_inventory_units",
                    "max_notional_exposure_usdc",
                    "max_margin_used_usdc",
                    "min_liquidation_buffer_usdc",
                    "max_daily_loss_usdc",
                    "kill_on_taker_fill",
                    "kill_on_time_in_force_mismatch",
                    "kill_on_unknown_liquidity_fill",
                )
            },
            "signatures": {
                key: signatures.get(key)
                for key in (
                    "custom_entry_price",
                    "custom_exit_price",
                    "custom_stake_amount",
                    "leverage",
                    "confirm_trade_entry",
                    "confirm_trade_exit",
                    "adjust_entry_price",
                    "adjust_exit_price",
                    "_risk_flatten_request_payload",
                    "_risk_flatten_cloid",
                    "_price_tick_safe",
                )
            },
            "guards": guards,
        },
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Verify checked-in strategy fail-closed safety defaults.")
    parser.add_argument("--strategy", type=Path, default=DEFAULT_STRATEGY)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        source = args.strategy.read_text(encoding="utf-8")
        load_error = None
    except FileNotFoundError:
        source = None
        load_error = "strategy_missing"
    except Exception as exc:
        source = None
        load_error = f"strategy_read_error:{exc}"

    report = build_strategy_safety_report(source, strategy_path=args.strategy, load_error=load_error)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
