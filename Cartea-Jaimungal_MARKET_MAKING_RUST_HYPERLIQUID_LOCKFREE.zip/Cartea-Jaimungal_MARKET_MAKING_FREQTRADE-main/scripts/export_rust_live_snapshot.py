#!/usr/bin/env python3
"""Export an atomic strategy snapshot consumed by the Rust live engine.

The existing Python calibration/HJB code can import ``write_snapshot`` directly,
or this file can be used as a CLI. Disk I/O and surface generation stay on the
cold path; Rust swaps only fully validated snapshots into the hot path.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Mapping


DEFAULT: dict[str, Any] = {
    "schema_version": 1,
    "revision": 1,
    "generated_at_ms": 0,
    "model": {
        "gamma": 0.05,
        "kappa": 1.5,
        "sigma": 0.5,
        "horizon_sec": 5.0,
        "base_half_spread_bps": 1.5,
        "inventory_skew_bps_per_lot": 0.15,
        "min_half_spread_ticks": 1,
        "quote_size_lots": 1,
        "max_quote_improvement_ticks": 1,
    },
    "risk": {
        "kill_switch": False,
        "max_inventory_lots": 20,
        "reduce_only_threshold_lots": 15,
        "max_order_notional": 1_000.0,
        "max_position_notional": 10_000.0,
        "max_market_spread_bps": 100.0,
    },
    "hjb": None,
}


def deep_merge(base: dict[str, Any], override: Mapping[str, Any]) -> dict[str, Any]:
    result = json.loads(json.dumps(base))
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_hjb_csv(path: Path) -> dict[str, Any]:
    rows: list[tuple[int, int, int]] = []
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        required = {"inventory_lots", "bid_offset_ticks", "ask_offset_ticks"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError(f"{path}: expected columns {sorted(required)}")
        for row in reader:
            rows.append(
                (
                    int(row["inventory_lots"]),
                    int(row["bid_offset_ticks"]),
                    int(row["ask_offset_ticks"]),
                )
            )
    rows.sort(key=lambda item: item[0])
    if not rows:
        raise ValueError(f"{path}: empty HJB surface")
    step = rows[1][0] - rows[0][0] if len(rows) > 1 else 1
    if step <= 0 or any(rows[i][0] - rows[i - 1][0] != step for i in range(1, len(rows))):
        raise ValueError("inventory_lots must form a strictly increasing regular grid")
    if any(bid <= 0 or ask <= 0 for _, bid, ask in rows):
        raise ValueError("HJB offsets must be strictly positive")
    return {
        "inventory_min_lots": rows[0][0],
        "inventory_step_lots": step,
        "bid_offset_ticks": [row[1] for row in rows],
        "ask_offset_ticks": [row[2] for row in rows],
    }


def validate(snapshot: Mapping[str, Any]) -> None:
    if snapshot.get("schema_version") != 1:
        raise ValueError("schema_version must be 1")
    model = snapshot["model"]
    risk = snapshot["risk"]
    if float(model["gamma"]) < 0:
        raise ValueError("gamma must be non-negative")
    if float(model["kappa"]) <= 0:
        raise ValueError("kappa must be positive")
    if float(model["sigma"]) < 0:
        raise ValueError("sigma must be non-negative")
    if float(model["horizon_sec"]) <= 0:
        raise ValueError("horizon_sec must be positive")
    if int(model["quote_size_lots"]) <= 0:
        raise ValueError("quote_size_lots must be positive")
    maximum = int(risk["max_inventory_lots"])
    threshold = int(risk["reduce_only_threshold_lots"])
    if maximum <= 0 or not 0 <= threshold <= maximum:
        raise ValueError("invalid inventory limits")


def write_snapshot(path: str | os.PathLike[str], snapshot: Mapping[str, Any]) -> None:
    """Validate and atomically publish a complete snapshot.

    Call this function from the existing estimator after each successful model
    calibration. A failed calibration must not overwrite the last good file.
    """

    path = Path(path)
    document = deep_merge(DEFAULT, snapshot)
    document["generated_at_ms"] = int(document.get("generated_at_ms") or time.time_ns() // 1_000_000)
    document["revision"] = int(document.get("revision") or document["generated_at_ms"])
    validate(document)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(document, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("config/strategy_snapshot.json"))
    parser.add_argument("--params-json", type=Path, help="JSON object merged over defaults")
    parser.add_argument("--hjb-csv", type=Path, help="regular inventory/offset table")
    parser.add_argument("--revision", type=int)
    parser.add_argument("--gamma", type=float)
    parser.add_argument("--kappa", type=float)
    parser.add_argument("--sigma", type=float)
    parser.add_argument("--horizon-sec", type=float)
    parser.add_argument("--base-half-spread-bps", type=float)
    parser.add_argument("--inventory-skew-bps-per-lot", type=float)
    parser.add_argument("--quote-size-lots", type=int)
    parser.add_argument("--max-inventory-lots", type=int)
    parser.add_argument("--reduce-only-threshold-lots", type=int)
    parser.add_argument("--max-order-notional", type=float)
    parser.add_argument("--max-position-notional", type=float)
    parser.add_argument("--kill-switch", action=argparse.BooleanOptionalAction)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    snapshot: dict[str, Any] = json.loads(json.dumps(DEFAULT))
    if args.params_json:
        with args.params_json.open(encoding="utf-8") as handle:
            snapshot = deep_merge(snapshot, json.load(handle))
    model_keys = {
        "gamma": args.gamma,
        "kappa": args.kappa,
        "sigma": args.sigma,
        "horizon_sec": args.horizon_sec,
        "base_half_spread_bps": args.base_half_spread_bps,
        "inventory_skew_bps_per_lot": args.inventory_skew_bps_per_lot,
        "quote_size_lots": args.quote_size_lots,
    }
    risk_keys = {
        "max_inventory_lots": args.max_inventory_lots,
        "reduce_only_threshold_lots": args.reduce_only_threshold_lots,
        "max_order_notional": args.max_order_notional,
        "max_position_notional": args.max_position_notional,
        "kill_switch": args.kill_switch,
    }
    snapshot["model"].update({key: value for key, value in model_keys.items() if value is not None})
    snapshot["risk"].update({key: value for key, value in risk_keys.items() if value is not None})
    if args.hjb_csv:
        snapshot["hjb"] = load_hjb_csv(args.hjb_csv)
    now_ms = time.time_ns() // 1_000_000
    snapshot["revision"] = args.revision or now_ms
    snapshot["generated_at_ms"] = now_ms
    write_snapshot(args.output, snapshot)
    print(f"published revision {snapshot['revision']} -> {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
