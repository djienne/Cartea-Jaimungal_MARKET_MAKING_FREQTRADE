# Benchmark du hot path Rust

Généré le `2026-08-20T23:36:49.205646+00:00`.

- Plateforme : `Linux-6.18.35-x86_64-with-glibc2.41`
- Python hôte : `3.13.5`
- CPU logiques visibles : `5`
- Code de sortie : `127`

Ce microbenchmark mesure le calcul local BBO → décision de quote. Il ne mesure ni le réseau, ni la confirmation Hyperliquid, ni la signature/action WebSocket.

```text
timeout: failed to run command 'rust_live/target/release/hot-path-bench': No such file or directory
```
