#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="${1:-$ROOT/config/live.toml}"
exec cargo run --manifest-path "$ROOT/rust_live/Cargo.toml" --release --bin mm-live -- --config "$CONFIG"
