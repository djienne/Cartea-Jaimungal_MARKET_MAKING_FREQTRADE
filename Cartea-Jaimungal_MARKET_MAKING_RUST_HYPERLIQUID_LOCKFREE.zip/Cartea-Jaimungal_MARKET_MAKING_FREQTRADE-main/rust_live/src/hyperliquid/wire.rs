use crate::config::MarketConfig;
use crate::types::{Bbo, Fill, OrderStatus, OrderUpdate, Side, TakerSide, Trade};
use anyhow::{bail, Result};
use serde_json::Value;

pub fn parse_decimal_scaled(input: &str, decimals: u32) -> Result<i64> {
    let input = input.trim();
    if input.is_empty() {
        bail!("empty decimal");
    }
    let (negative, body) = match input.as_bytes()[0] {
        b'-' => (true, &input[1..]),
        b'+' => (false, &input[1..]),
        _ => (false, input),
    };
    if body.is_empty() || body.contains('e') || body.contains('E') {
        bail!("unsupported decimal format {input}");
    }
    let mut parts = body.split('.');
    let whole = parts.next().unwrap_or("0");
    let frac = parts.next().unwrap_or("");
    if parts.next().is_some()
        || !whole.bytes().all(|b| b.is_ascii_digit())
        || !frac.bytes().all(|b| b.is_ascii_digit())
    {
        bail!("invalid decimal {input}");
    }
    let scale = 10_i128.pow(decimals);
    let whole_value = if whole.is_empty() {
        0_i128
    } else {
        whole.parse::<i128>()?
    };
    let keep = decimals as usize;
    let mut frac_value = 0_i128;
    for (idx, byte) in frac.bytes().take(keep).enumerate() {
        let digit = (byte - b'0') as i128;
        frac_value += digit * 10_i128.pow((keep - idx - 1) as u32);
    }
    let mut value = whole_value
        .checked_mul(scale)
        .and_then(|x| x.checked_add(frac_value))
        .ok_or_else(|| anyhow::anyhow!("decimal overflow"))?;
    if frac.len() > keep && frac.as_bytes()[keep] >= b'5' {
        value = value.checked_add(1).ok_or_else(|| anyhow::anyhow!("decimal overflow"))?;
    }
    if negative {
        value = -value;
    }
    i64::try_from(value).map_err(|error| anyhow::anyhow!(error))
}

pub fn format_decimal_scaled(value: i64, decimals: u32) -> String {
    let negative = value < 0;
    let abs = (value as i128).abs();
    if decimals == 0 {
        return format!("{}{}", if negative { "-" } else { "" }, abs);
    }
    let scale = 10_i128.pow(decimals);
    let whole = abs / scale;
    let mut frac = format!("{:0width$}", abs % scale, width = decimals as usize);
    while frac.ends_with('0') {
        frac.pop();
    }
    if frac.is_empty() {
        format!("{}{}", if negative { "-" } else { "" }, whole)
    } else {
        format!("{}{}.{}", if negative { "-" } else { "" }, whole, frac)
    }
}

fn string_field<'a>(value: &'a Value, keys: &[&str]) -> Option<&'a str> {
    keys.iter().find_map(|key| value.get(*key)?.as_str())
}

fn u64_field(value: &Value, keys: &[&str]) -> Option<u64> {
    keys.iter().find_map(|key| {
        value
            .get(*key)
            .and_then(|v| v.as_u64().or_else(|| v.as_str()?.parse::<u64>().ok()))
    })
}

pub fn parse_bbo_message(
    root: &Value,
    coin: &str,
    market: &MarketConfig,
    recv_ns: u64,
) -> Option<Bbo> {
    if root.get("channel")?.as_str()? != "bbo" {
        return None;
    }
    let data = root.get("data")?;
    if data.get("coin")?.as_str()? != coin {
        return None;
    }
    let levels = data.get("bbo")?.as_array()?;
    let bid = levels.first()?;
    let ask = levels.get(1)?;
    if bid.is_null() || ask.is_null() { return None; }
    let bid_px = parse_decimal_scaled(string_field(bid, &["px", "price"] )?, market.price_decimals).ok()?;
    let bid_sz = parse_decimal_scaled(string_field(bid, &["sz", "size"] )?, market.size_decimals).ok()?;
    let ask_px = parse_decimal_scaled(string_field(ask, &["px", "price"] )?, market.price_decimals).ok()?;
    let ask_sz = parse_decimal_scaled(string_field(ask, &["sz", "size"] )?, market.size_decimals).ok()?;
    Some(Bbo {
        bid_px,
        bid_sz,
        ask_px,
        ask_sz,
        exchange_ms: u64_field(data, &["time", "timestamp"]).unwrap_or_default(),
        recv_ns,
    })
}

pub fn parse_l2_top_message(
    root: &Value,
    coin: &str,
    market: &MarketConfig,
    recv_ns: u64,
) -> Option<Bbo> {
    if root.get("channel")?.as_str()? != "l2Book" {
        return None;
    }
    let data = root.get("data")?;
    if data.get("coin")?.as_str()? != coin {
        return None;
    }
    let sides = data.get("levels")?.as_array()?;
    let bid = sides.first()?.as_array()?.first()?;
    let ask = sides.get(1)?.as_array()?.first()?;
    Some(Bbo {
        bid_px: parse_decimal_scaled(bid.get("px")?.as_str()?, market.price_decimals).ok()?,
        bid_sz: parse_decimal_scaled(bid.get("sz")?.as_str()?, market.size_decimals).ok()?,
        ask_px: parse_decimal_scaled(ask.get("px")?.as_str()?, market.price_decimals).ok()?,
        ask_sz: parse_decimal_scaled(ask.get("sz")?.as_str()?, market.size_decimals).ok()?,
        exchange_ms: u64_field(data, &["time", "timestamp"]).unwrap_or_default(),
        recv_ns,
    })
}

pub fn parse_trade_messages(
    root: &Value,
    coin: &str,
    market: &MarketConfig,
    recv_ns: u64,
) -> Vec<Trade> {
    if root.get("channel").and_then(Value::as_str) != Some("trades") {
        return Vec::new();
    }
    let Some(items) = root.get("data").and_then(Value::as_array) else {
        return Vec::new();
    };
    items
        .iter()
        .filter(|item| item.get("coin").and_then(Value::as_str) == Some(coin))
        .filter_map(|item| {
            let taker_side = match item.get("side")?.as_str()? {
                "B" | "buy" | "Buy" => TakerSide::Buy,
                "A" | "S" | "sell" | "Sell" => TakerSide::Sell,
                _ => return None,
            };
            Some(Trade {
                taker_side,
                px: parse_decimal_scaled(item.get("px")?.as_str()?, market.price_decimals).ok()?,
                qty_units: parse_decimal_scaled(item.get("sz")?.as_str()?, market.size_decimals).ok()?,
                exchange_ms: u64_field(item, &["time", "timestamp"]).unwrap_or_default(),
                recv_ns,
            })
        })
        .collect()
}

fn side_from_wire(value: &str) -> Option<Side> {
    match value {
        "B" | "buy" | "Buy" => Some(Side::Buy),
        "A" | "S" | "sell" | "Sell" => Some(Side::Sell),
        _ => None,
    }
}

pub fn cloid_to_hash(cloid: Option<&str>) -> u128 {
    cloid
        .and_then(|s| s.strip_prefix("0x").or(Some(s)))
        .and_then(|s| u128::from_str_radix(s, 16).ok())
        .unwrap_or_default()
}

pub fn parse_user_fills(
    root: &Value,
    coin: &str,
    market: &MarketConfig,
) -> Vec<Fill> {
    if root.get("channel").and_then(Value::as_str) != Some("userFills") {
        return Vec::new();
    }
    let Some(data) = root.get("data") else {
        return Vec::new();
    };
    if data.get("isSnapshot").and_then(Value::as_bool) == Some(true) {
        return Vec::new();
    }
    let Some(items) = data.get("fills").and_then(Value::as_array) else {
        return Vec::new();
    };
    items
        .iter()
        .filter(|item| item.get("coin").and_then(Value::as_str) == Some(coin))
        .filter_map(|item| {
            let side = side_from_wire(item.get("side")?.as_str()?)?;
            let qty_units =
                parse_decimal_scaled(item.get("sz")?.as_str()?, market.size_decimals).ok()?;
            let qty_lots = ((qty_units as f64 / market.size_step_units as f64).round() as i64).max(1);
            let fee = item
                .get("fee")
                .and_then(Value::as_str)
                .and_then(|s| parse_decimal_scaled(s, market.price_decimals).ok())
                .unwrap_or_default();
            Some(Fill {
                side,
                px: parse_decimal_scaled(item.get("px")?.as_str()?, market.price_decimals).ok()?,
                qty_lots,
                fee_quote_units: fee,
                exchange_ms: u64_field(item, &["time", "timestamp"]).unwrap_or_default(),
                oid: u64_field(item, &["oid"]),
                cloid_hash: cloid_to_hash(item.get("cloid").and_then(Value::as_str)),
            })
        })
        .collect()
}

pub fn parse_order_updates(
    root: &Value,
    coin: &str,
    market: &MarketConfig,
) -> Vec<OrderUpdate> {
    if root.get("channel").and_then(Value::as_str) != Some("orderUpdates") {
        return Vec::new();
    }
    let Some(items) = root.get("data").and_then(Value::as_array) else {
        return Vec::new();
    };
    items
        .iter()
        .filter_map(|update| {
            let order = update.get("order").unwrap_or(update);
            if order.get("coin").and_then(Value::as_str) != Some(coin) {
                return None;
            }
            let status_raw = update
                .get("status")
                .and_then(Value::as_str)
                .unwrap_or("unknown");
            let status = match status_raw {
                "open" | "triggered" => OrderStatus::Open,
                "filled" => OrderStatus::Filled,
                "canceled" | "cancelled" | "marginCanceled" | "vaultWithdrawalCanceled"
                | "scheduledCancel" | "selfTradeCanceled" | "reduceOnlyCanceled" => OrderStatus::Canceled,
                "rejected" => OrderStatus::Rejected,
                _ => OrderStatus::Unknown,
            };
            let side = side_from_wire(order.get("side")?.as_str()?)?;
            let qty_lots = order
                .get("sz")
                .and_then(Value::as_str)
                .and_then(|s| parse_decimal_scaled(s, market.size_decimals).ok())
                .map(|units| ((units as f64 / market.size_step_units as f64).round() as i64).max(1));
            Some(OrderUpdate {
                side,
                oid: u64_field(order, &["oid"]),
                cloid: order.get("cloid").and_then(Value::as_str).map(str::to_owned),
                status,
                px: order
                    .get("limitPx")
                    .or_else(|| order.get("px"))
                    .and_then(Value::as_str)
                    .and_then(|s| parse_decimal_scaled(s, market.price_decimals).ok()),
                qty_lots,
            })
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decimals_round_trip() {
        assert_eq!(parse_decimal_scaled("123.4567", 3).unwrap(), 123_457);
        assert_eq!(parse_decimal_scaled("-0.001", 4).unwrap(), -10);
        assert_eq!(format_decimal_scaled(123_450, 3), "123.45");
    }
}
