use alloy::{
    dyn_abi::Eip712Domain,
    primitives::{keccak256, Address, Signature, B256},
    signers::{local::PrivateKeySigner, Signer, SignerSync},
    sol,
    sol_types::{eip712_domain, SolStruct},
};
use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::str::FromStr;
use std::sync::atomic::{AtomicU64, Ordering};

sol! {
    #[derive(Debug)]
    struct Agent {
        string source;
        bytes32 connectionId;
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LimitWire {
    pub tif: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum OrderTypeWire {
    Limit(LimitWire),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderWire {
    #[serde(rename = "a")]
    pub asset: u32,
    #[serde(rename = "b")]
    pub is_buy: bool,
    #[serde(rename = "p")]
    pub limit_px: String,
    #[serde(rename = "s")]
    pub size: String,
    #[serde(rename = "r")]
    pub reduce_only: bool,
    #[serde(rename = "t")]
    pub order_type: OrderTypeWire,
    #[serde(rename = "c", skip_serializing_if = "Option::is_none")]
    pub cloid: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BulkOrder {
    pub orders: Vec<OrderWire>,
    pub grouping: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub builder: Option<serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CancelWire {
    #[serde(rename = "a")]
    pub asset: u32,
    #[serde(rename = "o")]
    pub oid: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BulkCancel {
    pub cancels: Vec<CancelWire>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CancelByCloidWire {
    pub asset: u32,
    pub cloid: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BulkCancelByCloid {
    pub cancels: Vec<CancelByCloidWire>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModifyWire {
    pub oid: u64,
    pub order: OrderWire,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BulkModify {
    pub modifies: Vec<ModifyWire>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ScheduleCancel {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub time: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "camelCase")]
pub enum Action {
    Order(BulkOrder),
    Cancel(BulkCancel),
    CancelByCloid(BulkCancelByCloid),
    BatchModify(BulkModify),
    ScheduleCancel(ScheduleCancel),
}

#[derive(Debug, Serialize)]
pub struct SignatureWire {
    pub r: String,
    pub s: String,
    pub v: u64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SignedActionPayload {
    pub action: serde_json::Value,
    pub signature: SignatureWire,
    pub nonce: u64,
    pub vault_address: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub expires_after: Option<u64>,
}

pub struct ActionSigner {
    wallet: PrivateKeySigner,
    is_mainnet: bool,
    vault_address: Option<Address>,
    vault_address_wire: Option<String>,
    nonce: AtomicU64,
}

impl ActionSigner {
    pub fn new(
        private_key: &str,
        is_mainnet: bool,
        vault_address: Option<&str>,
    ) -> Result<Self> {
        let wallet = private_key
            .parse::<PrivateKeySigner>()
            .context("invalid Hyperliquid private key")?;
        let vault = vault_address
            .map(Address::from_str)
            .transpose()
            .context("invalid vault address")?;
        Ok(Self {
            wallet,
            is_mainnet,
            vault_address: vault,
            vault_address_wire: vault_address.map(|value| value.to_lowercase()),
            nonce: AtomicU64::new(0),
        })
    }

    pub fn signer_address(&self) -> String {
        format!("{:#x}", self.wallet.address())
    }

    pub fn next_nonce(&self, now_ms: u64) -> u64 {
        let mut previous = self.nonce.load(Ordering::Relaxed);
        loop {
            let next = now_ms.max(previous.saturating_add(1));
            match self.nonce.compare_exchange_weak(
                previous,
                next,
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => return next,
                Err(actual) => previous = actual,
            }
        }
    }

    pub fn sign_action(
        &self,
        action: &Action,
        nonce: u64,
        expires_after: Option<u64>,
    ) -> Result<SignedActionPayload> {
        let connection_id = action_hash(action, self.vault_address, nonce, expires_after)?;
        let signature = sign_l1_action(&self.wallet, connection_id, self.is_mainnet)?;
        let action = serde_json::to_value(action)?;
        Ok(SignedActionPayload {
            action,
            signature: signature_to_wire(&signature),
            nonce,
            vault_address: self.vault_address_wire.clone(),
            expires_after,
        })
    }
}

fn action_hash(
    action: &Action,
    vault_address: Option<Address>,
    nonce: u64,
    expires_after: Option<u64>,
) -> Result<B256> {
    let mut bytes = rmp_serde::to_vec_named(action)?;
    bytes.extend_from_slice(&nonce.to_be_bytes());
    match vault_address {
        Some(address) => {
            bytes.push(1);
            bytes.extend_from_slice(address.as_slice());
        }
        None => bytes.push(0),
    }
    if let Some(expires_after) = expires_after {
        bytes.push(0);
        bytes.extend_from_slice(&expires_after.to_be_bytes());
    }
    Ok(keccak256(bytes))
}

fn sign_l1_action(
    wallet: &PrivateKeySigner,
    connection_id: B256,
    is_mainnet: bool,
) -> Result<Signature> {
    let domain: Eip712Domain = eip712_domain! {
        name: "Exchange",
        version: "1",
        chain_id: 1337,
        verifying_contract: Address::ZERO,
    };
    let agent = Agent {
        source: if is_mainnet { "a" } else { "b" }.to_owned(),
        connectionId: connection_id,
    };
    let mut input = [0_u8; 66];
    input[0] = 0x19;
    input[1] = 0x01;
    input[2..34].copy_from_slice(domain.hash_struct().as_slice());
    input[34..66].copy_from_slice(agent.eip712_hash_struct().as_slice());
    let digest = keccak256(input);
    wallet
        .sign_hash_sync(&digest)
        .map_err(|error| anyhow::anyhow!("cannot sign Hyperliquid L1 action: {error}"))
}

fn signature_to_wire(signature: &Signature) -> SignatureWire {
    SignatureWire {
        r: format!("{:#x}", signature.r()),
        s: format!("{:#x}", signature.s()),
        v: 27 + signature.v() as u64,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn order_wire_uses_compact_exchange_keys() {
        let action = Action::Order(BulkOrder {
            orders: vec![OrderWire {
                asset: 1,
                is_buy: true,
                limit_px: "100.1".to_owned(),
                size: "0.01".to_owned(),
                reduce_only: false,
                order_type: OrderTypeWire::Limit(LimitWire { tif: "Alo".to_owned() }),
                cloid: Some("0x00000000000000000000000000000001".to_owned()),
            }],
            grouping: "na".to_owned(),
            builder: None,
        });
        let value = serde_json::to_value(action).unwrap();
        let order = &value["orders"][0];
        assert_eq!(order["a"], 1);
        assert_eq!(order["b"], true);
        assert_eq!(order["t"]["limit"]["tif"], "Alo");
    }
}
