use crate::config::{MarketConfig, Network};
use crate::hyperliquid::wire::{parse_bbo_message, parse_l2_top_message, parse_trade_messages};
use crate::lockfree::{AsyncRing, HotPathSignal, HOT_SIGNAL_MARKET};
use crate::metrics::Metrics;
use crate::types::{AtomicBbo, MarketProbe, ProcessClock};
use futures_util::{SinkExt, StreamExt};
use serde_json::json;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::watch;
use tokio_tungstenite::{connect_async, tungstenite::Message};
use tracing::{info, warn};

pub struct MarketStreamArgs {
    pub coin: String,
    pub network: Network,
    pub config: MarketConfig,
    pub latest_bbo: Arc<AtomicBbo>,
    pub hot_signal: Arc<HotPathSignal>,
    /// Present in dry-run mode, where ordered BBO/trade probes feed the fill
    /// simulator. Real execution uses private fills and does not allocate or
    /// enqueue this optional stream.
    pub probe_ring: Option<Arc<AsyncRing<MarketProbe>>>,
    pub clock: Arc<ProcessClock>,
    pub metrics: Arc<Metrics>,
    pub shutdown: watch::Receiver<bool>,
}

pub async fn run_market_stream(mut args: MarketStreamArgs) {
    let url = args.config.effective_ws_url(args.network);
    let mut backoff_ms = args.config.reconnect_min_ms.max(50);
    loop {
        if *args.shutdown.borrow() {
            break;
        }
        match connect_async(&url).await {
            Ok((socket, _)) => {
                info!(%url, coin = %args.coin, "public market WebSocket connected");
                backoff_ms = args.config.reconnect_min_ms.max(50);
                if let Err(error) = run_connected(&mut args, socket).await {
                    warn!(%error, "public market WebSocket disconnected");
                }
            }
            Err(error) => warn!(%error, %url, "cannot connect public market WebSocket"),
        }
        args.metrics.ws_reconnects.fetch_add(1, Ordering::Relaxed);
        tokio::select! {
            _ = tokio::time::sleep(Duration::from_millis(backoff_ms)) => {}
            changed = args.shutdown.changed() => {
                if changed.is_err() || *args.shutdown.borrow() { break; }
            }
        }
        backoff_ms = (backoff_ms.saturating_mul(2)).min(args.config.reconnect_max_ms.max(backoff_ms));
    }
}

async fn run_connected<S>(
    args: &mut MarketStreamArgs,
    socket: tokio_tungstenite::WebSocketStream<S>,
) -> anyhow::Result<()>
where
    S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin,
{
    let (mut write, mut read) = socket.split();
    if args.config.subscribe_bbo {
        let message = json!({
            "method": "subscribe",
            "subscription": {"type": "bbo", "coin": args.coin}
        });
        write.send(Message::Text(message.to_string().into())).await?;
    } else {
        let message = json!({
            "method": "subscribe",
            "subscription": {"type": "l2Book", "coin": args.coin}
        });
        write.send(Message::Text(message.to_string().into())).await?;
    }

    // Trades are consumed only by the dry-run queue simulator. In real mode,
    // private user fills are authoritative and avoiding this subscription cuts
    // parsing/allocation load from the execution process.
    let consume_trades = args.config.subscribe_trades && args.probe_ring.is_some();
    if consume_trades {
        let message = json!({
            "method": "subscribe",
            "subscription": {"type": "trades", "coin": args.coin}
        });
        write.send(Message::Text(message.to_string().into())).await?;
    }

    let mut ping = tokio::time::interval(Duration::from_secs(30));
    ping.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    loop {
        tokio::select! {
            incoming = read.next() => {
                let Some(incoming) = incoming else { anyhow::bail!("stream ended") };
                match incoming? {
                    Message::Text(text) => {
                        args.metrics.market_messages.fetch_add(1, Ordering::Relaxed);
                        let root: serde_json::Value = match serde_json::from_str(text.as_str()) {
                            Ok(value) => value,
                            Err(_) => continue,
                        };
                        let recv_ns = args.clock.now_ns();
                        let bbo = parse_bbo_message(&root, &args.coin, &args.config, recv_ns)
                            .or_else(|| parse_l2_top_message(&root, &args.coin, &args.config, recv_ns));
                        if let Some(bbo) = bbo {
                            if bbo.is_valid() {
                                args.latest_bbo.store(bbo);
                                args.metrics.bbo_updates.fetch_add(1, Ordering::Relaxed);
                                // In dry-run, publish the causal market probe before waking
                                // quote computation. The simulator can therefore process the
                                // market event before applying the quote derived from it.
                                if let Some(ring) = &args.probe_ring {
                                    if ring.try_push(MarketProbe::Bbo(bbo)).is_err() {
                                        args.metrics
                                            .dropped_market_probes
                                            .fetch_add(1, Ordering::Relaxed);
                                    }
                                }
                                if !args.hot_signal.notify(HOT_SIGNAL_MARKET) {
                                    // A pending market bit means the hot thread will read
                                    // the newer atomic BBO anyway; this is coalescing, not
                                    // market-state loss.
                                    args.metrics.coalesced_market_signals.fetch_add(1, Ordering::Relaxed);
                                }
                            } else {
                                args.metrics.invalid_bbo.fetch_add(1, Ordering::Relaxed);
                            }
                        }
                        if consume_trades {
                            for trade in parse_trade_messages(&root, &args.coin, &args.config, recv_ns) {
                                args.metrics.trade_messages.fetch_add(1, Ordering::Relaxed);
                                let Some(ring) = &args.probe_ring else { continue };
                                if ring.try_push(MarketProbe::Trade(trade)).is_err() {
                                    args.metrics.dropped_trades.fetch_add(1, Ordering::Relaxed);
                                }
                            }
                        }
                    }
                    Message::Ping(payload) => write.send(Message::Pong(payload)).await?,
                    Message::Close(frame) => anyhow::bail!("server close: {frame:?}"),
                    _ => {}
                }
            }
            _ = ping.tick() => {
                let ping = json!({"method": "ping"});
                write.send(Message::Text(ping.to_string().into())).await?;
            }
            changed = args.shutdown.changed() => {
                if changed.is_err() || *args.shutdown.borrow() {
                    let _ = write.send(Message::Close(None)).await;
                    return Ok(());
                }
            }
        }
    }
}
