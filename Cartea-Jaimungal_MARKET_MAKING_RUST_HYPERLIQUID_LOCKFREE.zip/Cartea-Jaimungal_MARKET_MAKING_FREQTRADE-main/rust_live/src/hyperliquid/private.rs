use crate::config::{MarketConfig, Network};
use crate::hyperliquid::rpc::WsRpcClient;
use crate::hyperliquid::wire::{parse_decimal_scaled, parse_order_updates, parse_user_fills};
use crate::lockfree::AsyncRing;
use crate::metrics::Metrics;
use crate::types::BackendEvent;
use futures_util::{SinkExt, StreamExt};
use serde_json::{json, Value};
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::watch;
use tokio_tungstenite::{connect_async, tungstenite::Message};
use tracing::{info, warn};

pub struct PrivateStreamArgs {
    pub network: Network,
    pub ws_url: Option<String>,
    pub user: String,
    pub coin: String,
    pub market: MarketConfig,
    pub event_ring: Arc<AsyncRing<BackendEvent>>,
    pub metrics: Arc<Metrics>,
    pub shutdown: watch::Receiver<bool>,
}

pub async fn run_private_stream(mut args: PrivateStreamArgs) {
    let url = args
        .ws_url
        .clone()
        .unwrap_or_else(|| args.network.ws_url().to_owned());
    let mut reconnect_ms = args.market.reconnect_min_ms.max(50);
    loop {
        if *args.shutdown.borrow() {
            return;
        }
        match connect_async(&url).await {
            Ok((socket, _)) => {
                reconnect_ms = args.market.reconnect_min_ms.max(50);
                info!(user = %args.user, "private account WebSocket connected");
                if let Err(error) = run_connected(&mut args, socket).await {
                    warn!(%error, "private account WebSocket disconnected");
                    if !publish_event(
                        &mut args,
                        BackendEvent::Disconnected {
                            reason: error.to_string(),
                        },
                    )
                    .await
                    {
                        return;
                    }
                }
            }
            Err(error) => {
                warn!(%error, "cannot connect private account WebSocket");
                if !publish_event(
                    &mut args,
                    BackendEvent::Disconnected {
                        reason: error.to_string(),
                    },
                )
                .await
                {
                    return;
                }
            }
        }
        tokio::select! {
            _ = tokio::time::sleep(Duration::from_millis(reconnect_ms)) => {}
            changed = args.shutdown.changed() => {
                if changed.is_err() || *args.shutdown.borrow() { return; }
            }
        }
        reconnect_ms = (reconnect_ms * 2).min(args.market.reconnect_max_ms.max(reconnect_ms));
    }
}

async fn publish_event(args: &mut PrivateStreamArgs, event: BackendEvent) -> bool {
    let ring = args.event_ring.clone();
    match ring.push_or_shutdown(event, &mut args.shutdown).await {
        Ok(backpressured) => {
            if backpressured {
                args.metrics
                    .ring_backpressure_events
                    .fetch_add(1, Ordering::Relaxed);
            }
            true
        }
        Err(_) => false,
    }
}

async fn run_connected<S>(
    args: &mut PrivateStreamArgs,
    socket: tokio_tungstenite::WebSocketStream<S>,
) -> anyhow::Result<()>
where
    S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin,
{
    let (mut write, mut read) = socket.split();
    for subscription in [
        json!({"type": "orderUpdates", "user": args.user}),
        json!({"type": "userFills", "user": args.user, "aggregateByTime": false}),
    ] {
        let message = json!({"method": "subscribe", "subscription": subscription});
        write.send(Message::Text(message.to_string().into())).await?;
    }
    if !publish_event(args, BackendEvent::Connected).await {
        return Ok(());
    }
    let mut ping = tokio::time::interval(Duration::from_secs(30));
    ping.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    loop {
        tokio::select! {
            incoming = read.next() => {
                let Some(incoming) = incoming else { anyhow::bail!("private stream ended") };
                match incoming? {
                    Message::Text(text) => {
                        let Ok(root) = serde_json::from_str::<Value>(text.as_ref()) else { continue };
                        for fill in parse_user_fills(&root, &args.coin, &args.market) {
                            if !publish_event(args, BackendEvent::Fill(fill)).await {
                                return Ok(());
                            }
                        }
                        for update in parse_order_updates(&root, &args.coin, &args.market) {
                            if !publish_event(args, BackendEvent::OrderUpdate(update)).await {
                                return Ok(());
                            }
                        }
                    }
                    Message::Ping(payload) => write.send(Message::Pong(payload)).await?,
                    Message::Close(frame) => anyhow::bail!("server close: {frame:?}"),
                    _ => {}
                }
            }
            _ = ping.tick() => {
                write.send(Message::Text(json!({"method":"ping"}).to_string().into())).await?;
            }
            changed = args.shutdown.changed() => {
                if changed.is_err() || *args.shutdown.borrow() {
                    let _ = write.send(Message::Close(None)).await;
                    return Ok(());
                }
            }
        }
    }
}

pub async fn run_position_sync(
    rpc: WsRpcClient,
    user: String,
    coin: String,
    market: MarketConfig,
    interval_ms: u64,
    event_ring: Arc<AsyncRing<BackendEvent>>,
    metrics: Arc<Metrics>,
    mut shutdown: watch::Receiver<bool>,
) {
    let mut interval = tokio::time::interval(Duration::from_millis(interval_ms.max(1_000)));
    interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    loop {
        tokio::select! {
            _ = interval.tick() => {
                let payload = json!({"type": "clearinghouseState", "user": user});
                match rpc.post_info(payload).await {
                    Ok(response) => {
                        if let Some(inventory_lots) = parse_position_lots(&response, &coin, &market) {
                            match event_ring
                                .push_or_shutdown(
                                    BackendEvent::PositionSnapshot { inventory_lots },
                                    &mut shutdown,
                                )
                                .await
                            {
                                Ok(backpressured) => {
                                    if backpressured {
                                        metrics
                                            .ring_backpressure_events
                                            .fetch_add(1, Ordering::Relaxed);
                                    }
                                }
                                Err(_) => return,
                            }
                        }
                    }
                    Err(error) => warn!(%error, "position synchronization over WebSocket failed"),
                }
            }
            changed = shutdown.changed() => {
                if changed.is_err() || *shutdown.borrow() { return; }
            }
        }
    }
}

fn find_asset_positions(value: &Value) -> Option<&Vec<Value>> {
    if let Some(array) = value.get("assetPositions").and_then(Value::as_array) {
        return Some(array);
    }
    match value {
        Value::Object(map) => map.values().find_map(find_asset_positions),
        Value::Array(values) => values.iter().find_map(find_asset_positions),
        _ => None,
    }
}

fn parse_position_lots(value: &Value, coin: &str, market: &MarketConfig) -> Option<i64> {
    let positions = find_asset_positions(value)?;
    for item in positions {
        let position = item.get("position").unwrap_or(item);
        if position.get("coin").and_then(Value::as_str) != Some(coin) {
            continue;
        }
        let units = parse_decimal_scaled(position.get("szi")?.as_str()?, market.size_decimals).ok()?;
        return Some((units as f64 / market.size_step_units as f64).round() as i64);
    }
    Some(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_position_from_nested_ws_response() {
        let value = json!({"payload":{"assetPositions":[{"position":{"coin":"ETH","szi":"-0.012"}}]}});
        let market = MarketConfig {
            size_decimals: 3,
            size_step_units: 1,
            ..MarketConfig::default()
        };
        assert_eq!(parse_position_lots(&value, "ETH", &market), Some(-12));
    }
}
