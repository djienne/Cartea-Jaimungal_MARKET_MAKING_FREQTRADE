use crate::metrics::Metrics;
use anyhow::{anyhow, Context, Result};
use futures_util::{SinkExt, StreamExt};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::{mpsc, oneshot, watch};
use tokio_tungstenite::{connect_async, tungstenite::Message};
use tracing::{info, warn};

struct RpcCommand {
    request_type: &'static str,
    payload: Value,
    reply: oneshot::Sender<std::result::Result<Value, String>>,
}

#[derive(Clone)]
pub struct WsRpcClient {
    tx: mpsc::Sender<RpcCommand>,
    timeout: Duration,
}

impl WsRpcClient {
    pub fn spawn(
        url: String,
        max_pending: usize,
        timeout: Duration,
        metrics: Arc<Metrics>,
        shutdown: watch::Receiver<bool>,
    ) -> Self {
        let (tx, rx) = mpsc::channel(max_pending.max(1));
        tokio::spawn(run_rpc_actor(url, max_pending.max(1), rx, metrics, shutdown));
        Self { tx, timeout }
    }

    pub async fn post_action(&self, payload: Value) -> Result<Value> {
        self.call("action", payload).await
    }

    pub async fn post_info(&self, payload: Value) -> Result<Value> {
        self.call("info", payload).await
    }

    async fn call(&self, request_type: &'static str, payload: Value) -> Result<Value> {
        let (reply_tx, reply_rx) = oneshot::channel();
        self.tx
            .send(RpcCommand {
                request_type,
                payload,
                reply: reply_tx,
            })
            .await
            .context("Hyperliquid WS RPC actor stopped")?;
        let response = tokio::time::timeout(self.timeout, reply_rx)
            .await
            .context("Hyperliquid WS RPC timeout")?
            .context("Hyperliquid WS RPC response channel closed")?;
        response.map_err(anyhow::Error::msg)
    }
}

async fn run_rpc_actor(
    url: String,
    max_pending: usize,
    mut rx: mpsc::Receiver<RpcCommand>,
    metrics: Arc<Metrics>,
    mut shutdown: watch::Receiver<bool>,
) {
    let ids = AtomicU64::new(1);
    let mut reconnect_ms = 250_u64;
    loop {
        if *shutdown.borrow() {
            return;
        }
        let socket = match connect_async(&url).await {
            Ok((socket, _)) => socket,
            Err(error) => {
                warn!(%error, %url, "cannot connect action/info WebSocket");
                metrics.ws_reconnects.fetch_add(1, Ordering::Relaxed);
                tokio::select! {
                    _ = tokio::time::sleep(Duration::from_millis(reconnect_ms)) => {}
                    changed = shutdown.changed() => {
                        if changed.is_err() || *shutdown.borrow() { return; }
                    }
                }
                reconnect_ms = (reconnect_ms * 2).min(8_000);
                continue;
            }
        };
        reconnect_ms = 250;
        info!(%url, "action/info WebSocket connected");
        let (mut write, mut read) = socket.split();
        let mut pending: HashMap<
            u64,
            oneshot::Sender<std::result::Result<Value, String>>,
        > = HashMap::new();
        let mut ping = tokio::time::interval(Duration::from_secs(30));
        ping.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        let disconnect_reason = loop {
            tokio::select! {
                maybe_command = rx.recv() => {
                    let Some(command) = maybe_command else { return };
                    if pending.len() >= max_pending {
                        let _ = command.reply.send(Err("too many pending Hyperliquid actions".to_owned()));
                        continue;
                    }
                    let id = ids.fetch_add(1, Ordering::Relaxed);
                    let request = json!({
                        "method": "post",
                        "id": id,
                        "request": {
                            "type": command.request_type,
                            "payload": command.payload,
                        }
                    });
                    if let Err(error) = write.send(Message::Text(request.to_string().into())).await {
                        let _ = command.reply.send(Err(error.to_string()));
                        break format!("send failed: {error}");
                    }
                    metrics.action_requests.fetch_add(1, Ordering::Relaxed);
                    pending.insert(id, command.reply);
                }
                incoming = read.next() => {
                    let Some(incoming) = incoming else { break "stream ended".to_owned() };
                    match incoming {
                        Ok(Message::Text(text)) => {
                            let Ok(root) = serde_json::from_str::<Value>(text.as_ref()) else { continue };
                            let id = root.pointer("/data/id")
                                .or_else(|| root.get("id"))
                                .and_then(Value::as_u64);
                            if let Some(id) = id {
                                if let Some(reply) = pending.remove(&id) {
                                    let response = root.pointer("/data/response")
                                        .cloned()
                                        .or_else(|| root.get("response").cloned())
                                        .unwrap_or(root);
                                    let _ = reply.send(Ok(response));
                                }
                            }
                        }
                        Ok(Message::Ping(payload)) => {
                            if let Err(error) = write.send(Message::Pong(payload)).await {
                                break format!("pong failed: {error}");
                            }
                        }
                        Ok(Message::Close(frame)) => break format!("server close: {frame:?}"),
                        Ok(_) => {}
                        Err(error) => break error.to_string(),
                    }
                }
                _ = ping.tick() => {
                    let payload = json!({"method": "ping"});
                    if let Err(error) = write.send(Message::Text(payload.to_string().into())).await {
                        break format!("ping failed: {error}");
                    }
                }
                changed = shutdown.changed() => {
                    if changed.is_err() || *shutdown.borrow() {
                        let _ = write.send(Message::Close(None)).await;
                        for (_, reply) in pending.drain() {
                            let _ = reply.send(Err("shutdown".to_owned()));
                        }
                        return;
                    }
                }
            }
        };
        warn!(reason = %disconnect_reason, "action/info WebSocket disconnected");
        metrics.ws_reconnects.fetch_add(1, Ordering::Relaxed);
        for (_, reply) in pending.drain() {
            let _ = reply.send(Err(disconnect_reason.clone()));
        }
    }
}
