use serde::Serialize;
use std::sync::atomic::{AtomicI64, AtomicU64, Ordering};

#[derive(Debug, Default)]
pub struct Metrics {
    pub market_messages: AtomicU64,
    pub bbo_updates: AtomicU64,
    pub invalid_bbo: AtomicU64,
    pub coalesced_market_signals: AtomicU64,
    pub dropped_market_probes: AtomicU64,
    pub trade_messages: AtomicU64,
    pub dropped_trades: AtomicU64,
    pub ring_backpressure_events: AtomicU64,
    pub hot_iterations: AtomicU64,
    pub quote_updates: AtomicU64,
    pub stale_market_events: AtomicU64,
    pub fills: AtomicU64,
    pub action_requests: AtomicU64,
    pub action_rejections: AtomicU64,
    pub ws_reconnects: AtomicU64,
    pub snapshot_reloads: AtomicU64,
    pub snapshot_errors: AtomicU64,
    pub inventory_lots: AtomicI64,
    pub last_hot_latency_ns: AtomicU64,
    pub max_hot_latency_ns: AtomicU64,
}

#[derive(Debug, Serialize)]
pub struct MetricsSnapshot {
    pub market_messages: u64,
    pub bbo_updates: u64,
    pub invalid_bbo: u64,
    pub coalesced_market_signals: u64,
    pub dropped_market_probes: u64,
    pub trade_messages: u64,
    pub dropped_trades: u64,
    pub ring_backpressure_events: u64,
    pub hot_iterations: u64,
    pub quote_updates: u64,
    pub stale_market_events: u64,
    pub fills: u64,
    pub action_requests: u64,
    pub action_rejections: u64,
    pub ws_reconnects: u64,
    pub snapshot_reloads: u64,
    pub snapshot_errors: u64,
    pub inventory_lots: i64,
    pub last_hot_latency_ns: u64,
    pub max_hot_latency_ns: u64,
}

impl Metrics {
    #[inline]
    pub fn observe_hot_latency(&self, latency_ns: u64) {
        self.last_hot_latency_ns.store(latency_ns, Ordering::Relaxed);
        let mut current = self.max_hot_latency_ns.load(Ordering::Relaxed);
        while latency_ns > current {
            match self.max_hot_latency_ns.compare_exchange_weak(
                current,
                latency_ns,
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(next) => current = next,
            }
        }
    }

    pub fn snapshot(&self) -> MetricsSnapshot {
        MetricsSnapshot {
            market_messages: self.market_messages.load(Ordering::Relaxed),
            bbo_updates: self.bbo_updates.load(Ordering::Relaxed),
            invalid_bbo: self.invalid_bbo.load(Ordering::Relaxed),
            coalesced_market_signals: self.coalesced_market_signals.load(Ordering::Relaxed),
            dropped_market_probes: self.dropped_market_probes.load(Ordering::Relaxed),
            trade_messages: self.trade_messages.load(Ordering::Relaxed),
            dropped_trades: self.dropped_trades.load(Ordering::Relaxed),
            ring_backpressure_events: self
                .ring_backpressure_events
                .load(Ordering::Relaxed),
            hot_iterations: self.hot_iterations.load(Ordering::Relaxed),
            quote_updates: self.quote_updates.load(Ordering::Relaxed),
            stale_market_events: self.stale_market_events.load(Ordering::Relaxed),
            fills: self.fills.load(Ordering::Relaxed),
            action_requests: self.action_requests.load(Ordering::Relaxed),
            action_rejections: self.action_rejections.load(Ordering::Relaxed),
            ws_reconnects: self.ws_reconnects.load(Ordering::Relaxed),
            snapshot_reloads: self.snapshot_reloads.load(Ordering::Relaxed),
            snapshot_errors: self.snapshot_errors.load(Ordering::Relaxed),
            inventory_lots: self.inventory_lots.load(Ordering::Relaxed),
            last_hot_latency_ns: self.last_hot_latency_ns.load(Ordering::Relaxed),
            max_hot_latency_ns: self.max_hot_latency_ns.load(Ordering::Relaxed),
        }
    }
}
