use anyhow::{Context, Result};
use arc_swap::ArcSwap;
use clap::Parser;
use mm_live::cold_path::{
    log_metrics, persist_hot_state, restore_inventory, watch_strategy_snapshot,
};
use mm_live::config::{AppConfig, LogFormat, RunMode};
use mm_live::execution::dry_run::{run_dry_run, DryRunLoopArgs};
use mm_live::execution::live::{run_live, LiveLoopArgs, LiveOrderManager};
use mm_live::hot_path::{spawn_hot_path, HotPathInputs};
use mm_live::hyperliquid::market::{run_market_stream, MarketStreamArgs};
use mm_live::hyperliquid::private::{
    run_position_sync, run_private_stream, PrivateStreamArgs,
};
use mm_live::hyperliquid::rpc::WsRpcClient;
use mm_live::hyperliquid::signing::ActionSigner;
use mm_live::lockfree::{
    AsyncRing, HotEventRing, HotPathSignal, SharedQuotes, HOT_SIGNAL_SHUTDOWN,
};
use mm_live::metrics::Metrics;
use mm_live::model::StrategySnapshot;
use mm_live::types::{
    unix_ms, AtomicBbo, AtomicHotStateSnapshot, BackendEvent, HotStateSnapshot, MarketProbe,
    ProcessClock,
};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::watch;
use tracing::{info, warn};
use tracing_subscriber::EnvFilter;

#[derive(Debug, Parser)]
#[command(name = "mm-live", version, about = "Rust live/dry-run market-making engine")]
struct Cli {
    #[arg(long, default_value = "config/live.toml")]
    config: PathBuf,
    /// Mandatory second factor when runtime.mode=live.
    #[arg(long)]
    enable_live: bool,
    /// Parse and validate all files, then exit without opening a socket.
    #[arg(long)]
    validate_only: bool,
}

#[tokio::main(flavor = "multi_thread")]
async fn main() -> Result<()> {
    let cli = Cli::parse();
    let config = AppConfig::load(&cli.config)?;
    init_tracing(config.telemetry.log_format);
    let snapshot = StrategySnapshot::load(&config.runtime.snapshot_path)?;
    config.enforce_live_guards(cli.enable_live)?;
    if cli.validate_only {
        info!(
            mode = ?config.runtime.mode,
            network = ?config.runtime.network,
            coin = %config.runtime.coin,
            snapshot_revision = snapshot.revision,
            "configuration is valid"
        );
        return Ok(());
    }

    let metrics = Arc::new(Metrics::default());
    let clock = Arc::new(ProcessClock::default());
    let latest_bbo = Arc::new(AtomicBbo::default());
    let strategy = Arc::new(ArcSwap::from_pointee(snapshot));
    let desired = Arc::new(SharedQuotes::default());
    let hot_state = Arc::new(AtomicHotStateSnapshot::default());
    let hot_signal = Arc::new(HotPathSignal::default());
    let hot_events = Arc::new(HotEventRing::new(
        config.runtime.hot_event_ring_capacity,
        hot_signal.clone(),
    ));
    let probe_ring = matches!(config.runtime.mode, RunMode::DryRun).then(|| {
        Arc::new(AsyncRing::<MarketProbe>::new(
            config.runtime.market_probe_ring_capacity,
        ))
    });

    let (shutdown_tx, shutdown_rx) = watch::channel(false);

    let initial_inventory = match config.runtime.mode {
        RunMode::DryRun => restore_inventory(
            &config.runtime.state_path,
            config.runtime.initial_inventory_lots,
        ),
        RunMode::Live => config.runtime.initial_inventory_lots,
    };
    hot_state.store(HotStateSnapshot {
        inventory_lots: initial_inventory,
        updated_unix_ms: unix_ms(),
        ..HotStateSnapshot::default()
    });

    let hot_thread = spawn_hot_path(HotPathInputs {
        latest_bbo: latest_bbo.clone(),
        events: hot_events.clone(),
        signal: hot_signal.clone(),
        desired: desired.clone(),
        state: hot_state.clone(),
        snapshot: strategy.clone(),
        market: config.market.clone(),
        clock: clock.clone(),
        metrics: metrics.clone(),
        initial_inventory_lots: initial_inventory,
        // Both backends explicitly publish Connected into the priority ring.
        initial_backend_ready: false,
        // Live mode requires both private connectivity and an authoritative
        // position snapshot before any order-bearing quote can be published.
        require_position_sync: matches!(config.runtime.mode, RunMode::Live),
        hot_path_cpu: config.runtime.hot_path_cpu,
    })
    .context("cannot start dedicated hot-path thread")?;

    let mut tasks = Vec::new();
    tasks.push(tokio::spawn(watch_strategy_snapshot(
        config.runtime.snapshot_path.clone(),
        config.telemetry.snapshot_poll_ms,
        strategy,
        hot_signal.clone(),
        metrics.clone(),
        shutdown_rx.clone(),
    )));
    tasks.push(tokio::spawn(persist_hot_state(
        config.runtime.state_path.clone(),
        config.telemetry.state_flush_ms,
        hot_state,
        shutdown_rx.clone(),
    )));
    tasks.push(tokio::spawn(log_metrics(
        config.telemetry.stats_interval_ms,
        metrics.clone(),
        shutdown_rx.clone(),
    )));
    tasks.push(tokio::spawn(run_market_stream(MarketStreamArgs {
        coin: config.runtime.coin.clone(),
        network: config.runtime.network,
        config: config.market.clone(),
        latest_bbo: latest_bbo.clone(),
        hot_signal: hot_signal.clone(),
        probe_ring: probe_ring.clone(),
        clock,
        metrics: metrics.clone(),
        shutdown: shutdown_rx.clone(),
    })));

    match config.runtime.mode {
        RunMode::DryRun => {
            tasks.push(tokio::spawn(run_dry_run(DryRunLoopArgs {
                config: config.dry_run.clone(),
                market: config.market.clone(),
                latest_bbo,
                desired,
                probe_ring: probe_ring.expect("dry-run probe ring must exist"),
                hot_events,
                metrics: metrics.clone(),
                shutdown: shutdown_rx.clone(),
            })));
        }
        RunMode::Live => {
            let private_key = std::env::var(&config.runtime.private_key_env)
                .with_context(|| format!("{} not set", config.runtime.private_key_env))?;
            let signer = Arc::new(ActionSigner::new(
                private_key.trim(),
                config.runtime.network.is_mainnet(),
                config.execution.vault_address.as_deref(),
            )?);
            let user = config
                .runtime
                .wallet_address
                .clone()
                .filter(|address| !address.trim().is_empty())
                .unwrap_or_else(|| signer.signer_address())
                .to_lowercase();
            let ws_url = config.market.effective_ws_url(config.runtime.network);
            let rpc = WsRpcClient::spawn(
                ws_url.clone(),
                config.execution.max_pending_actions,
                Duration::from_millis(config.execution.action_timeout_ms),
                metrics.clone(),
                shutdown_rx.clone(),
            );
            let private_events = Arc::new(AsyncRing::<BackendEvent>::new(
                config.runtime.private_event_ring_capacity,
            ));
            tasks.push(tokio::spawn(run_private_stream(PrivateStreamArgs {
                network: config.runtime.network,
                ws_url: Some(ws_url),
                user: user.clone(),
                coin: config.runtime.coin.clone(),
                market: config.market.clone(),
                event_ring: private_events.clone(),
                metrics: metrics.clone(),
                shutdown: shutdown_rx.clone(),
            })));
            tasks.push(tokio::spawn(run_position_sync(
                rpc.clone(),
                user.clone(),
                config.runtime.coin.clone(),
                config.market.clone(),
                config.execution.private_position_sync_ms,
                private_events.clone(),
                metrics.clone(),
                shutdown_rx.clone(),
            )));
            let manager = LiveOrderManager::new(
                config.runtime.coin.clone(),
                user,
                config.execution.asset_id.expect("validated live asset_id"),
                config.market.clone(),
                config.execution.clone(),
                signer,
                rpc,
            );
            tasks.push(tokio::spawn(run_live(LiveLoopArgs {
                manager,
                desired,
                private_events,
                hot_events,
                metrics: metrics.clone(),
                shutdown: shutdown_rx.clone(),
            })));
        }
    }

    info!(
        mode = ?config.runtime.mode,
        network = ?config.runtime.network,
        coin = %config.runtime.coin,
        hot_path_cpu = ?config.runtime.hot_path_cpu,
        market_probe_ring_capacity = config.runtime.market_probe_ring_capacity,
        private_event_ring_capacity = config.runtime.private_event_ring_capacity,
        hot_event_ring_capacity = config.runtime.hot_event_ring_capacity,
        "mm-live started"
    );
    wait_for_shutdown_signal().await?;
    info!("shutdown requested");
    hot_signal.notify(HOT_SIGNAL_SHUTDOWN);
    let _ = shutdown_tx.send(true);

    for task in tasks {
        match tokio::time::timeout(Duration::from_secs(8), task).await {
            Ok(Ok(())) => {}
            Ok(Err(error)) => warn!(%error, "runtime task failed during shutdown"),
            Err(_) => warn!("runtime task did not stop before timeout"),
        }
    }
    match tokio::task::spawn_blocking(move || hot_thread.join()).await {
        Ok(Ok(())) => {}
        Ok(Err(_)) => warn!("hot-path thread panicked"),
        Err(error) => warn!(%error, "cannot join hot-path thread"),
    }
    info!("mm-live stopped");
    Ok(())
}

fn init_tracing(format: LogFormat) {
    let filter = EnvFilter::try_from_default_env()
        .unwrap_or_else(|_| EnvFilter::new("mm_live=info,mm_live::hyperliquid=info"));
    match format {
        LogFormat::Pretty => tracing_subscriber::fmt().with_env_filter(filter).init(),
        LogFormat::Json => tracing_subscriber::fmt()
            .json()
            .with_env_filter(filter)
            .init(),
    }
}

async fn wait_for_shutdown_signal() -> Result<()> {
    #[cfg(unix)]
    {
        use tokio::signal::unix::{signal, SignalKind};
        let mut terminate = signal(SignalKind::terminate())?;
        tokio::select! {
            result = tokio::signal::ctrl_c() => result?,
            _ = terminate.recv() => {},
        }
    }
    #[cfg(not(unix))]
    tokio::signal::ctrl_c().await?;
    Ok(())
}
