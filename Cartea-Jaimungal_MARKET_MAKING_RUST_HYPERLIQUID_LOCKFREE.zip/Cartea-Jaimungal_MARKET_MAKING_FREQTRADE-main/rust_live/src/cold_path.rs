use crate::lockfree::{HotPathSignal, HOT_SIGNAL_MODEL};
use crate::metrics::Metrics;
use crate::model::StrategySnapshot;
use crate::types::{AtomicHotStateSnapshot, HotStateSnapshot};
use arc_swap::ArcSwap;
use std::path::{Path, PathBuf};
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::{Duration, SystemTime};
use tokio::sync::watch;
use tracing::{info, warn};

pub async fn watch_strategy_snapshot(
    path: PathBuf,
    poll_ms: u64,
    snapshot: Arc<ArcSwap<StrategySnapshot>>,
    hot_signal: Arc<HotPathSignal>,
    metrics: Arc<Metrics>,
    mut shutdown: watch::Receiver<bool>,
) {
    let mut last_modified: Option<SystemTime> = None;
    let mut interval = tokio::time::interval(Duration::from_millis(poll_ms.max(100)));
    interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    loop {
        tokio::select! {
            _ = interval.tick() => {
                let modified = std::fs::metadata(&path).and_then(|m| m.modified()).ok();
                if modified.is_some() && modified != last_modified {
                    match StrategySnapshot::load(&path) {
                        Ok(next) => {
                            let previous_revision = snapshot.load().revision;
                            if next.revision >= previous_revision {
                                let revision = next.revision;
                                snapshot.store(Arc::new(next));
                                last_modified = modified;
                                metrics.snapshot_reloads.fetch_add(1, Ordering::Relaxed);
                                hot_signal.notify(HOT_SIGNAL_MODEL);
                                info!(revision, path = %path.display(), "strategy snapshot reloaded");
                            } else {
                                metrics.snapshot_errors.fetch_add(1, Ordering::Relaxed);
                                warn!(revision = next.revision, previous_revision, "ignored stale strategy snapshot");
                            }
                        }
                        Err(error) => {
                            metrics.snapshot_errors.fetch_add(1, Ordering::Relaxed);
                            warn!(%error, path = %path.display(), "invalid strategy snapshot; keeping last good version");
                        }
                    }
                }
            }
            changed = shutdown.changed() => {
                if changed.is_err() || *shutdown.borrow() { break; }
            }
        }
    }
}

pub async fn persist_hot_state(
    path: PathBuf,
    flush_ms: u64,
    state: Arc<AtomicHotStateSnapshot>,
    mut shutdown: watch::Receiver<bool>,
) {
    let mut interval = tokio::time::interval(Duration::from_millis(flush_ms.max(250)));
    interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    loop {
        tokio::select! {
            _ = interval.tick() => {
                let snapshot = state.load();
                if let Err(error) = write_json_atomic(&path, &snapshot) {
                    warn!(%error, path = %path.display(), "cannot persist live state");
                }
            }
            changed = shutdown.changed() => {
                if changed.is_err() || *shutdown.borrow() {
                    let snapshot = state.load();
                    if let Err(error) = write_json_atomic(&path, &snapshot) {
                        warn!(%error, path = %path.display(), "cannot persist final live state");
                    }
                    break;
                }
            }
        }
    }
}

fn write_json_atomic<T: serde::Serialize>(path: &Path, value: &T) -> anyhow::Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let tmp = path.with_extension("tmp");
    let bytes = serde_json::to_vec_pretty(value)?;
    std::fs::write(&tmp, bytes)?;
    std::fs::rename(&tmp, path)?;
    Ok(())
}

pub async fn log_metrics(
    interval_ms: u64,
    metrics: Arc<Metrics>,
    mut shutdown: watch::Receiver<bool>,
) {
    let mut interval = tokio::time::interval(Duration::from_millis(interval_ms.max(250)));
    interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    loop {
        tokio::select! {
            _ = interval.tick() => {
                let snapshot = metrics.snapshot();
                info!(
                    inventory_lots = snapshot.inventory_lots,
                    bbo_updates = snapshot.bbo_updates,
                    quote_updates = snapshot.quote_updates,
                    fills = snapshot.fills,
                    action_requests = snapshot.action_requests,
                    action_rejections = snapshot.action_rejections,
                    ws_reconnects = snapshot.ws_reconnects,
                    hot_latency_ns = snapshot.last_hot_latency_ns,
                    max_hot_latency_ns = snapshot.max_hot_latency_ns,
                    coalesced_market_signals = snapshot.coalesced_market_signals,
                    dropped_market_probes = snapshot.dropped_market_probes,
                    dropped_trades = snapshot.dropped_trades,
                    ring_backpressure_events = snapshot.ring_backpressure_events,
                    "runtime statistics"
                );
            }
            changed = shutdown.changed() => {
                if changed.is_err() || *shutdown.borrow() { break; }
            }
        }
    }
}

pub fn restore_inventory(path: &Path, fallback: i64) -> i64 {
    let Ok(raw) = std::fs::read_to_string(path) else {
        return fallback;
    };
    serde_json::from_str::<HotStateSnapshot>(&raw)
        .map(|state| state.inventory_lots)
        .unwrap_or(fallback)
}
