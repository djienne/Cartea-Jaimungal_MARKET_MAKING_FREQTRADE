use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicBool, AtomicI64, AtomicU64, AtomicU8, Ordering};
use std::time::Instant;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[repr(u8)]
#[serde(rename_all = "snake_case")]
pub enum Side {
    Buy,
    Sell,
}

impl Side {
    #[inline]
    pub const fn inventory_sign(self) -> i64 {
        match self {
            Self::Buy => 1,
            Self::Sell => -1,
        }
    }

    #[inline]
    pub const fn from_u8(value: u8) -> Self {
        match value {
            1 => Self::Sell,
            _ => Self::Buy,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TakerSide {
    Buy,
    Sell,
}

#[derive(Debug, Clone, Copy, Default, Serialize, Deserialize)]
pub struct Bbo {
    pub bid_px: i64,
    pub bid_sz: i64,
    pub ask_px: i64,
    pub ask_sz: i64,
    pub exchange_ms: u64,
    pub recv_ns: u64,
}

impl Bbo {
    #[inline]
    pub const fn is_valid(self) -> bool {
        self.bid_px > 0 && self.ask_px > self.bid_px && self.bid_sz >= 0 && self.ask_sz >= 0
    }

    #[inline]
    pub const fn mid_units(self) -> i64 {
        self.bid_px + ((self.ask_px - self.bid_px) / 2)
    }
}

/// Single-writer, multi-reader seqlock for the latest BBO. The networking task
/// may overwrite market data under pressure; the hot path always reads a
/// coherent latest snapshot without taking a mutex.
#[derive(Debug, Default)]
#[repr(align(64))]
pub struct AtomicBbo {
    seq: AtomicU64,
    valid: AtomicBool,
    bid_px: AtomicI64,
    bid_sz: AtomicI64,
    ask_px: AtomicI64,
    ask_sz: AtomicI64,
    exchange_ms: AtomicU64,
    recv_ns: AtomicU64,
}

impl AtomicBbo {
    #[inline]
    pub fn store(&self, bbo: Bbo) {
        self.seq.fetch_add(1, Ordering::AcqRel); // odd: write in progress
        self.bid_px.store(bbo.bid_px, Ordering::Relaxed);
        self.bid_sz.store(bbo.bid_sz, Ordering::Relaxed);
        self.ask_px.store(bbo.ask_px, Ordering::Relaxed);
        self.ask_sz.store(bbo.ask_sz, Ordering::Relaxed);
        self.exchange_ms.store(bbo.exchange_ms, Ordering::Relaxed);
        self.recv_ns.store(bbo.recv_ns, Ordering::Relaxed);
        self.valid.store(bbo.is_valid(), Ordering::Relaxed);
        self.seq.fetch_add(1, Ordering::Release); // even: stable
    }

    #[inline]
    pub fn load(&self) -> Option<Bbo> {
        loop {
            let before = self.seq.load(Ordering::Acquire);
            if before & 1 == 1 {
                std::hint::spin_loop();
                continue;
            }
            let valid = self.valid.load(Ordering::Relaxed);
            let value = Bbo {
                bid_px: self.bid_px.load(Ordering::Relaxed),
                bid_sz: self.bid_sz.load(Ordering::Relaxed),
                ask_px: self.ask_px.load(Ordering::Relaxed),
                ask_sz: self.ask_sz.load(Ordering::Relaxed),
                exchange_ms: self.exchange_ms.load(Ordering::Relaxed),
                recv_ns: self.recv_ns.load(Ordering::Relaxed),
            };
            let after = self.seq.load(Ordering::Acquire);
            if before == after && before & 1 == 0 {
                return valid.then_some(value);
            }
            std::hint::spin_loop();
        }
    }
}

#[derive(Debug, Clone)]
pub struct ProcessClock {
    origin: Instant,
}

impl Default for ProcessClock {
    fn default() -> Self {
        Self {
            origin: Instant::now(),
        }
    }
}

impl ProcessClock {
    #[inline]
    pub fn now_ns(&self) -> u64 {
        self.origin.elapsed().as_nanos().min(u64::MAX as u128) as u64
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct DesiredOrder {
    pub side: Side,
    /// Price in configured integer price units.
    pub px: i64,
    /// Quantity in configured integer lots (one lot = `size_step_units`).
    pub qty_lots: i64,
    pub reduce_only: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct DesiredQuotes {
    pub bid: Option<DesiredOrder>,
    pub ask: Option<DesiredOrder>,
    pub quote_seq: u64,
    pub model_revision: u64,
    pub generated_ns: u64,
    pub reason: QuoteReason,
}

impl DesiredQuotes {
    pub const fn empty(reason: QuoteReason, quote_seq: u64, generated_ns: u64) -> Self {
        Self {
            bid: None,
            ask: None,
            quote_seq,
            model_revision: 0,
            generated_ns,
            reason,
        }
    }
}

impl Default for DesiredQuotes {
    fn default() -> Self {
        Self::empty(QuoteReason::Startup, 0, 0)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[repr(u8)]
#[serde(rename_all = "snake_case")]
pub enum QuoteReason {
    Startup,
    Market,
    Fill,
    PositionSync,
    ModelReload,
    StaleMarket,
    RiskLimit,
    BackendDown,
    Shutdown,
}

impl QuoteReason {
    #[inline]
    pub const fn from_u8(value: u8) -> Self {
        match value {
            1 => Self::Market,
            2 => Self::Fill,
            3 => Self::PositionSync,
            4 => Self::ModelReload,
            5 => Self::StaleMarket,
            6 => Self::RiskLimit,
            7 => Self::BackendDown,
            8 => Self::Shutdown,
            _ => Self::Startup,
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct Trade {
    pub taker_side: TakerSide,
    pub px: i64,
    pub qty_units: i64,
    pub exchange_ms: u64,
    pub recv_ns: u64,
}

#[derive(Debug, Clone, Copy)]
pub enum MarketProbe {
    Bbo(Bbo),
    Trade(Trade),
}

#[derive(Debug, Clone, Copy)]
pub struct Fill {
    pub side: Side,
    pub px: i64,
    pub qty_lots: i64,
    pub fee_quote_units: i64,
    pub exchange_ms: u64,
    pub oid: Option<u64>,
    pub cloid_hash: u128,
}

#[derive(Debug, Clone)]
pub struct OrderUpdate {
    pub side: Side,
    pub oid: Option<u64>,
    pub cloid: Option<String>,
    pub status: OrderStatus,
    pub px: Option<i64>,
    pub qty_lots: Option<i64>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OrderStatus {
    Open,
    Filled,
    Canceled,
    Rejected,
    Unknown,
}

#[derive(Debug, Clone)]
pub enum BackendEvent {
    Fill(Fill),
    PositionSnapshot { inventory_lots: i64 },
    OrderUpdate(OrderUpdate),
    Connected,
    Disconnected { reason: String },
}

/// Fixed-size subset of backend events consumed by the hot path. Strings and
/// order-management details remain in the cold execution path.
#[derive(Debug, Clone, Copy)]
pub enum HotEvent {
    Fill(Fill),
    PositionSnapshot { inventory_lots: i64 },
    Connected,
    Disconnected,
    ActionRejected,
}

impl BackendEvent {
    #[inline]
    pub fn to_hot_event(&self) -> Option<HotEvent> {
        match self {
            Self::Fill(fill) => Some(HotEvent::Fill(*fill)),
            Self::PositionSnapshot { inventory_lots } => Some(HotEvent::PositionSnapshot {
                inventory_lots: *inventory_lots,
            }),
            Self::Connected => Some(HotEvent::Connected),
            Self::Disconnected { .. } => Some(HotEvent::Disconnected),
            Self::OrderUpdate(_) => None,
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub enum ExecutionControl {
    CancelAll,
    Shutdown,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct HotStateSnapshot {
    pub inventory_lots: i64,
    pub last_bid_px: i64,
    pub last_ask_px: i64,
    pub quote_seq: u64,
    pub model_revision: u64,
    pub updated_unix_ms: u64,
}

impl Default for HotStateSnapshot {
    fn default() -> Self {
        Self {
            inventory_lots: 0,
            last_bid_px: 0,
            last_ask_px: 0,
            quote_seq: 0,
            model_revision: 0,
            updated_unix_ms: 0,
        }
    }
}


#[derive(Debug)]
#[repr(align(64))]
pub struct AtomicDesiredQuotes {
    seq: AtomicU64,
    bid_valid: AtomicBool,
    bid_side: AtomicU8,
    bid_px: AtomicI64,
    bid_qty_lots: AtomicI64,
    bid_reduce_only: AtomicBool,
    ask_valid: AtomicBool,
    ask_side: AtomicU8,
    ask_px: AtomicI64,
    ask_qty_lots: AtomicI64,
    ask_reduce_only: AtomicBool,
    quote_seq: AtomicU64,
    model_revision: AtomicU64,
    generated_ns: AtomicU64,
    reason: AtomicU8,
}

impl Default for AtomicDesiredQuotes {
    fn default() -> Self {
        let value = Self {
            seq: AtomicU64::new(0),
            bid_valid: AtomicBool::new(false),
            bid_side: AtomicU8::new(Side::Buy as u8),
            bid_px: AtomicI64::new(0),
            bid_qty_lots: AtomicI64::new(0),
            bid_reduce_only: AtomicBool::new(false),
            ask_valid: AtomicBool::new(false),
            ask_side: AtomicU8::new(Side::Sell as u8),
            ask_px: AtomicI64::new(0),
            ask_qty_lots: AtomicI64::new(0),
            ask_reduce_only: AtomicBool::new(false),
            quote_seq: AtomicU64::new(0),
            model_revision: AtomicU64::new(0),
            generated_ns: AtomicU64::new(0),
            reason: AtomicU8::new(QuoteReason::Startup as u8),
        };
        value.store(DesiredQuotes::default());
        value
    }
}

impl AtomicDesiredQuotes {
    #[inline]
    pub fn store(&self, quotes: DesiredQuotes) {
        self.seq.fetch_add(1, Ordering::AcqRel);
        store_desired_order(
            &self.bid_valid,
            &self.bid_side,
            &self.bid_px,
            &self.bid_qty_lots,
            &self.bid_reduce_only,
            quotes.bid,
        );
        store_desired_order(
            &self.ask_valid,
            &self.ask_side,
            &self.ask_px,
            &self.ask_qty_lots,
            &self.ask_reduce_only,
            quotes.ask,
        );
        self.quote_seq.store(quotes.quote_seq, Ordering::Relaxed);
        self.model_revision
            .store(quotes.model_revision, Ordering::Relaxed);
        self.generated_ns
            .store(quotes.generated_ns, Ordering::Relaxed);
        self.reason.store(quotes.reason as u8, Ordering::Relaxed);
        self.seq.fetch_add(1, Ordering::Release);
    }

    #[inline]
    pub fn load(&self) -> DesiredQuotes {
        loop {
            let before = self.seq.load(Ordering::Acquire);
            if before & 1 == 1 {
                std::hint::spin_loop();
                continue;
            }

            let value = DesiredQuotes {
                bid: load_desired_order(
                    &self.bid_valid,
                    &self.bid_side,
                    &self.bid_px,
                    &self.bid_qty_lots,
                    &self.bid_reduce_only,
                ),
                ask: load_desired_order(
                    &self.ask_valid,
                    &self.ask_side,
                    &self.ask_px,
                    &self.ask_qty_lots,
                    &self.ask_reduce_only,
                ),
                quote_seq: self.quote_seq.load(Ordering::Relaxed),
                model_revision: self.model_revision.load(Ordering::Relaxed),
                generated_ns: self.generated_ns.load(Ordering::Relaxed),
                reason: QuoteReason::from_u8(self.reason.load(Ordering::Relaxed)),
            };

            let after = self.seq.load(Ordering::Acquire);
            if before == after && before & 1 == 0 {
                return value;
            }
            std::hint::spin_loop();
        }
    }
}

#[inline]
fn store_desired_order(
    valid: &AtomicBool,
    side: &AtomicU8,
    px: &AtomicI64,
    qty_lots: &AtomicI64,
    reduce_only: &AtomicBool,
    order: Option<DesiredOrder>,
) {
    if let Some(order) = order {
        side.store(order.side as u8, Ordering::Relaxed);
        px.store(order.px, Ordering::Relaxed);
        qty_lots.store(order.qty_lots, Ordering::Relaxed);
        reduce_only.store(order.reduce_only, Ordering::Relaxed);
        valid.store(true, Ordering::Relaxed);
    } else {
        valid.store(false, Ordering::Relaxed);
    }
}

#[inline]
fn load_desired_order(
    valid: &AtomicBool,
    side: &AtomicU8,
    px: &AtomicI64,
    qty_lots: &AtomicI64,
    reduce_only: &AtomicBool,
) -> Option<DesiredOrder> {
    valid.load(Ordering::Relaxed).then(|| DesiredOrder {
        side: Side::from_u8(side.load(Ordering::Relaxed)),
        px: px.load(Ordering::Relaxed),
        qty_lots: qty_lots.load(Ordering::Relaxed),
        reduce_only: reduce_only.load(Ordering::Relaxed),
    })
}

#[derive(Debug)]
#[repr(align(64))]
pub struct AtomicHotStateSnapshot {
    seq: AtomicU64,
    inventory_lots: AtomicI64,
    last_bid_px: AtomicI64,
    last_ask_px: AtomicI64,
    quote_seq: AtomicU64,
    model_revision: AtomicU64,
    updated_unix_ms: AtomicU64,
}

impl Default for AtomicHotStateSnapshot {
    fn default() -> Self {
        Self {
            seq: AtomicU64::new(0),
            inventory_lots: AtomicI64::new(0),
            last_bid_px: AtomicI64::new(0),
            last_ask_px: AtomicI64::new(0),
            quote_seq: AtomicU64::new(0),
            model_revision: AtomicU64::new(0),
            updated_unix_ms: AtomicU64::new(0),
        }
    }
}

impl AtomicHotStateSnapshot {
    #[inline]
    pub fn store(&self, state: HotStateSnapshot) {
        self.seq.fetch_add(1, Ordering::AcqRel);
        self.inventory_lots
            .store(state.inventory_lots, Ordering::Relaxed);
        self.last_bid_px
            .store(state.last_bid_px, Ordering::Relaxed);
        self.last_ask_px
            .store(state.last_ask_px, Ordering::Relaxed);
        self.quote_seq.store(state.quote_seq, Ordering::Relaxed);
        self.model_revision
            .store(state.model_revision, Ordering::Relaxed);
        self.updated_unix_ms
            .store(state.updated_unix_ms, Ordering::Relaxed);
        self.seq.fetch_add(1, Ordering::Release);
    }

    #[inline]
    pub fn load(&self) -> HotStateSnapshot {
        loop {
            let before = self.seq.load(Ordering::Acquire);
            if before & 1 == 1 {
                std::hint::spin_loop();
                continue;
            }
            let value = HotStateSnapshot {
                inventory_lots: self.inventory_lots.load(Ordering::Relaxed),
                last_bid_px: self.last_bid_px.load(Ordering::Relaxed),
                last_ask_px: self.last_ask_px.load(Ordering::Relaxed),
                quote_seq: self.quote_seq.load(Ordering::Relaxed),
                model_revision: self.model_revision.load(Ordering::Relaxed),
                updated_unix_ms: self.updated_unix_ms.load(Ordering::Relaxed),
            };
            let after = self.seq.load(Ordering::Acquire);
            if before == after && before & 1 == 0 {
                return value;
            }
            std::hint::spin_loop();
        }
    }
}

pub fn unix_ms() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
        .min(u64::MAX as u128) as u64
}


#[cfg(test)]
mod atomic_tests {
    use super::*;

    #[test]
    fn desired_quotes_atomic_round_trip() {
        let shared = AtomicDesiredQuotes::default();
        let expected = DesiredQuotes {
            bid: Some(DesiredOrder {
                side: Side::Buy,
                px: 123,
                qty_lots: 4,
                reduce_only: false,
            }),
            ask: Some(DesiredOrder {
                side: Side::Sell,
                px: 127,
                qty_lots: 5,
                reduce_only: true,
            }),
            quote_seq: 9,
            model_revision: 3,
            generated_ns: 77,
            reason: QuoteReason::Fill,
        };
        shared.store(expected);
        assert_eq!(shared.load(), expected);
    }

    #[test]
    fn hot_state_atomic_round_trip() {
        let shared = AtomicHotStateSnapshot::default();
        let expected = HotStateSnapshot {
            inventory_lots: -12,
            last_bid_px: 99,
            last_ask_px: 101,
            quote_seq: 8,
            model_revision: 2,
            updated_unix_ms: 1234,
        };
        shared.store(expected);
        assert_eq!(shared.load().inventory_lots, expected.inventory_lots);
        assert_eq!(shared.load().quote_seq, expected.quote_seq);
    }
}
