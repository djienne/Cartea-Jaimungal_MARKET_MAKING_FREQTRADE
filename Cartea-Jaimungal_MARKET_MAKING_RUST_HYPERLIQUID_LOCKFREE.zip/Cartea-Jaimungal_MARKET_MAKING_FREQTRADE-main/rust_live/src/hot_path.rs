use crate::config::MarketConfig;
use crate::lockfree::{
    HotEventRing, HotPathSignal, SharedQuotes, HOT_SIGNAL_EVENT, HOT_SIGNAL_MARKET,
    HOT_SIGNAL_MODEL, HOT_SIGNAL_SHUTDOWN,
};
use crate::metrics::Metrics;
use crate::model::{compute_desired_quotes, StrategySnapshot};
use crate::types::{
    unix_ms, AtomicBbo, AtomicHotStateSnapshot, DesiredQuotes, HotEvent, HotStateSnapshot,
    ProcessClock, QuoteReason,
};
use arc_swap::ArcSwap;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::thread::{self, JoinHandle};
use std::time::Duration;

pub struct HotPathInputs {
    pub latest_bbo: Arc<AtomicBbo>,
    pub events: Arc<HotEventRing>,
    pub signal: Arc<HotPathSignal>,
    pub desired: Arc<SharedQuotes>,
    pub state: Arc<AtomicHotStateSnapshot>,
    pub snapshot: Arc<ArcSwap<StrategySnapshot>>,
    pub market: MarketConfig,
    pub clock: Arc<ProcessClock>,
    pub metrics: Arc<Metrics>,
    pub initial_inventory_lots: i64,
    pub initial_backend_ready: bool,
    /// Real execution remains gated until an authoritative position snapshot
    /// has been observed in addition to the private-stream connection.
    pub require_position_sync: bool,
    pub hot_path_cpu: Option<usize>,
}

pub fn spawn_hot_path(inputs: HotPathInputs) -> std::io::Result<JoinHandle<()>> {
    thread::Builder::new()
        .name("mm-hot-path".to_owned())
        .spawn(move || run_hot_path(inputs))
}

fn pin_current_thread(cpu: Option<usize>) {
    let Some(cpu) = cpu else { return };
    let Some(cores) = core_affinity::get_core_ids() else {
        return;
    };
    if let Some(core) = cores.into_iter().find(|id| id.id == cpu) {
        let _ = core_affinity::set_for_current(core);
    }
}

fn run_hot_path(inputs: HotPathInputs) {
    pin_current_thread(inputs.hot_path_cpu);
    inputs.signal.register_current_thread();

    let mut inventory_lots = inputs.initial_inventory_lots;
    let mut private_connected = inputs.initial_backend_ready;
    let mut position_synced = !inputs.require_position_sync;
    let mut backend_ready = private_connected && position_synced;
    let mut quote_seq = 0_u64;
    let mut last_bbo = inputs.latest_bbo.load();
    let mut last_quotes = DesiredQuotes::default();
    let stale_ns = inputs.market.stale_after_ms.saturating_mul(1_000_000);
    let idle_poll = Duration::from_millis(100);

    inputs
        .metrics
        .inventory_lots
        .store(inventory_lots, Ordering::Relaxed);

    loop {
        let mut pending = inputs.signal.take_pending();
        if pending == 0 {
            inputs.signal.park_timeout(idle_poll);
            pending = inputs.signal.take_pending();
        }

        if pending & HOT_SIGNAL_SHUTDOWN != 0 {
            quote_seq = quote_seq.wrapping_add(1);
            inputs.desired.publish(DesiredQuotes::empty(
                QuoteReason::Shutdown,
                quote_seq,
                inputs.clock.now_ns(),
            ));
            break;
        }

        let mut reason = None;
        if pending & HOT_SIGNAL_MARKET != 0 {
            last_bbo = inputs.latest_bbo.load();
            reason = Some(QuoteReason::Market);
        }
        if pending & HOT_SIGNAL_MODEL != 0 {
            reason = Some(QuoteReason::ModelReload);
        }

        // Private/account events are drained as a batch and take precedence
        // over coalescible market/model notifications.
        if pending & HOT_SIGNAL_EVENT != 0 {
            while let Some(event) = inputs.events.try_pop() {
                match event {
                    HotEvent::Fill(fill) => {
                        inventory_lots = inventory_lots.saturating_add(
                            fill.side
                                .inventory_sign()
                                .saturating_mul(fill.qty_lots),
                        );
                        inputs.metrics.fills.fetch_add(1, Ordering::Relaxed);
                        inputs
                            .metrics
                            .inventory_lots
                            .store(inventory_lots, Ordering::Relaxed);
                        reason = Some(QuoteReason::Fill);
                    }
                    HotEvent::PositionSnapshot {
                        inventory_lots: next,
                    } => {
                        inventory_lots = next;
                        position_synced = true;
                        backend_ready = private_connected && position_synced;
                        inputs
                            .metrics
                            .inventory_lots
                            .store(inventory_lots, Ordering::Relaxed);
                        reason = Some(QuoteReason::PositionSync);
                    }
                    HotEvent::Disconnected => {
                        private_connected = false;
                        if inputs.require_position_sync {
                            position_synced = false;
                        }
                        backend_ready = false;
                        reason = Some(QuoteReason::BackendDown);
                    }
                    HotEvent::Connected => {
                        private_connected = true;
                        backend_ready = private_connected && position_synced;
                        reason = Some(if backend_ready {
                            QuoteReason::Market
                        } else {
                            QuoteReason::BackendDown
                        });
                    }
                    HotEvent::ActionRejected => {}
                }
            }
        }

        inputs
            .metrics
            .hot_iterations
            .fetch_add(1, Ordering::Relaxed);
        let start_ns = inputs.clock.now_ns();
        let Some(bbo) = last_bbo else {
            continue;
        };
        let age_ns = start_ns.saturating_sub(bbo.recv_ns);
        quote_seq = quote_seq.wrapping_add(1);
        let next = if !backend_ready {
            DesiredQuotes::empty(QuoteReason::BackendDown, quote_seq, start_ns)
        } else if age_ns > stale_ns {
            inputs
                .metrics
                .stale_market_events
                .fetch_add(1, Ordering::Relaxed);
            DesiredQuotes::empty(QuoteReason::StaleMarket, quote_seq, start_ns)
        } else {
            let snapshot = inputs.snapshot.load();
            compute_desired_quotes(
                &snapshot,
                &inputs.market,
                bbo,
                inventory_lots,
                quote_seq,
                start_ns,
                reason.unwrap_or(QuoteReason::Market),
            )
        };

        if next.bid != last_quotes.bid
            || next.ask != last_quotes.ask
            || next.model_revision != last_quotes.model_revision
            || next.reason != last_quotes.reason
        {
            inputs.desired.publish(next);
            inputs
                .metrics
                .quote_updates
                .fetch_add(1, Ordering::Relaxed);
            last_quotes = next;
        }

        inputs.state.store(HotStateSnapshot {
            inventory_lots,
            last_bid_px: bbo.bid_px,
            last_ask_px: bbo.ask_px,
            quote_seq,
            model_revision: next.model_revision,
            updated_unix_ms: unix_ms(),
        });
        inputs
            .metrics
            .observe_hot_latency(inputs.clock.now_ns().saturating_sub(start_ns));
    }
}
