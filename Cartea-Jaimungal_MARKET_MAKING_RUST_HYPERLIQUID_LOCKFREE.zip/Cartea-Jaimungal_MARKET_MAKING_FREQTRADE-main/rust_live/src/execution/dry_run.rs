use crate::config::{DryRunConfig, MarketConfig};
use crate::lockfree::{AsyncRing, HotEventRing, SharedQuotes};
use crate::metrics::Metrics;
use crate::types::{
    AtomicBbo, Bbo, DesiredOrder, DesiredQuotes, Fill, HotEvent, MarketProbe, Side, TakerSide,
};
use std::sync::atomic::Ordering;
use std::sync::Arc;
use tokio::sync::watch;
use tracing::info;

#[derive(Debug, Clone, Copy)]
struct SimOrder {
    desired: DesiredOrder,
    cloid_hash: u128,
    remaining_lots: i64,
    queue_ahead_units: i64,
}

pub struct DryRunEngine {
    config: DryRunConfig,
    market: MarketConfig,
    latest_bbo: Arc<AtomicBbo>,
    bid: Option<SimOrder>,
    ask: Option<SimOrder>,
    next_cloid: u128,
    cash_quote_units: i128,
}

impl DryRunEngine {
    pub fn new(
        config: DryRunConfig,
        market: MarketConfig,
        latest_bbo: Arc<AtomicBbo>,
    ) -> Self {
        let cash_quote_units =
            (config.initial_cash_quote * market.price_scale() as f64).round() as i128;
        Self {
            config,
            market,
            latest_bbo,
            bid: None,
            ask: None,
            next_cloid: 1,
            cash_quote_units,
        }
    }

    pub fn reconcile(&mut self, desired: DesiredQuotes) {
        let current_bid = self.bid.take();
        self.bid = self.reconcile_one(current_bid, desired.bid);
        let current_ask = self.ask.take();
        self.ask = self.reconcile_one(current_ask, desired.ask);
    }

    fn reconcile_one(
        &mut self,
        current: Option<SimOrder>,
        desired: Option<DesiredOrder>,
    ) -> Option<SimOrder> {
        match (current, desired) {
            (_, None) => None,
            (Some(current), Some(next)) if current.desired == next => Some(current),
            (_, Some(next)) => {
                let visible = self.latest_bbo.load().map(|bbo| match next.side {
                    Side::Buy if next.px == bbo.bid_px => bbo.bid_sz,
                    Side::Sell if next.px == bbo.ask_px => bbo.ask_sz,
                    _ => 0,
                }).unwrap_or_default();
                let queue_ahead_units =
                    (visible as f64 * self.config.queue_ahead_fraction).round() as i64;
                let cloid_hash = self.next_cloid;
                self.next_cloid = self.next_cloid.wrapping_add(1);
                Some(SimOrder {
                    desired: next,
                    cloid_hash,
                    remaining_lots: next.qty_lots,
                    queue_ahead_units: queue_ahead_units.max(0),
                })
            }
        }
    }

    pub fn on_probe(&mut self, probe: MarketProbe) -> Vec<Fill> {
        match probe {
            MarketProbe::Trade(trade) => {
                let mut fills = Vec::with_capacity(1);
                match trade.taker_side {
                    TakerSide::Sell => {
                        if let Some(fill) = self.trade_against_side(Side::Buy, trade.px, trade.qty_units, trade.exchange_ms) {
                            fills.push(fill);
                        }
                    }
                    TakerSide::Buy => {
                        if let Some(fill) = self.trade_against_side(Side::Sell, trade.px, trade.qty_units, trade.exchange_ms) {
                            fills.push(fill);
                        }
                    }
                }
                fills
            }
            MarketProbe::Bbo(bbo) => self.on_bbo(bbo),
        }
    }

    fn trade_against_side(
        &mut self,
        side: Side,
        trade_px: i64,
        mut traded_units: i64,
        exchange_ms: u64,
    ) -> Option<Fill> {
        let slot = match side {
            Side::Buy => &mut self.bid,
            Side::Sell => &mut self.ask,
        };
        let order = slot.as_mut()?;
        let eligible = match side {
            Side::Buy => trade_px <= order.desired.px,
            Side::Sell => trade_px >= order.desired.px,
        };
        if !eligible || traded_units <= 0 {
            return None;
        }
        let queue_consumed = traded_units.min(order.queue_ahead_units);
        order.queue_ahead_units -= queue_consumed;
        traded_units -= queue_consumed;
        let available_lots = traded_units.div_euclid(self.market.size_step_units);
        let fill_lots = available_lots.min(order.remaining_lots).max(0);
        if fill_lots == 0 {
            return None;
        }
        let order_snapshot = *order;
        order.remaining_lots -= fill_lots;
        let fully_filled = order.remaining_lots == 0;
        if fully_filled {
            *slot = None;
        }
        Some(self.make_fill(order_snapshot, fill_lots, exchange_ms))
    }

    fn on_bbo(&mut self, bbo: Bbo) -> Vec<Fill> {
        let mut fills = Vec::with_capacity(2);
        if let Some(order) = self.bid {
            let crossed = bbo.ask_px <= order.desired.px;
            let touched = self.config.fill_on_touch && bbo.bid_px == order.desired.px;
            if crossed || touched {
                let lots = if crossed {
                    order.remaining_lots
                } else {
                    bbo.bid_sz
                        .div_euclid(self.market.size_step_units)
                        .min(order.remaining_lots)
                };
                if lots > 0 {
                    fills.push(self.make_fill(order, lots, bbo.exchange_ms));
                    if lots >= order.remaining_lots {
                        self.bid = None;
                    } else if let Some(current) = self.bid.as_mut() {
                        current.remaining_lots -= lots;
                    }
                }
            }
        }
        if let Some(order) = self.ask {
            let crossed = bbo.bid_px >= order.desired.px;
            let touched = self.config.fill_on_touch && bbo.ask_px == order.desired.px;
            if crossed || touched {
                let lots = if crossed {
                    order.remaining_lots
                } else {
                    bbo.ask_sz
                        .div_euclid(self.market.size_step_units)
                        .min(order.remaining_lots)
                };
                if lots > 0 {
                    fills.push(self.make_fill(order, lots, bbo.exchange_ms));
                    if lots >= order.remaining_lots {
                        self.ask = None;
                    } else if let Some(current) = self.ask.as_mut() {
                        current.remaining_lots -= lots;
                    }
                }
            }
        }
        fills
    }

    fn make_fill(&mut self, order: SimOrder, fill_lots: i64, exchange_ms: u64) -> Fill {
        let qty_units = fill_lots.saturating_mul(self.market.size_step_units);
        let quote_units = (order.desired.px as i128)
            .saturating_mul(qty_units as i128)
            .div_euclid(self.market.size_scale() as i128);
        let fee_units = (quote_units as f64 * self.config.maker_fee_bps / 10_000.0).round() as i64;
        match order.desired.side {
            Side::Buy => self.cash_quote_units -= quote_units + fee_units as i128,
            Side::Sell => self.cash_quote_units += quote_units - fee_units as i128,
        }
        Fill {
            side: order.desired.side,
            px: order.desired.px,
            qty_lots: fill_lots,
            fee_quote_units: fee_units,
            exchange_ms,
            oid: None,
            cloid_hash: order.cloid_hash,
        }
    }
}

pub struct DryRunLoopArgs {
    pub config: DryRunConfig,
    pub market: MarketConfig,
    pub latest_bbo: Arc<AtomicBbo>,
    pub desired: Arc<SharedQuotes>,
    pub probe_ring: Arc<AsyncRing<MarketProbe>>,
    pub hot_events: Arc<HotEventRing>,
    pub metrics: Arc<Metrics>,
    pub shutdown: watch::Receiver<bool>,
}

pub async fn run_dry_run(mut args: DryRunLoopArgs) {
    let mut engine = DryRunEngine::new(args.config, args.market, args.latest_bbo);
    match args
        .hot_events
        .push_or_shutdown(HotEvent::Connected, &mut args.shutdown)
        .await
    {
        Ok(backpressured) => {
            if backpressured {
                args.metrics
                    .ring_backpressure_events
                    .fetch_add(1, Ordering::Relaxed);
            }
        }
        Err(_) => return,
    }

    let mut observed_quote_seq = args.desired.load().quote_seq;
    info!(
        probe_ring_capacity = args.probe_ring.capacity(),
        hot_event_ring_capacity = args.hot_events.capacity(),
        "dry-run execution backend ready"
    );
    loop {
        tokio::select! {
            biased;
            changed = args.shutdown.changed() => {
                if changed.is_err() || *args.shutdown.borrow() { break; }
            }
            probe = args.probe_ring.pop() => {
                for fill in engine.on_probe(probe) {
                    match args
                        .hot_events
                        .push_or_shutdown(HotEvent::Fill(fill), &mut args.shutdown)
                        .await
                    {
                        Ok(backpressured) => {
                            if backpressured {
                                args.metrics
                                    .ring_backpressure_events
                                    .fetch_add(1, Ordering::Relaxed);
                            }
                        }
                        Err(_) => return,
                    }
                    info!(
                        side = ?fill.side,
                        px_units = fill.px,
                        qty_lots = fill.qty_lots,
                        fee_quote_units = fill.fee_quote_units,
                        "dry-run fill"
                    );
                }

                // Coalesce to the newest quote only after the causal market
                // probe has been simulated. This avoids same-tick look-ahead.
                let latest = args.desired.load();
                if latest.quote_seq != observed_quote_seq {
                    observed_quote_seq = latest.quote_seq;
                    engine.reconcile(latest);
                }
            }
            desired = args.desired.changed_after(observed_quote_seq) => {
                observed_quote_seq = desired.quote_seq;
                engine.reconcile(desired);
            }
        }
    }
    info!(
        probe_ring_high_water = args.probe_ring.high_water_mark(),
        hot_event_ring_high_water = args.hot_events.high_water_mark(),
        "dry-run execution backend stopped"
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::{QuoteReason, Trade};

    #[test]
    fn passive_trade_consumes_queue_then_fills() {
        let market = MarketConfig {
            price_decimals: 2,
            size_decimals: 3,
            price_tick_units: 1,
            size_step_units: 1,
            ..MarketConfig::default()
        };
        let latest = Arc::new(AtomicBbo::default());
        latest.store(Bbo { bid_px: 10000, bid_sz: 10, ask_px: 10002, ask_sz: 10, ..Bbo::default() });
        let mut engine = DryRunEngine::new(
            DryRunConfig { queue_ahead_fraction: 0.5, ..DryRunConfig::default() },
            market,
            latest,
        );
        engine.reconcile(DesiredQuotes {
            bid: Some(DesiredOrder { side: Side::Buy, px: 10000, qty_lots: 3, reduce_only: false }),
            ask: None,
            quote_seq: 1,
            model_revision: 1,
            generated_ns: 0,
            reason: QuoteReason::Market,
        });
        let first = engine.on_probe(MarketProbe::Trade(Trade { taker_side: TakerSide::Sell, px: 10000, qty_units: 5, exchange_ms: 1, recv_ns: 1 }));
        assert!(first.is_empty());
        let second = engine.on_probe(MarketProbe::Trade(Trade { taker_side: TakerSide::Sell, px: 10000, qty_units: 3, exchange_ms: 2, recv_ns: 2 }));
        assert_eq!(second[0].qty_lots, 3);
    }
}
