use crate::config::{ExecutionConfig, MarketConfig};
use crate::hyperliquid::rpc::WsRpcClient;
use crate::hyperliquid::signing::{
    Action, ActionSigner, BulkCancel, BulkCancelByCloid, BulkModify, BulkOrder,
    CancelByCloidWire, CancelWire, LimitWire, ModifyWire, OrderTypeWire, OrderWire,
    ScheduleCancel,
};
use crate::hyperliquid::wire::{format_decimal_scaled, parse_decimal_scaled};
use crate::lockfree::{AsyncRing, HotEventRing, SharedQuotes};
use crate::metrics::Metrics;
use crate::types::{
    unix_ms, BackendEvent, DesiredOrder, DesiredQuotes, HotEvent, OrderStatus, Side,
};
use anyhow::{bail, Context, Result};
use serde_json::{json, Value};
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::watch;
use tracing::{info, warn};

#[derive(Debug, Clone)]
struct ManagedOrder {
    desired: DesiredOrder,
    cloid: String,
    oid: Option<u64>,
    created_ms: u64,
    last_action_ms: u64,
}

pub struct LiveOrderManager {
    coin: String,
    user: String,
    asset_id: u32,
    market: MarketConfig,
    execution: ExecutionConfig,
    signer: Arc<ActionSigner>,
    rpc: WsRpcClient,
    bid: Option<ManagedOrder>,
    ask: Option<ManagedOrder>,
    cloid_counter: u64,
}

impl LiveOrderManager {
    pub fn new(
        coin: String,
        user: String,
        asset_id: u32,
        market: MarketConfig,
        execution: ExecutionConfig,
        signer: Arc<ActionSigner>,
        rpc: WsRpcClient,
    ) -> Self {
        Self {
            coin,
            user,
            asset_id,
            market,
            execution,
            signer,
            rpc,
            bid: None,
            ask: None,
            cloid_counter: 1,
        }
    }

    pub async fn reconcile(&mut self, desired: DesiredQuotes) -> Result<()> {
        let urgent = desired.bid.is_none() && desired.ask.is_none();
        let bid = self.bid.take();
        self.bid = self.reconcile_side(bid, desired.bid, urgent).await?;
        let ask = self.ask.take();
        self.ask = self.reconcile_side(ask, desired.ask, urgent).await?;
        Ok(())
    }

    async fn reconcile_side(
        &mut self,
        current: Option<ManagedOrder>,
        desired: Option<DesiredOrder>,
        urgent: bool,
    ) -> Result<Option<ManagedOrder>> {
        match (current, desired) {
            (None, None) => Ok(None),
            (None, Some(next)) => self.place(next).await.map(Some),
            (Some(current), None) => {
                self.cancel(&current).await?;
                Ok(None)
            }
            (Some(mut current), Some(next)) => {
                if !self.needs_replace(&current.desired, &next) {
                    return Ok(Some(current));
                }
                let now = unix_ms();
                if !urgent
                    && now.saturating_sub(current.last_action_ms)
                        < self.execution.min_order_lifetime_ms
                {
                    return Ok(Some(current));
                }
                if let Some(oid) = current.oid {
                    let order = self.to_wire(next, Some(current.cloid.clone()));
                    let action = Action::BatchModify(BulkModify {
                        modifies: vec![ModifyWire { oid, order }],
                    });
                    self.submit(action).await?;
                    current.desired = next;
                    current.last_action_ms = now;
                    Ok(Some(current))
                } else {
                    // Until the private order update provides an oid, use the
                    // cloid-safe cancel/replace path. Once known, batchModify is used.
                    self.cancel(&current).await?;
                    self.place(next).await.map(Some)
                }
            }
        }
    }

    fn needs_replace(&self, current: &DesiredOrder, next: &DesiredOrder) -> bool {
        let threshold = self
            .execution
            .quote_replace_threshold_ticks
            .max(1)
            .saturating_mul(self.market.price_tick_units);
        (current.px - next.px).abs() >= threshold
            || current.qty_lots != next.qty_lots
            || current.reduce_only != next.reduce_only
    }

    async fn place(&mut self, desired: DesiredOrder) -> Result<ManagedOrder> {
        let cloid = self.next_cloid();
        let order = self.to_wire(desired, Some(cloid.clone()));
        let action = Action::Order(BulkOrder {
            orders: vec![order],
            grouping: "na".to_owned(),
            builder: None,
        });
        let response = self.submit(action).await?;
        let oid = extract_status_oids(&response).into_iter().next();
        let now = unix_ms();
        Ok(ManagedOrder {
            desired,
            cloid,
            oid,
            created_ms: now,
            last_action_ms: now,
        })
    }

    async fn cancel(&self, order: &ManagedOrder) -> Result<()> {
        let action = if let Some(oid) = order.oid {
            Action::Cancel(BulkCancel {
                cancels: vec![CancelWire {
                    asset: self.asset_id,
                    oid,
                }],
            })
        } else {
            Action::CancelByCloid(BulkCancelByCloid {
                cancels: vec![CancelByCloidWire {
                    asset: self.asset_id,
                    cloid: order.cloid.clone(),
                }],
            })
        };
        self.submit(action).await?;
        Ok(())
    }

    fn to_wire(&self, desired: DesiredOrder, cloid: Option<String>) -> OrderWire {
        OrderWire {
            asset: self.asset_id,
            is_buy: desired.side == Side::Buy,
            limit_px: format_decimal_scaled(desired.px, self.market.price_decimals),
            size: format_decimal_scaled(
                desired.qty_lots.saturating_mul(self.market.size_step_units),
                self.market.size_decimals,
            ),
            reduce_only: desired.reduce_only,
            order_type: OrderTypeWire::Limit(LimitWire {
                tif: if self.execution.post_only {
                    "Alo".to_owned()
                } else {
                    "Gtc".to_owned()
                },
            }),
            cloid,
        }
    }

    fn next_cloid(&mut self) -> String {
        let value = ((unix_ms() as u128) << 64) | self.cloid_counter as u128;
        self.cloid_counter = self.cloid_counter.wrapping_add(1);
        format!("0x{value:032x}")
    }

    async fn submit(&self, action: Action) -> Result<Value> {
        let nonce = self.signer.next_nonce(unix_ms());
        let signed = self.signer.sign_action(&action, nonce, None)?;
        let payload = serde_json::to_value(signed)?;
        let response = self.rpc.post_action(payload).await?;
        ensure_action_ok(&response)?;
        Ok(response)
    }

    pub fn apply_private_event(&mut self, event: &BackendEvent) {
        if let BackendEvent::OrderUpdate(update) = event {
            let slot = match update.side {
                Side::Buy => &mut self.bid,
                Side::Sell => &mut self.ask,
            };
            let matches = slot.as_ref().is_some_and(|working| {
                update
                    .cloid
                    .as_deref()
                    .is_some_and(|cloid| cloid.eq_ignore_ascii_case(&working.cloid))
                    || update.oid.is_some() && update.oid == working.oid
            });
            if !matches {
                return;
            }
            match update.status {
                OrderStatus::Open => {
                    if let Some(working) = slot.as_mut() {
                        working.oid = update.oid.or(working.oid);
                    }
                }
                OrderStatus::Filled | OrderStatus::Canceled | OrderStatus::Rejected => {
                    *slot = None;
                }
                OrderStatus::Unknown => {}
            }
        }
    }

    pub async fn cancel_tracked(&mut self) {
        if let Some(order) = self.bid.take() {
            if let Err(error) = self.cancel(&order).await {
                warn!(%error, side = "buy", "cannot cancel tracked order");
            }
        }
        if let Some(order) = self.ask.take() {
            if let Err(error) = self.cancel(&order).await {
                warn!(%error, side = "sell", "cannot cancel tracked order");
            }
        }
    }

    pub async fn cancel_existing_on_start(&self) -> Result<()> {
        let response = self
            .rpc
            .post_info(json!({"type": "openOrders", "user": self.user}))
            .await?;
        let oids = find_open_order_oids(&response, &self.coin);
        if oids.is_empty() {
            return Ok(());
        }
        let action = Action::Cancel(BulkCancel {
            cancels: oids
                .into_iter()
                .map(|oid| CancelWire {
                    asset: self.asset_id,
                    oid,
                })
                .collect(),
        });
        self.submit(action).await?;
        Ok(())
    }

    pub async fn renew_dead_man_switch(&self) -> Result<()> {
        let when = unix_ms().saturating_add(self.execution.schedule_cancel_horizon_ms);
        self.submit(Action::ScheduleCancel(ScheduleCancel { time: Some(when) }))
            .await?;
        Ok(())
    }

    pub async fn disable_dead_man_switch(&self) -> Result<()> {
        self.submit(Action::ScheduleCancel(ScheduleCancel { time: None }))
            .await?;
        Ok(())
    }
}

fn ensure_action_ok(value: &Value) -> Result<()> {
    if value.get("status").and_then(Value::as_str) == Some("err") {
        bail!("Hyperliquid action rejected: {value}");
    }
    if let Some(error) = find_error(value) {
        bail!("Hyperliquid action rejected: {error}");
    }
    Ok(())
}

fn find_error(value: &Value) -> Option<String> {
    match value {
        Value::Object(map) => {
            if let Some(error) = map.get("error").and_then(Value::as_str) {
                return Some(error.to_owned());
            }
            map.values().find_map(find_error)
        }
        Value::Array(values) => values.iter().find_map(find_error),
        _ => None,
    }
}

fn find_oid(value: &Value) -> Option<u64> {
    match value {
        Value::Object(map) => map
            .get("oid")
            .and_then(|oid| oid.as_u64().or_else(|| oid.as_str()?.parse().ok()))
            .or_else(|| map.values().find_map(find_oid)),
        Value::Array(values) => values.iter().find_map(find_oid),
        _ => None,
    }
}

fn extract_status_oids(value: &Value) -> Vec<u64> {
    match value {
        Value::Object(map) => {
            if let Some(statuses) = map.get("statuses").and_then(Value::as_array) {
                return statuses.iter().filter_map(find_oid).collect();
            }
            map.values()
                .find_map(|value| {
                    let oids = extract_status_oids(value);
                    (!oids.is_empty()).then_some(oids)
                })
                .unwrap_or_default()
        }
        Value::Array(values) => values
            .iter()
            .find_map(|value| {
                let oids = extract_status_oids(value);
                (!oids.is_empty()).then_some(oids)
            })
            .unwrap_or_default(),
        _ => Vec::new(),
    }
}

fn find_open_order_oids(value: &Value, coin: &str) -> Vec<u64> {
    let mut out = Vec::new();
    collect_open_order_oids(value, coin, &mut out);
    out.sort_unstable();
    out.dedup();
    out
}

fn collect_open_order_oids(value: &Value, coin: &str, out: &mut Vec<u64>) {
    match value {
        Value::Object(map) => {
            if map.get("coin").and_then(Value::as_str) == Some(coin) {
                if let Some(oid) = map
                    .get("oid")
                    .and_then(|value| value.as_u64().or_else(|| value.as_str()?.parse().ok()))
                {
                    out.push(oid);
                }
            }
            for value in map.values() {
                collect_open_order_oids(value, coin, out);
            }
        }
        Value::Array(values) => {
            for value in values {
                collect_open_order_oids(value, coin, out);
            }
        }
        _ => {}
    }
}

pub struct LiveLoopArgs {
    pub manager: LiveOrderManager,
    pub desired: Arc<SharedQuotes>,
    pub private_events: Arc<AsyncRing<BackendEvent>>,
    pub hot_events: Arc<HotEventRing>,
    pub metrics: Arc<Metrics>,
    pub shutdown: watch::Receiver<bool>,
}

pub async fn run_live(mut args: LiveLoopArgs) {
    if args.manager.execution.cancel_on_start {
        match args.manager.cancel_existing_on_start().await {
            Ok(()) => info!("startup open-order cleanup complete"),
            Err(error) => warn!(%error, "startup open-order cleanup failed"),
        }
    }
    let interval_ms = args.manager.execution.schedule_cancel_interval_ms.max(1_000);
    let mut dead_man = tokio::time::interval(Duration::from_millis(interval_ms));
    dead_man.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    let mut observed_quote_seq = args.desired.load().quote_seq;
    info!(
        private_ring_capacity = args.private_events.capacity(),
        hot_event_ring_capacity = args.hot_events.capacity(),
        "live Hyperliquid execution backend ready"
    );

    loop {
        tokio::select! {
            biased;
            changed = args.shutdown.changed() => {
                if changed.is_err() || *args.shutdown.borrow() { break; }
            }
            event = args.private_events.pop() => {
                let hot_event = event.to_hot_event();
                args.manager.apply_private_event(&event);
                if let Some(hot_event) = hot_event {
                    match args.hot_events
                        .push_or_shutdown(hot_event, &mut args.shutdown)
                        .await
                    {
                        Ok(backpressured) => {
                            if backpressured {
                                args.metrics
                                    .ring_backpressure_events
                                    .fetch_add(1, Ordering::Relaxed);
                            }
                        }
                        Err(_) => break,
                    }
                }
            }
            desired = args.desired.changed_after(observed_quote_seq) => {
                observed_quote_seq = desired.quote_seq;
                if let Err(error) = args.manager.reconcile(desired).await {
                    args.metrics.action_rejections.fetch_add(1, Ordering::Relaxed);
                    match args.hot_events
                        .push_or_shutdown(HotEvent::ActionRejected, &mut args.shutdown)
                        .await
                    {
                        Ok(backpressured) => {
                            if backpressured {
                                args.metrics
                                    .ring_backpressure_events
                                    .fetch_add(1, Ordering::Relaxed);
                            }
                        }
                        Err(_) => break,
                    }
                    warn!(%error, quote_seq = desired.quote_seq, "quote reconciliation failed");
                }
            }
            _ = dead_man.tick() => {
                if let Err(error) = args.manager.renew_dead_man_switch().await {
                    args.metrics.action_rejections.fetch_add(1, Ordering::Relaxed);
                    warn!(%error, "cannot renew scheduleCancel dead-man switch");
                }
            }
        }
    }

    if args.manager.execution.cancel_on_exit {
        args.manager.cancel_tracked().await;
    }
    if let Err(error) = args.manager.disable_dead_man_switch().await {
        warn!(%error, "cannot disable scheduleCancel during clean shutdown");
    }
    info!(
        private_ring_high_water = args.private_events.high_water_mark(),
        hot_event_ring_high_water = args.hot_events.high_water_mark(),
        "live Hyperliquid execution backend stopped"
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn finds_oids_in_order_response() {
        let value = json!({"response":{"data":{"statuses":[{"resting":{"oid":12}}, {"filled":{"oid":"13"}}]}}});
        assert_eq!(extract_status_oids(&value), vec![12, 13]);
    }
}
