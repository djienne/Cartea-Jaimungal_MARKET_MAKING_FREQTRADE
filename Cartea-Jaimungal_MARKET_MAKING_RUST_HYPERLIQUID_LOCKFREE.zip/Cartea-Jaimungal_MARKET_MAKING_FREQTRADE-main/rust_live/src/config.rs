use anyhow::{bail, Context, Result};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RunMode {
    DryRun,
    Live,
}

impl Default for RunMode {
    fn default() -> Self {
        Self::DryRun
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Network {
    Testnet,
    Mainnet,
}

impl Default for Network {
    fn default() -> Self {
        Self::Testnet
    }
}

impl Network {
    pub const fn ws_url(self) -> &'static str {
        match self {
            Self::Testnet => "wss://api.hyperliquid-testnet.xyz/ws",
            Self::Mainnet => "wss://api.hyperliquid.xyz/ws",
        }
    }

    pub const fn is_mainnet(self) -> bool {
        matches!(self, Self::Mainnet)
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct AppConfig {
    pub runtime: RuntimeConfig,
    pub market: MarketConfig,
    pub execution: ExecutionConfig,
    pub dry_run: DryRunConfig,
    pub telemetry: TelemetryConfig,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            runtime: RuntimeConfig::default(),
            market: MarketConfig::default(),
            execution: ExecutionConfig::default(),
            dry_run: DryRunConfig::default(),
            telemetry: TelemetryConfig::default(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct RuntimeConfig {
    pub mode: RunMode,
    pub network: Network,
    pub coin: String,
    pub wallet_address: Option<String>,
    pub private_key_env: String,
    pub snapshot_path: PathBuf,
    pub state_path: PathBuf,
    pub hot_path_cpu: Option<usize>,
    /// Power-of-two capacity of the dry-run market probe ring.
    pub market_probe_ring_capacity: usize,
    /// Power-of-two capacity of the private account event ring.
    pub private_event_ring_capacity: usize,
    /// Power-of-two capacity of the execution-to-hot-path event ring.
    pub hot_event_ring_capacity: usize,
    pub initial_inventory_lots: i64,
    pub live_confirmation_env: String,
    pub live_confirmation_value: String,
    pub mainnet_confirmation_env: String,
    pub mainnet_confirmation_value: String,
}

impl Default for RuntimeConfig {
    fn default() -> Self {
        Self {
            mode: RunMode::DryRun,
            network: Network::Testnet,
            coin: "ETH".to_owned(),
            wallet_address: None,
            private_key_env: "HL_PRIVATE_KEY".to_owned(),
            snapshot_path: PathBuf::from("config/strategy_snapshot.json"),
            state_path: PathBuf::from("run/mm-live-state.json"),
            hot_path_cpu: None,
            market_probe_ring_capacity: 8_192,
            private_event_ring_capacity: 4_096,
            hot_event_ring_capacity: 16_384,
            initial_inventory_lots: 0,
            live_confirmation_env: "HL_LIVE_CONFIRMATION".to_owned(),
            live_confirmation_value: "I_UNDERSTAND_THIS_SENDS_REAL_ORDERS".to_owned(),
            mainnet_confirmation_env: "HL_MAINNET_CONFIRMATION".to_owned(),
            mainnet_confirmation_value: "I_UNDERSTAND_THIS_USES_MAINNET_FUNDS".to_owned(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct MarketConfig {
    pub ws_url: Option<String>,
    pub subscribe_bbo: bool,
    pub subscribe_trades: bool,
    pub stale_after_ms: u64,
    pub reconnect_min_ms: u64,
    pub reconnect_max_ms: u64,
    pub price_decimals: u32,
    pub size_decimals: u32,
    /// Tick size expressed in `10^-price_decimals` integer units.
    pub price_tick_units: i64,
    /// One engine lot expressed in `10^-size_decimals` integer size units.
    pub size_step_units: i64,
    /// Hyperliquid currently accepts at most five significant figures for perp prices.
    pub max_price_significant_figures: u32,
}

impl Default for MarketConfig {
    fn default() -> Self {
        Self {
            ws_url: None,
            subscribe_bbo: true,
            subscribe_trades: true,
            stale_after_ms: 1_500,
            reconnect_min_ms: 250,
            reconnect_max_ms: 8_000,
            price_decimals: 2,
            size_decimals: 4,
            price_tick_units: 1,
            size_step_units: 1,
            max_price_significant_figures: 5,
        }
    }
}

impl MarketConfig {
    pub fn effective_ws_url(&self, network: Network) -> String {
        self.ws_url
            .clone()
            .unwrap_or_else(|| network.ws_url().to_owned())
    }

    pub fn price_scale(&self) -> i64 {
        10_i64.pow(self.price_decimals)
    }

    pub fn size_scale(&self) -> i64 {
        10_i64.pow(self.size_decimals)
    }

    /// Dynamic integer price quantum satisfying both the configured tick and
    /// Hyperliquid's significant-figure rule at the current price magnitude.
    pub fn price_quantum_for(&self, px_units: i64) -> i64 {
        if px_units == 0 || self.max_price_significant_figures == 0 {
            return self.price_tick_units;
        }
        let px = px_units.unsigned_abs() as f64 / self.price_scale() as f64;
        let decimal_places = (self.max_price_significant_figures as i32 - 1
            - px.log10().floor() as i32)
            .clamp(0, self.price_decimals as i32) as u32;
        let sig_quantum = 10_i64.pow(self.price_decimals - decimal_places);
        self.price_tick_units.max(sig_quantum)
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct ExecutionConfig {
    /// Perpetual asset index from Hyperliquid meta. Mandatory for real mode.
    pub asset_id: Option<u32>,
    pub post_only: bool,
    pub quote_replace_threshold_ticks: i64,
    pub min_order_lifetime_ms: u64,
    pub action_timeout_ms: u64,
    pub schedule_cancel_interval_ms: u64,
    pub schedule_cancel_horizon_ms: u64,
    pub cancel_on_start: bool,
    pub cancel_on_exit: bool,
    pub private_position_sync_ms: u64,
    pub max_pending_actions: usize,
    pub vault_address: Option<String>,
}

impl Default for ExecutionConfig {
    fn default() -> Self {
        Self {
            asset_id: None,
            post_only: true,
            quote_replace_threshold_ticks: 1,
            min_order_lifetime_ms: 75,
            action_timeout_ms: 3_000,
            schedule_cancel_interval_ms: 20_000,
            schedule_cancel_horizon_ms: 60_000,
            cancel_on_start: false,
            cancel_on_exit: true,
            private_position_sync_ms: 30_000,
            max_pending_actions: 32,
            vault_address: None,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct DryRunConfig {
    pub initial_cash_quote: f64,
    pub maker_fee_bps: f64,
    pub queue_ahead_fraction: f64,
    pub fill_on_touch: bool,
    pub latency_ms: u64,
}

impl Default for DryRunConfig {
    fn default() -> Self {
        Self {
            initial_cash_quote: 10_000.0,
            maker_fee_bps: 0.0,
            queue_ahead_fraction: 0.50,
            fill_on_touch: false,
            latency_ms: 0,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct TelemetryConfig {
    pub log_format: LogFormat,
    pub stats_interval_ms: u64,
    pub snapshot_poll_ms: u64,
    pub state_flush_ms: u64,
}

impl Default for TelemetryConfig {
    fn default() -> Self {
        Self {
            log_format: LogFormat::Pretty,
            stats_interval_ms: 5_000,
            snapshot_poll_ms: 500,
            state_flush_ms: 2_000,
        }
    }
}

#[derive(Debug, Clone, Copy, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LogFormat {
    Pretty,
    Json,
}

impl AppConfig {
    pub fn load(path: &Path) -> Result<Self> {
        let raw = std::fs::read_to_string(path)
            .with_context(|| format!("cannot read config {}", path.display()))?;
        let mut cfg: Self = toml::from_str(&raw)
            .with_context(|| format!("cannot parse TOML config {}", path.display()))?;
        let base = path.parent().unwrap_or_else(|| Path::new("."));
        if cfg.runtime.snapshot_path.is_relative() {
            cfg.runtime.snapshot_path = base.join(&cfg.runtime.snapshot_path);
        }
        if cfg.runtime.state_path.is_relative() {
            cfg.runtime.state_path = base.join(&cfg.runtime.state_path);
        }
        cfg.validate_static()?;
        Ok(cfg)
    }

    pub fn validate_static(&self) -> Result<()> {
        if self.runtime.coin.trim().is_empty() {
            bail!("runtime.coin must not be empty");
        }
        if self.market.price_decimals > 12 || self.market.size_decimals > 12 {
            bail!("price_decimals and size_decimals must be <= 12");
        }
        if !(1..=10).contains(&self.market.max_price_significant_figures) {
            bail!("market.max_price_significant_figures must be in 1..=10");
        }
        if self.market.price_tick_units <= 0 || self.market.size_step_units <= 0 {
            bail!("price_tick_units and size_step_units must be strictly positive");
        }
        if self.market.stale_after_ms < 50 {
            bail!("market.stale_after_ms below 50 ms is unsafe");
        }
        if !(0.0..=10.0).contains(&self.dry_run.queue_ahead_fraction) {
            bail!("dry_run.queue_ahead_fraction must be between 0 and 10");
        }
        if self.execution.max_pending_actions == 0 {
            bail!("execution.max_pending_actions must be positive");
        }
        for (name, capacity) in [
            (
                "runtime.market_probe_ring_capacity",
                self.runtime.market_probe_ring_capacity,
            ),
            (
                "runtime.private_event_ring_capacity",
                self.runtime.private_event_ring_capacity,
            ),
            (
                "runtime.hot_event_ring_capacity",
                self.runtime.hot_event_ring_capacity,
            ),
        ] {
            if capacity == 0 || !capacity.is_power_of_two() {
                bail!("{name} must be a positive power of two");
            }
            if capacity > 1_048_576 {
                bail!("{name} must not exceed 1048576 entries");
            }
        }
        Ok(())
    }

    pub fn enforce_live_guards(&self, cli_enable_live: bool) -> Result<()> {
        if self.runtime.mode != RunMode::Live {
            return Ok(());
        }
        if !cli_enable_live {
            bail!("live mode requires the explicit --enable-live CLI flag");
        }
        let confirmation = std::env::var(&self.runtime.live_confirmation_env).unwrap_or_default();
        if confirmation != self.runtime.live_confirmation_value {
            bail!(
                "live mode requires {}={} exactly",
                self.runtime.live_confirmation_env,
                self.runtime.live_confirmation_value
            );
        }
        if self.runtime.network.is_mainnet() {
            let confirmation =
                std::env::var(&self.runtime.mainnet_confirmation_env).unwrap_or_default();
            if confirmation != self.runtime.mainnet_confirmation_value {
                bail!(
                    "mainnet requires {}={} exactly",
                    self.runtime.mainnet_confirmation_env,
                    self.runtime.mainnet_confirmation_value
                );
            }
        }
        if std::env::var(&self.runtime.private_key_env)
            .unwrap_or_default()
            .trim()
            .is_empty()
        {
            bail!("{} is missing or empty", self.runtime.private_key_env);
        }
        if self.execution.asset_id.is_none() {
            bail!("execution.asset_id is mandatory in live mode");
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_ring_capacities_are_valid() {
        assert!(AppConfig::default().validate_static().is_ok());
    }

    #[test]
    fn rejects_non_power_of_two_ring_capacity() {
        let mut config = AppConfig::default();
        config.runtime.hot_event_ring_capacity = 3_000;
        let error = config.validate_static().expect_err("capacity must be rejected");
        assert!(error.to_string().contains("positive power of two"));
    }
}
