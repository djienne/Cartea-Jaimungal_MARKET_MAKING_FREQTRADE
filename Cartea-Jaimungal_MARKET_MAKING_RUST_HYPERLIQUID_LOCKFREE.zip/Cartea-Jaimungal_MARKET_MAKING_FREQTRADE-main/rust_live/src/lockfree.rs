use crate::types::{AtomicDesiredQuotes, DesiredQuotes, HotEvent};
use crossbeam_queue::ArrayQueue;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, OnceLock};
use std::thread::{self, Thread};
use std::time::Duration;
use tokio::sync::{watch, Notify};

pub const HOT_SIGNAL_MARKET: usize = 1 << 0;
pub const HOT_SIGNAL_MODEL: usize = 1 << 1;
pub const HOT_SIGNAL_EVENT: usize = 1 << 2;
pub const HOT_SIGNAL_SHUTDOWN: usize = 1 << 3;

/// Lock-free, coalescing wake state for the dedicated hot-path thread.
///
/// Producers only perform an atomic `fetch_or`. `Thread::unpark` is used solely
/// to avoid busy-spinning while no work is pending; the state transfer itself
/// is entirely atomic and coalesces redundant market/model notifications.
#[derive(Debug, Default)]
#[repr(align(64))]
pub struct HotPathSignal {
    pending: AtomicUsize,
    hot_thread: OnceLock<Thread>,
}

impl HotPathSignal {
    pub fn register_current_thread(&self) {
        let current = thread::current();
        let _ = self.hot_thread.set(current.clone());
        if self.pending.load(Ordering::Acquire) != 0 {
            current.unpark();
        }
    }

    /// Marks `bits` pending and wakes the hot thread if it was idle.
    /// Returns `true` when at least one bit was newly pending.
    #[inline]
    pub fn notify(&self, bits: usize) -> bool {
        debug_assert!(bits != 0);
        let previous = self.pending.fetch_or(bits, Ordering::Release);
        if previous == 0 {
            if let Some(thread) = self.hot_thread.get() {
                thread.unpark();
            }
        }
        previous & bits != bits
    }

    #[inline]
    pub fn take_pending(&self) -> usize {
        self.pending.swap(0, Ordering::AcqRel)
    }

    #[inline]
    pub fn park_timeout(&self, timeout: Duration) {
        thread::park_timeout(timeout);
    }
}


struct AtomicWaiter<'a> {
    counter: &'a AtomicUsize,
}

impl<'a> AtomicWaiter<'a> {
    #[inline]
    fn new(counter: &'a AtomicUsize) -> Self {
        counter.fetch_add(1, Ordering::AcqRel);
        Self { counter }
    }
}

impl Drop for AtomicWaiter<'_> {
    #[inline]
    fn drop(&mut self) {
        self.counter.fetch_sub(1, Ordering::AcqRel);
    }
}

/// Bounded array-backed MPMC ring buffer.
///
/// Successful push/pop operations are handled by `ArrayQueue` without a
/// mutex. Tokio notifications are touched only when a producer/consumer must
/// sleep because the ring is full/empty.
pub struct AsyncRing<T> {
    queue: ArrayQueue<T>,
    high_water: AtomicUsize,
    waiting_producers: AtomicUsize,
    waiting_consumers: AtomicUsize,
    not_empty: Notify,
    not_full: Notify,
}

impl<T> std::fmt::Debug for AsyncRing<T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("AsyncRing")
            .field("capacity", &self.capacity())
            .field("len", &self.len())
            .field("high_water_mark", &self.high_water_mark())
            .field(
                "waiting_producers",
                &self.waiting_producers.load(Ordering::Relaxed),
            )
            .field(
                "waiting_consumers",
                &self.waiting_consumers.load(Ordering::Relaxed),
            )
            .finish_non_exhaustive()
    }
}

impl<T> AsyncRing<T> {
    pub fn new(capacity: usize) -> Self {
        assert!(capacity > 0, "ring capacity must be positive");
        Self {
            queue: ArrayQueue::new(capacity),
            high_water: AtomicUsize::new(0),
            waiting_producers: AtomicUsize::new(0),
            waiting_consumers: AtomicUsize::new(0),
            not_empty: Notify::new(),
            not_full: Notify::new(),
        }
    }

    #[inline]
    pub fn capacity(&self) -> usize {
        self.queue.capacity()
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.queue.len()
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.queue.is_empty()
    }

    /// Best-effort peak observed depth. It is maintained with relaxed atomics
    /// and is intended for capacity tuning, not correctness decisions.
    #[inline]
    pub fn high_water_mark(&self) -> usize {
        self.high_water.load(Ordering::Relaxed)
    }

    #[inline]
    fn observe_high_water(&self) {
        let depth = self.queue.len();
        let mut current = self.high_water.load(Ordering::Relaxed);
        while depth > current {
            match self.high_water.compare_exchange_weak(
                current,
                depth,
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(next) => current = next,
            }
        }
    }

    #[inline]
    fn notify_consumer_if_waiting(&self) {
        if self.waiting_consumers.load(Ordering::Acquire) != 0 {
            self.not_empty.notify_one();
        }
    }

    #[inline]
    fn notify_producer_if_waiting(&self) {
        if self.waiting_producers.load(Ordering::Acquire) != 0 {
            self.not_full.notify_one();
        }
    }

    #[inline]
    pub fn try_push(&self, value: T) -> Result<(), T> {
        self.queue.push(value).map(|()| {
            self.observe_high_water();
            self.notify_consumer_if_waiting();
        })
    }

    /// Pushes with bounded backpressure. The boolean reports whether the
    /// producer had to wait for capacity at least once.
    pub async fn push_or_shutdown(
        &self,
        mut value: T,
        shutdown: &mut watch::Receiver<bool>,
    ) -> Result<bool, T> {
        let mut backpressured = false;

        loop {
            if *shutdown.borrow() {
                return Err(value);
            }

            match self.queue.push(value) {
                Ok(()) => {
                    self.observe_high_water();
                    self.notify_consumer_if_waiting();
                    return Ok(backpressured);
                }
                Err(returned) => {
                    value = returned;
                    backpressured = true;
                }
            }

            // Register the waiter before rechecking capacity. If a consumer
            // popped between the failed push and registration, the second push
            // observes that slot directly. The RAII counter is cancellation-safe.
            let space_available = self.not_full.notified();
            tokio::pin!(space_available);
            let waiting = AtomicWaiter::new(&self.waiting_producers);
            space_available.as_mut().enable();

            match self.queue.push(value) {
                Ok(()) => {
                    drop(waiting);
                    self.observe_high_water();
                    self.notify_consumer_if_waiting();
                    return Ok(backpressured);
                }
                Err(returned) => value = returned,
            }

            tokio::select! {
                biased;
                changed = shutdown.changed() => {
                    if changed.is_err() || *shutdown.borrow() {
                        return Err(value);
                    }
                }
                _ = space_available.as_mut() => {}
            }
            drop(waiting);
        }
    }

    #[inline]
    pub fn try_pop(&self) -> Option<T> {
        let value = self.queue.pop();
        if value.is_some() {
            self.notify_producer_if_waiting();
        }
        value
    }

    pub async fn pop(&self) -> T {
        loop {
            if let Some(value) = self.try_pop() {
                return value;
            }

            // Register before rechecking the ring. A producer racing this
            // transition either sees the waiter and notifies it, or the second
            // pop observes the newly published item.
            let item_available = self.not_empty.notified();
            tokio::pin!(item_available);
            let waiting = AtomicWaiter::new(&self.waiting_consumers);
            item_available.as_mut().enable();

            if let Some(value) = self.try_pop() {
                drop(waiting);
                return value;
            }
            item_available.as_mut().await;
            drop(waiting);
        }
    }
}

/// Atomic latest-value publication for desired quotes. Intermediate versions
/// are intentionally coalesced; execution always consumes the newest complete
/// seqlock snapshot.
pub struct SharedQuotes {
    value: AtomicDesiredQuotes,
    waiting_consumers: AtomicUsize,
    changed: Notify,
}

impl Default for SharedQuotes {
    fn default() -> Self {
        Self {
            value: AtomicDesiredQuotes::default(),
            waiting_consumers: AtomicUsize::new(0),
            changed: Notify::new(),
        }
    }
}

impl std::fmt::Debug for SharedQuotes {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SharedQuotes")
            .field("value", &self.load())
            .field(
                "waiting_consumers",
                &self.waiting_consumers.load(Ordering::Relaxed),
            )
            .finish_non_exhaustive()
    }
}

impl SharedQuotes {
    #[inline]
    pub fn publish(&self, quotes: DesiredQuotes) {
        self.value.store(quotes);
        if self.waiting_consumers.load(Ordering::Acquire) != 0 {
            self.changed.notify_one();
        }
    }

    #[inline]
    pub fn load(&self) -> DesiredQuotes {
        self.value.load()
    }

    pub async fn changed_after(&self, observed_quote_seq: u64) -> DesiredQuotes {
        loop {
            let current = self.load();
            if current.quote_seq != observed_quote_seq {
                return current;
            }

            let changed = self.changed.notified();
            tokio::pin!(changed);
            let waiting = AtomicWaiter::new(&self.waiting_consumers);
            changed.as_mut().enable();

            let current = self.load();
            if current.quote_seq != observed_quote_seq {
                drop(waiting);
                return current;
            }
            changed.as_mut().await;
            drop(waiting);
        }
    }
}

/// Priority ring between execution/account handling and the dedicated hot
/// thread. Events are fixed-size and allocation-free after parsing.
#[derive(Debug)]
pub struct HotEventRing {
    ring: AsyncRing<HotEvent>,
    signal: Arc<HotPathSignal>,
}

impl HotEventRing {
    pub fn new(capacity: usize, signal: Arc<HotPathSignal>) -> Self {
        Self {
            ring: AsyncRing::new(capacity),
            signal,
        }
    }

    pub async fn push_or_shutdown(
        &self,
        event: HotEvent,
        shutdown: &mut watch::Receiver<bool>,
    ) -> Result<bool, HotEvent> {
        let result = self.ring.push_or_shutdown(event, shutdown).await;
        if result.is_ok() {
            self.signal.notify(HOT_SIGNAL_EVENT);
        }
        result
    }

    #[inline]
    pub fn try_pop(&self) -> Option<HotEvent> {
        self.ring.try_pop()
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.ring.len()
    }

    #[inline]
    pub fn capacity(&self) -> usize {
        self.ring.capacity()
    }

    #[inline]
    pub fn high_water_mark(&self) -> usize {
        self.ring.high_water_mark()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::{DesiredOrder, QuoteReason, Side};

    #[tokio::test]
    async fn async_ring_is_fifo_and_bounded() {
        let ring = AsyncRing::new(2);
        assert!(ring.try_push(10).is_ok());
        assert!(ring.try_push(20).is_ok());
        assert_eq!(ring.try_push(30), Err(30));
        assert_eq!(ring.high_water_mark(), 2);
        assert_eq!(ring.pop().await, 10);
        assert_eq!(ring.pop().await, 20);
    }

    #[tokio::test]
    async fn full_ring_wakes_multiple_blocked_producers() {
        let ring = Arc::new(AsyncRing::new(1));
        ring.try_push(0_u64).expect("initial slot must be free");
        let (_shutdown_tx, shutdown_rx) = watch::channel(false);

        let first_ring = ring.clone();
        let mut first_shutdown = shutdown_rx.clone();
        let first = tokio::spawn(async move {
            first_ring
                .push_or_shutdown(1, &mut first_shutdown)
                .await
        });
        let second_ring = ring.clone();
        let mut second_shutdown = shutdown_rx;
        let second = tokio::spawn(async move {
            second_ring
                .push_or_shutdown(2, &mut second_shutdown)
                .await
        });

        assert_eq!(ring.pop().await, 0);
        let mut produced = tokio::time::timeout(Duration::from_secs(1), async {
            vec![ring.pop().await, ring.pop().await]
        })
        .await
        .expect("both blocked producers must be woken");
        produced.sort_unstable();
        assert_eq!(produced, vec![1, 2]);
        assert!(first.await.expect("first producer task panicked").is_ok());
        assert!(second.await.expect("second producer task panicked").is_ok());
    }

    #[tokio::test]
    async fn shared_quotes_coalesces_to_latest_version() {
        let shared = SharedQuotes::default();
        shared.publish(DesiredQuotes {
            bid: Some(DesiredOrder {
                side: Side::Buy,
                px: 100,
                qty_lots: 2,
                reduce_only: false,
            }),
            ask: None,
            quote_seq: 1,
            model_revision: 7,
            generated_ns: 11,
            reason: QuoteReason::Market,
        });
        shared.publish(DesiredQuotes {
            quote_seq: 2,
            ..shared.load()
        });
        assert_eq!(shared.changed_after(0).await.quote_seq, 2);
    }

    #[test]
    fn hot_signal_coalesces_bits() {
        let signal = HotPathSignal::default();
        assert!(signal.notify(HOT_SIGNAL_MARKET));
        assert!(!signal.notify(HOT_SIGNAL_MARKET));
        assert!(signal.notify(HOT_SIGNAL_MODEL));
        assert_eq!(
            signal.take_pending(),
            HOT_SIGNAL_MARKET | HOT_SIGNAL_MODEL
        );
    }
}
