use crate::config::MarketConfig;
use crate::types::{Bbo, DesiredOrder, DesiredQuotes, QuoteReason, Side};
use anyhow::{bail, Context, Result};
use serde::{Deserialize, Serialize};
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct StrategySnapshot {
    pub schema_version: u32,
    pub revision: u64,
    pub generated_at_ms: u64,
    pub model: ModelParams,
    pub risk: RiskParams,
    pub hjb: Option<HjbSurface>,
}

impl Default for StrategySnapshot {
    fn default() -> Self {
        Self {
            schema_version: 1,
            revision: 1,
            generated_at_ms: 0,
            model: ModelParams::default(),
            risk: RiskParams::default(),
            hjb: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ModelParams {
    /// Absolute risk aversion used by the Cartea/Avellaneda-Stoikov approximation.
    pub gamma: f64,
    /// Order-arrival depth parameter. Must be strictly positive.
    pub kappa: f64,
    /// Price volatility per square-root second, in quote-currency price units.
    pub sigma: f64,
    /// Rolling quoting horizon in seconds.
    pub horizon_sec: f64,
    /// Hard floor applied to the model half-spread.
    pub base_half_spread_bps: f64,
    /// Additional reservation-price skew per inventory lot.
    pub inventory_skew_bps_per_lot: f64,
    pub min_half_spread_ticks: i64,
    pub quote_size_lots: i64,
    /// Maximum improvement over the displayed same-side BBO.
    pub max_quote_improvement_ticks: i64,
}

impl Default for ModelParams {
    fn default() -> Self {
        Self {
            gamma: 0.05,
            kappa: 1.5,
            sigma: 0.5,
            horizon_sec: 5.0,
            base_half_spread_bps: 1.5,
            inventory_skew_bps_per_lot: 0.15,
            min_half_spread_ticks: 1,
            quote_size_lots: 1,
            max_quote_improvement_ticks: 1,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct RiskParams {
    pub kill_switch: bool,
    pub max_inventory_lots: i64,
    pub reduce_only_threshold_lots: i64,
    pub max_order_notional: f64,
    pub max_position_notional: f64,
    pub max_market_spread_bps: f64,
}

impl Default for RiskParams {
    fn default() -> Self {
        Self {
            kill_switch: false,
            max_inventory_lots: 20,
            reduce_only_threshold_lots: 15,
            max_order_notional: 1_000.0,
            max_position_notional: 10_000.0,
            max_market_spread_bps: 100.0,
        }
    }
}

/// Optional precomputed offsets exported by the existing Python HJB solver.
/// Each vector entry is an offset from the reservation/mid price in integer
/// price ticks. This is the preferred way to preserve an exact Python policy
/// while keeping interpolation and execution in Rust.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HjbSurface {
    pub inventory_min_lots: i64,
    pub inventory_step_lots: i64,
    pub bid_offset_ticks: Vec<i64>,
    pub ask_offset_ticks: Vec<i64>,
}

impl StrategySnapshot {
    pub fn load(path: &Path) -> Result<Self> {
        let raw = std::fs::read_to_string(path)
            .with_context(|| format!("cannot read strategy snapshot {}", path.display()))?;
        let snapshot: Self = serde_json::from_str(&raw)
            .with_context(|| format!("cannot parse strategy snapshot {}", path.display()))?;
        snapshot.validate()?;
        Ok(snapshot)
    }

    pub fn validate(&self) -> Result<()> {
        if self.schema_version != 1 {
            bail!("unsupported strategy snapshot schema_version {}", self.schema_version);
        }
        if !self.model.gamma.is_finite() || self.model.gamma < 0.0 {
            bail!("model.gamma must be finite and non-negative");
        }
        if !self.model.kappa.is_finite() || self.model.kappa <= 0.0 {
            bail!("model.kappa must be finite and strictly positive");
        }
        if !self.model.sigma.is_finite() || self.model.sigma < 0.0 {
            bail!("model.sigma must be finite and non-negative");
        }
        if !self.model.horizon_sec.is_finite() || self.model.horizon_sec <= 0.0 {
            bail!("model.horizon_sec must be finite and positive");
        }
        if self.model.quote_size_lots <= 0 {
            bail!("model.quote_size_lots must be positive");
        }
        if self.model.min_half_spread_ticks <= 0 {
            bail!("model.min_half_spread_ticks must be positive");
        }
        if self.risk.max_inventory_lots <= 0 {
            bail!("risk.max_inventory_lots must be positive");
        }
        if self.risk.reduce_only_threshold_lots < 0
            || self.risk.reduce_only_threshold_lots > self.risk.max_inventory_lots
        {
            bail!("risk.reduce_only_threshold_lots must be in [0, max_inventory_lots]");
        }
        if let Some(surface) = &self.hjb {
            if surface.inventory_step_lots <= 0 {
                bail!("hjb.inventory_step_lots must be positive");
            }
            if surface.bid_offset_ticks.is_empty()
                || surface.bid_offset_ticks.len() != surface.ask_offset_ticks.len()
            {
                bail!("HJB bid/ask offset arrays must be non-empty and have equal lengths");
            }
            if surface.bid_offset_ticks.iter().any(|x| *x <= 0)
                || surface.ask_offset_ticks.iter().any(|x| *x <= 0)
            {
                bail!("HJB offsets must be strictly positive ticks");
            }
        }
        Ok(())
    }
}

#[inline]
fn floor_to_tick(value: i64, tick: i64) -> i64 {
    value.div_euclid(tick) * tick
}

#[inline]
fn ceil_to_tick(value: i64, tick: i64) -> i64 {
    let q = value.div_euclid(tick);
    if value.rem_euclid(tick) == 0 {
        q * tick
    } else {
        (q + 1) * tick
    }
}

#[inline]
fn surface_offsets(surface: &HjbSurface, inventory_lots: i64) -> (i64, i64) {
    let raw = (inventory_lots - surface.inventory_min_lots)
        .div_euclid(surface.inventory_step_lots);
    let idx = raw.clamp(0, surface.bid_offset_ticks.len() as i64 - 1) as usize;
    (
        surface.bid_offset_ticks[idx],
        surface.ask_offset_ticks[idx],
    )
}

/// Allocation-free quote calculation used by the dedicated hot-path thread.
#[inline]
pub fn compute_desired_quotes(
    snapshot: &StrategySnapshot,
    market: &MarketConfig,
    bbo: Bbo,
    inventory_lots: i64,
    quote_seq: u64,
    now_ns: u64,
    reason: QuoteReason,
) -> DesiredQuotes {
    let mut result = DesiredQuotes {
        bid: None,
        ask: None,
        quote_seq,
        model_revision: snapshot.revision,
        generated_ns: now_ns,
        reason,
    };

    if snapshot.risk.kill_switch || !bbo.is_valid() {
        result.reason = QuoteReason::RiskLimit;
        return result;
    }

    let price_scale = market.price_scale() as f64;
    let size_scale = market.size_scale() as f64;
    let mid_units = bbo.mid_units();
    let mid = mid_units as f64 / price_scale;
    if !mid.is_finite() || mid <= 0.0 {
        result.reason = QuoteReason::RiskLimit;
        return result;
    }

    let market_spread_bps = (bbo.ask_px - bbo.bid_px) as f64 / mid_units as f64 * 10_000.0;
    if market_spread_bps > snapshot.risk.max_market_spread_bps {
        result.reason = QuoteReason::RiskLimit;
        return result;
    }

    let base_size = snapshot.model.quote_size_lots.max(1);
    let order_base_units = base_size.saturating_mul(market.size_step_units);
    let order_size = order_base_units as f64 / size_scale;
    if snapshot.risk.max_order_notional > 0.0
        && order_size * mid > snapshot.risk.max_order_notional
    {
        result.reason = QuoteReason::RiskLimit;
        return result;
    }

    let inventory_base = inventory_lots as f64 * market.size_step_units as f64 / size_scale;
    if snapshot.risk.max_position_notional > 0.0
        && inventory_base.abs() * mid > snapshot.risk.max_position_notional
    {
        result.reason = QuoteReason::RiskLimit;
        return result;
    }

    let (mut bid_px, mut ask_px) = if let Some(surface) = &snapshot.hjb {
        let (bid_ticks, ask_ticks) = surface_offsets(surface, inventory_lots);
        (
            mid_units.saturating_sub(bid_ticks.saturating_mul(market.price_tick_units)),
            mid_units.saturating_add(ask_ticks.saturating_mul(market.price_tick_units)),
        )
    } else {
        let variance = snapshot.model.sigma * snapshot.model.sigma * snapshot.model.horizon_sec;
        let reservation = mid
            - snapshot.model.gamma * variance * inventory_base
            - mid
                * snapshot.model.inventory_skew_bps_per_lot
                * inventory_lots as f64
                / 10_000.0;

        let model_half_spread = if snapshot.model.gamma > 1e-12 {
            0.5 * snapshot.model.gamma * variance
                + (1.0 / snapshot.model.gamma)
                    * (1.0 + snapshot.model.gamma / snapshot.model.kappa).ln()
        } else {
            1.0 / snapshot.model.kappa
        };
        let floor_price = mid * snapshot.model.base_half_spread_bps / 10_000.0;
        let tick_floor = snapshot.model.min_half_spread_ticks as f64
            * market.price_tick_units as f64
            / price_scale;
        let half_spread = model_half_spread.max(floor_price).max(tick_floor);
        (
            ((reservation - half_spread) * price_scale).floor() as i64,
            ((reservation + half_spread) * price_scale).ceil() as i64,
        )
    };

    let bid_quantum = market.price_quantum_for(bid_px);
    let ask_quantum = market.price_quantum_for(ask_px);
    bid_px = floor_to_tick(bid_px, bid_quantum);
    ask_px = ceil_to_tick(ask_px, ask_quantum);

    // Post-only clamps: never cross the opposite BBO and cap how aggressively
    // the bot improves the displayed same-side quote.
    let max_bid = (bbo.ask_px - market.price_tick_units).min(
        bbo.bid_px
            + snapshot.model.max_quote_improvement_ticks.max(0) * market.price_tick_units,
    );
    let min_ask = (bbo.bid_px + market.price_tick_units).max(
        bbo.ask_px
            - snapshot.model.max_quote_improvement_ticks.max(0) * market.price_tick_units,
    );
    bid_px = floor_to_tick(bid_px.min(max_bid), market.price_quantum_for(bid_px));
    ask_px = ceil_to_tick(ask_px.max(min_ask), market.price_quantum_for(ask_px));
    if bid_px <= 0 || ask_px <= bid_px {
        result.reason = QuoteReason::RiskLimit;
        return result;
    }

    let max_inventory = snapshot.risk.max_inventory_lots;
    let reduce_threshold = snapshot.risk.reduce_only_threshold_lots;
    let can_buy = inventory_lots.saturating_add(base_size) <= max_inventory;
    let can_sell = inventory_lots.saturating_sub(base_size) >= -max_inventory;

    if can_buy {
        result.bid = Some(DesiredOrder {
            side: Side::Buy,
            px: bid_px,
            qty_lots: base_size,
            reduce_only: inventory_lots >= reduce_threshold && inventory_lots > 0,
        });
    }
    if can_sell {
        result.ask = Some(DesiredOrder {
            side: Side::Sell,
            px: ask_px,
            qty_lots: base_size,
            reduce_only: inventory_lots <= -reduce_threshold && inventory_lots < 0,
        });
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    fn market() -> MarketConfig {
        MarketConfig {
            price_decimals: 2,
            size_decimals: 3,
            price_tick_units: 1,
            size_step_units: 1,
            ..MarketConfig::default()
        }
    }

    #[test]
    fn quote_is_post_only_and_inventory_skews_down() {
        let mut snapshot = StrategySnapshot::default();
        snapshot.model.sigma = 0.0;
        snapshot.model.inventory_skew_bps_per_lot = 1.0;
        let bbo = Bbo {
            bid_px: 10_000,
            ask_px: 10_002,
            bid_sz: 10,
            ask_sz: 10,
            ..Bbo::default()
        };
        let flat = compute_desired_quotes(&snapshot, &market(), bbo, 0, 1, 1, QuoteReason::Market);
        let long = compute_desired_quotes(&snapshot, &market(), bbo, 5, 2, 2, QuoteReason::Market);
        assert!(flat.bid.unwrap().px < bbo.ask_px);
        assert!(flat.ask.unwrap().px > bbo.bid_px);
        assert!(long.bid.unwrap().px <= flat.bid.unwrap().px);
        assert!(long.ask.unwrap().px <= flat.ask.unwrap().px);
    }

    #[test]
    fn inventory_limit_disables_risk_increasing_side() {
        let mut snapshot = StrategySnapshot::default();
        snapshot.risk.max_inventory_lots = 2;
        snapshot.model.quote_size_lots = 1;
        let bbo = Bbo {
            bid_px: 10_000,
            ask_px: 10_002,
            bid_sz: 10,
            ask_sz: 10,
            ..Bbo::default()
        };
        let q = compute_desired_quotes(&snapshot, &market(), bbo, 2, 1, 1, QuoteReason::Market);
        assert!(q.bid.is_none());
        assert!(q.ask.is_some());
    }
}
